"""Generate publication-quality screenshots for napari-turbobox paper.

This script creates impressive figures that demonstrate:
1. Multi-viewer synchronized annotation workflow
2. Interactive bbox editing in different view modes
3. Real-world usage scenarios

Usage:
    python generate_paper_screenshots.py
"""

import time
from pathlib import Path

import napari
import numpy as np
from napari_turbobox import create_synchronized_bbox_layers
from qtpy.QtWidgets import QApplication


def create_demo_image_with_cells(shape=(100, 512, 512)) -> np.ndarray:
    """Create synthetic 3D image with cell-like structures."""
    print("🔬 Generating demo image with synthetic cells...")

    Z, Y, X = shape
    image = np.zeros(shape, dtype=np.uint16)

    # Add background noise
    np.random.seed(42)
    image += np.random.poisson(50, size=shape).astype(np.uint16)

    # Create 15-20 cell-like blobs
    n_cells = 18
    cell_positions = []

    for _i in range(n_cells):
        # Random position
        z = np.random.randint(10, Z - 10)
        y = np.random.randint(50, Y - 50)
        x = np.random.randint(50, X - 50)

        # Random size
        radius_z = np.random.randint(8, 15)
        radius_y = np.random.randint(20, 40)
        radius_x = np.random.randint(20, 40)

        # Create gaussian blob
        zz, yy, xx = np.ogrid[:Z, :Y, :X]
        dist = ((zz - z) / radius_z) ** 2 + ((yy - y) / radius_y) ** 2 + ((xx - x) / radius_x) ** 2
        blob = np.exp(-dist)

        # Add to image with varying intensity
        intensity = np.random.randint(800, 1500)
        image += (blob * intensity).astype(np.uint16)

        cell_positions.append((z, y, x, radius_z, radius_y, radius_x))

    print(f"✅ Generated image with {n_cells} synthetic cells")
    return image, cell_positions


def create_demo_bboxes_from_cells(cell_positions, margin=5) -> np.ndarray:
    """Create bounding boxes around cell positions."""
    boxes = []

    for z, y, x, rz, ry, rx in cell_positions[:12]:  # Use first 12 cells
        mins = np.array([
            max(0, z - rz - margin),
            max(0, y - ry - margin),
            max(0, x - rx - margin)
        ], dtype=float)

        maxs = np.array([
            z + rz + margin,
            y + ry + margin,
            x + rx + margin
        ], dtype=float)

        boxes.append([mins, maxs])

    return np.array(boxes, dtype=float)


def setup_viewer_aesthetics(viewer: napari.Viewer, title: str | None = None):
    """Configure viewer for publication-quality screenshots."""
    # Set window title
    if title:
        viewer.title = title

    # Configure camera
    viewer.camera.angles = (15, 25, 120)
    viewer.camera.zoom = 1.2

    # Set theme
    viewer.theme = 'dark'

    # Configure axes (napari 0.6.6 compatible)
    viewer.axes.visible = True
    viewer.axes.colored = True

    # Scale bar
    viewer.scale_bar.visible = True


def generate_figure1_multiview(output_dir: Path):
    """
    Figure 1: Multi-Viewer Synchronized Annotation
    Shows XY, XZ, YZ, and 3D views with synchronized bboxes.
    """
    print("\n" + "=" * 80)
    print("📸 GENERATING FIGURE 1: Multi-Viewer Synchronized Annotation")
    print("=" * 80)

    # Create synthetic data
    image, cell_positions = create_demo_image_with_cells((80, 512, 512))
    boxes = create_demo_bboxes_from_cells(cell_positions)

    # Create 4 synchronized viewers
    print("🖥️  Creating 4 synchronized viewers (XY, XZ, YZ, 3D)...")
    viewers = []

    # XY view (transverse)
    v_xy = napari.Viewer(title="XY View (Transverse)", show=False)
    v_xy.add_image(image, name='Cells', colormap='green', contrast_limits=(0, 2000))
    v_xy.dims.order = (0, 1, 2)  # Z, Y, X
    v_xy.dims.ndisplay = 2
    v_xy.dims.set_point(0, 40)  # Middle Z slice
    viewers.append(v_xy)

    # XZ view (coronal)
    v_xz = napari.Viewer(title="XZ View (Coronal)", show=False)
    v_xz.add_image(image, name='Cells', colormap='green', contrast_limits=(0, 2000))
    v_xz.dims.order = (1, 0, 2)  # Y, Z, X
    v_xz.dims.ndisplay = 2
    v_xz.dims.set_point(0, 256)  # Middle Y
    viewers.append(v_xz)

    # YZ view (sagittal)
    v_yz = napari.Viewer(title="YZ View (Sagittal)", show=False)
    v_yz.add_image(image, name='Cells', colormap='green', contrast_limits=(0, 2000))
    v_yz.dims.order = (2, 0, 1)  # X, Z, Y
    v_yz.dims.ndisplay = 2
    v_yz.dims.set_point(0, 256)  # Middle X
    viewers.append(v_yz)

    # 3D view
    v_3d = napari.Viewer(title="3D View", show=False)
    v_3d.add_image(image, name='Cells', colormap='green', contrast_limits=(0, 2000),
                   rendering='attenuated_mip', attenuation=0.1, opacity=0.6)
    v_3d.dims.ndisplay = 3
    viewers.append(v_3d)

    # Create synchronized bbox layers
    print("🔗 Creating synchronized bounding box layers...")
    layers = create_synchronized_bbox_layers(
        main_viewer=v_xy,
        sub_viewers=[v_xz, v_yz, v_3d],
        image_shape=image.shape
    )

    # Add demo boxes
    print(f"📦 Adding {len(boxes)} bounding boxes...")
    layers[0].add_boxes(boxes)

    # Configure aesthetics
    for viewer in viewers:
        setup_viewer_aesthetics(viewer)

    # Process events and wait for rendering
    for _ in range(10):
        QApplication.processEvents()
    time.sleep(0.3)

    # Show viewers for screenshots
    print("📸 Capturing screenshots...")
    for v in viewers:
        v.show()
        v.window.resize(800, 600)

    QApplication.processEvents()
    time.sleep(0.5)

    # Capture screenshots
    screenshots = {}
    for _i, (viewer, name) in enumerate(zip(viewers, ['XY', 'XZ', 'YZ', '3D'])):
        screenshot = viewer.screenshot(canvas_only=True, scale=2.0)
        screenshots[name] = screenshot
        print(f"  ✅ Captured {name} view ({screenshot.shape})")

    # Create combined figure
    print("🎨 Creating combined multi-panel figure...")
    from PIL import Image

    # Arrange in 2x2 grid
    img_xy = Image.fromarray(screenshots['XY'])
    img_xz = Image.fromarray(screenshots['XZ'])
    img_yz = Image.fromarray(screenshots['YZ'])
    img_3d = Image.fromarray(screenshots['3D'])

    # Resize to consistent dimensions
    target_size = (1200, 900)
    img_xy = img_xy.resize(target_size, Image.Resampling.LANCZOS)
    img_xz = img_xz.resize(target_size, Image.Resampling.LANCZOS)
    img_yz = img_yz.resize(target_size, Image.Resampling.LANCZOS)
    img_3d = img_3d.resize(target_size, Image.Resampling.LANCZOS)

    # Create 2x2 composite
    gap = 40
    width = target_size[0] * 2 + gap * 3
    height = target_size[1] * 2 + gap * 3
    composite = Image.new('RGB', (width, height), (20, 20, 20))

    # Paste images
    composite.paste(img_xy, (gap, gap))
    composite.paste(img_xz, (gap * 2 + target_size[0], gap))
    composite.paste(img_yz, (gap, gap * 2 + target_size[1]))
    composite.paste(img_3d, (gap * 2 + target_size[0], gap * 2 + target_size[1]))

    # Add labels
    from PIL import ImageDraw, ImageFont
    draw = ImageDraw.Draw(composite)

    try:
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 36)
        font_bold = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 48)
    except:
        font = ImageFont.load_default()
        font_bold = font

    labels = [
        ("A) XY View (Transverse)", gap + 20, gap + 20),
        ("B) XZ View (Coronal)", gap * 2 + target_size[0] + 20, gap + 20),
        ("C) YZ View (Sagittal)", gap + 20, gap * 2 + target_size[1] + 20),
        ("D) 3D View", gap * 2 + target_size[0] + 20, gap * 2 + target_size[1] + 20),
    ]

    for text, x, y in labels:
        # Shadow
        draw.text((x + 2, y + 2), text, fill=(0, 0, 0), font=font_bold)
        # Text
        draw.text((x, y), text, fill=(255, 255, 255), font=font_bold)

    output_path = output_dir / "figure1_multiview_synchronized.png"
    composite.save(output_path, quality=95, dpi=(300, 300))
    print(f"✅ Saved: {output_path}")

    # Cleanup
    for v in viewers:
        v.close()

    return screenshots


def generate_figure2_workflow(output_dir: Path):
    """
    Figure 2: Interactive Annotation Workflow
    Shows step-by-step workflow of bbox annotation.
    """
    print("\n" + "=" * 80)
    print("📸 GENERATING FIGURE 2: Interactive Annotation Workflow")
    print("=" * 80)

    # Create synthetic data
    image, cell_positions = create_demo_image_with_cells((60, 512, 512))

    # Create single viewer for workflow demo
    viewer = napari.Viewer(title="napari-turbobox Workflow", show=False)
    viewer.add_image(image, name='Cells', colormap='magma', contrast_limits=(0, 2000))

    # Add bbox layer
    from napari_turbobox import OptimizedBoundingBoxLayer
    bbox_layer = OptimizedBoundingBoxLayer(
        ndim=3,
        image_shape=image.shape,
        edge_color='cyan',
        edge_width=3.0
    )
    viewer.add_layer(bbox_layer)

    setup_viewer_aesthetics(viewer, "Workflow Demo")

    # Set to middle Z slice
    viewer.dims.set_point(0, 30)

    # Process and show
    for _ in range(10):
        QApplication.processEvents()
    time.sleep(0.2)

    viewer.show()
    viewer.window.resize(1400, 1000)
    QApplication.processEvents()
    time.sleep(0.3)

    screenshots = {}

    # Step 1: Empty layer
    print("📸 Step 1: Empty annotation layer...")
    time.sleep(0.2)
    screenshots['step1'] = viewer.screenshot(canvas_only=True, scale=2.0)

    # Step 2: Add first box
    print("📸 Step 2: Adding first bounding box...")
    box1 = np.array([
        [25, 150, 180],
        [35, 220, 260]
    ], dtype=float)
    bbox_layer.add_boxes(box1)
    QApplication.processEvents()
    time.sleep(0.2)
    screenshots['step2'] = viewer.screenshot(canvas_only=True, scale=2.0)

    # Step 3: Add more boxes
    print("📸 Step 3: Multiple boxes annotated...")
    boxes = create_demo_bboxes_from_cells(cell_positions)[:6]
    bbox_layer.add_boxes(boxes)
    QApplication.processEvents()
    time.sleep(0.2)
    screenshots['step3'] = viewer.screenshot(canvas_only=True, scale=2.0)

    # Step 4: 3D view
    print("📸 Step 4: 3D visualization...")
    viewer.dims.ndisplay = 3
    viewer.camera.angles = (10, 30, 120)
    viewer.camera.zoom = 1.5
    QApplication.processEvents()
    time.sleep(0.3)
    screenshots['step4'] = viewer.screenshot(canvas_only=True, scale=2.0)

    # Create workflow composite
    print("🎨 Creating workflow composite figure...")
    from PIL import Image, ImageDraw, ImageFont

    # Load screenshots
    imgs = [Image.fromarray(screenshots[f'step{i}']) for i in range(1, 5)]

    # Resize
    target_size = (1200, 900)
    imgs = [img.resize(target_size, Image.Resampling.LANCZOS) for img in imgs]

    # Create 2x2 grid
    gap = 40
    width = target_size[0] * 2 + gap * 3
    height = target_size[1] * 2 + gap * 3
    composite = Image.new('RGB', (width, height), (20, 20, 20))

    # Paste
    positions = [
        (gap, gap),
        (gap * 2 + target_size[0], gap),
        (gap, gap * 2 + target_size[1]),
        (gap * 2 + target_size[0], gap * 2 + target_size[1]),
    ]

    for img, pos in zip(imgs, positions):
        composite.paste(img, pos)

    # Add labels
    draw = ImageDraw.Draw(composite)
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 40)
    except:
        font = ImageFont.load_default()

    labels = [
        ("1) Load Image", gap + 20, gap + 20),
        ("2) Draw First Box", gap * 2 + target_size[0] + 20, gap + 20),
        ("3) Annotate Multiple Objects", gap + 20, gap * 2 + target_size[1] + 20),
        ("4) Visualize in 3D", gap * 2 + target_size[0] + 20, gap * 2 + target_size[1] + 20),
    ]

    for text, x, y in labels:
        # Shadow
        draw.text((x + 2, y + 2), text, fill=(0, 0, 0), font=font)
        # Text
        draw.text((x, y), text, fill=(0, 255, 255), font=font)

    output_path = output_dir / "figure2_workflow.png"
    composite.save(output_path, quality=95, dpi=(300, 300))
    print(f"✅ Saved: {output_path}")

    viewer.close()


def generate_figure3_gui_features(output_dir: Path):
    """
    Figure 3: Key GUI Features
    Highlights interactive features and capabilities.
    """
    print("\n" + "=" * 80)
    print("📸 GENERATING FIGURE 3: GUI Features")
    print("=" * 80)

    # Create data
    image, cell_positions = create_demo_image_with_cells((70, 512, 512))
    boxes = create_demo_bboxes_from_cells(cell_positions)[:8]

    # Create viewer
    viewer = napari.Viewer(title="napari-turbobox Features", show=False)
    viewer.add_image(image, name='Cells', colormap='viridis', contrast_limits=(0, 2000))

    from napari_turbobox import OptimizedBoundingBoxLayer
    bbox_layer = OptimizedBoundingBoxLayer(
        ndim=3,
        image_shape=image.shape,
        edge_color='#00ffff',
        edge_width=2.5
    )
    viewer.add_layer(bbox_layer)
    bbox_layer.add_boxes(boxes)

    setup_viewer_aesthetics(viewer, "Interactive Features")
    viewer.dims.set_point(0, 35)

    # Show
    viewer.show()
    viewer.window.resize(1600, 1200)

    for _ in range(10):
        QApplication.processEvents()
    time.sleep(0.4)

    # Capture single impressive screenshot (canvas only due to napari limitation)
    screenshot = viewer.screenshot(canvas_only=True, scale=2.0)
    from PIL import Image
    img = Image.fromarray(screenshot)

    output_path = output_dir / "figure3_gui_features.png"
    img.save(output_path, quality=95, dpi=(300, 300))
    print(f"✅ Saved: {output_path}")

    viewer.close()



def generate_gallery_screenshot(output_dir: Path):
    """
    Generate High-Res Gallery Screenshot (Custom 2x2 Grid + Controls).
    Requested: 2x2 Viewers (XY, XZ, YZ, 3D) + Settings Tab on Right.
    """
    print("\n" + "=" * 80)
    print("📸 GENERATING GALLERY SCREENSHOT (2x2 Grid Layout)")
    print("=" * 80)

    # 1. Create large synthetic data
    shape = (200, 1080, 1920)
    print(f"🔬 Generating high-res synthetic data {shape}...")

    Z, Y, X = shape
    image = np.zeros(shape, dtype=np.uint16)

    # Background noise
    np.random.seed(42)

    # Create ~80 blobs
    n_blobs = 80
    blobs_positions = []

    print(f"   Adding {n_blobs} blobs...")

    for _i in range(n_blobs):
        z = np.random.randint(20, Z - 20)
        y = np.random.randint(100, Y - 100)
        x = np.random.randint(100, X - 100)

        rz = np.random.randint(5, 15)
        ry = np.random.randint(30, 80)
        rx = np.random.randint(30, 80)

        sl_z = slice(max(0, z-rz*2), min(Z, z+rz*2))
        sl_y = slice(max(0, y-ry*2), min(Y, y+ry*2))
        sl_x = slice(max(0, x-rx*2), min(X, x+rx*2))

        dz, dy, dx = np.ogrid[sl_z, sl_y, sl_x]
        dist = ((dz - z) / rz)**2 + ((dy - y) / ry)**2 + ((dx - x) / rx)**2
        blob = np.exp(-dist) * np.random.randint(2000, 4000)

        image[sl_z, sl_y, sl_x] += blob.astype(np.uint16)
        blobs_positions.append((z, y, x, rz, ry, rx))

    # 2. Create BBoxes
    print("   Creating bounding boxes...")
    boxes = create_demo_bboxes_from_cells(blobs_positions, margin=15)

    # 3. Setup Layout
    print("🖥️  Building Custom Gallery Window...")

    from qtpy.QtCore import Qt
    from qtpy.QtWidgets import QApplication, QGridLayout, QHBoxLayout, QLabel, QVBoxLayout, QWidget
    # Ensure app exists
    if not QApplication.instance():
        QApplication([])

    # Main Container
    gallery_window = QWidget()
    gallery_window.setStyleSheet("background-color: #262930; color: #EEE;") # Napari Dark Theme
    main_layout = QHBoxLayout()
    gallery_window.setLayout(main_layout)
    main_layout.setContentsMargins(10, 10, 10, 10)
    main_layout.setSpacing(10)

    # --- 2x2 Grid Section ---
    grid_container = QWidget()
    grid_layout = QGridLayout()
    grid_container.setLayout(grid_layout)
    grid_layout.setContentsMargins(0,0,0,0)
    grid_layout.setSpacing(5)

    def setup_viewer(title, order=None, ndisplay=2, zoom=0.35, cam_zoom=0.4):
        v = napari.Viewer(show=False)
        v.theme = 'dark'

        # Add Image
        l = v.add_image(image, name=title, colormap='green', contrast_limits=(0, 4000), blending='additive')

        # Config Dims
        v.dims.ndisplay = ndisplay
        if order:
            v.dims.order = order

        # Center dims
        if ndisplay == 2:
            # Set slider checks
            # Default (0, 1, 2) -> Z is slider.
            if order is None: # XY
                v.dims.set_point(0, Z//2)
            elif order == (1, 0, 2): # XZ -> Y is slider
                v.dims.set_point(0, Y//2) # Dim 1 is first
            elif order == (2, 0, 1): # YZ -> X is slider
                v.dims.set_point(0, X//2) # Dim 2 is first

        # Visuals
        v.scale_bar.visible = True
        v.scale_bar.unit = "µm"
        v.axes.visible = True

        if ndisplay == 3:
             v.camera.zoom = cam_zoom
             # Better 3D rendering
             l.rendering = 'attenuated_mip'
             l.attenuation = 0.05
        else:
             v.camera.zoom = zoom

        return v

    # Instantiate Viewers
    v_xy = setup_viewer("XY View (Transverse)", order=None)
    v_xz = setup_viewer("XZ View (Coronal)", order=(1, 0, 2))
    v_yz = setup_viewer("YZ View (Sagittal)", order=(2, 0, 1))
    v_3d = setup_viewer("3D Render", ndisplay=3)

    # Sync Boxes
    from napari_turbobox import create_synchronized_bbox_layers
    layers = create_synchronized_bbox_layers(v_xy, [v_xz, v_yz, v_3d], image_shape=shape)

    # Add Boxes & Style
    for lyr in layers:
        lyr.edge_color = '#00AAFF'
        lyr.edge_width = 3
        lyr.current_edge_width = 3
    layers[0].add_boxes(boxes)

    # Wrap and Add to Grid
    def wrap_viewer(v, label_text):
        w = QWidget()
        l = QVBoxLayout()
        l.setContentsMargins(0,0,0,0)
        l.setSpacing(0)

        # Label Header
        lbl = QLabel(label_text)
        lbl.setStyleSheet("background-color: #333; padding: 5px; font-weight: bold; border-left: 4px solid #00AAFF;")
        l.addWidget(lbl)

        # Steal QtViewer
        qtv = v.window.qt_viewer
        l.addWidget(qtv)

        w.setLayout(l)
        return w

    grid_layout.addWidget(wrap_viewer(v_xy, "1. XY View (Transverse)"), 0, 0)
    grid_layout.addWidget(wrap_viewer(v_xz, "2. XZ View (Coronal)"), 0, 1)
    grid_layout.addWidget(wrap_viewer(v_yz, "3. YZ View (Sagittal)"), 1, 0)
    grid_layout.addWidget(wrap_viewer(v_3d, "4. 3D Render"), 1, 1)

    # Add Grid to Main Layout
    main_layout.addWidget(grid_container, stretch=3)

    # --- Right Sidebar: Controls ---
    # We use the BoundingBoxControlWidget
    try:
        from napari_turbobox import BoundingBoxControlWidget
        ctrl_widget = BoundingBoxControlWidget(v_xy) # Controls the main viewer (XY)

        sidebar = QWidget()
        sidebar_layout = QVBoxLayout()
        sidebar.setLayout(sidebar_layout)
        sidebar_layout.setContentsMargins(0,0,0,0)

        lbl_ctrl = QLabel("Settings & Controls")
        lbl_ctrl.setStyleSheet("font-size: 14pt; font-weight: bold; padding: 10px; color: #00AAFF;")
        lbl_ctrl.setAlignment(Qt.AlignCenter)
        sidebar_layout.addWidget(lbl_ctrl)

        sidebar_layout.addWidget(ctrl_widget)
        sidebar_layout.addStretch()

        sidebar.setFixedWidth(400) # Fixed width for nice proportion

        main_layout.addWidget(sidebar, stretch=1)

    except ImportError:
        print("⚠️  Could not import BoundingBoxControlWidget")

    # 4. Show and Capture
    print("📸 Rendering Custom Layout...")

    gallery_window.resize(1920, 1080) # Full HD
    gallery_window.show()

    # Wait for resize/render
    for _ in range(50): QApplication.processEvents()
    time.sleep(2.0)

    # Capture
    try:
        pixmap = gallery_window.grab()
        out_file = output_dir / "figure5_gallery_2x2_grid.png"
        pixmap.save(str(out_file))
        print(f"✅ Saved custom 2x2 grid screenshot: {out_file}")
    except Exception as e:
        print(f"❌ Screen grab failed: {e}")

    # Cleanup
    gallery_window.close()
    for v in [v_xy, v_xz, v_yz, v_3d]:
        v.close()


def main():
    """Generate all paper figures."""
    output_dir = Path(".")
    output_dir.mkdir(exist_ok=True)

    print("\n" + "=" * 80)
    print("🎬 STARTING PAPER SCREENSHOT GENERATION")
    print("=" * 80)
    print(f"Output directory: {output_dir.absolute()}")
    print()

    try:
        # Generate all figures
        generate_gallery_screenshot(output_dir)  # New high-res gallery asset
        generate_figure1_multiview(output_dir)
        generate_figure2_workflow(output_dir)
        generate_figure3_gui_features(output_dir)

        print("\n" + "=" * 80)
        print("✅ ALL SCREENSHOTS GENERATED SUCCESSFULLY!")
        print("=" * 80)
        print("\n📁 Generated files:")
        print("  - figure1_multiview_synchronized.png  (Multi-viewer demo)")
        print("  - figure2_workflow.png                 (Annotation workflow)")
        print("  - figure3_gui_features.png             (GUI overview)")
        print("\n💡 For your paper:")
        print("  Figure 1: Use for demonstrating synchronized multi-view annotation")
        print("  Figure 2: Use for explaining the annotation workflow")
        print("  Figure 3: Use for showcasing the GUI")
        print("  Also use: benchmark_combined_figure.png (Performance comparison)")

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
