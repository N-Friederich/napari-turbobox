"""Launch an interactive C. elegans multi-view napari session."""

import logging
from datetime import datetime
from pathlib import Path

import napari
import napari_turbobox.widget as bbox_widget_module
import numpy as np
import tifffile
from napari_turbobox import create_synchronized_bbox_layers
from qtpy.QtCore import Qt
from qtpy.QtWidgets import (
    QDockWidget,
    QGridLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from paper_benchmarks.generate_gui_screenshots import compute_bboxes, download_celegans


def main() -> None:
    paths = download_celegans(Path("paper_results/celegans_data"))
    raw = tifffile.imread(paths["raw"])
    bboxes = compute_bboxes(paths["gt"])

    viewer_xy = napari.Viewer(show=False, title="XY (Axial)")
    viewer_xz = napari.Viewer(show=False, title="XZ (Coronal)")
    viewer_yz = napari.Viewer(show=False, title="YZ (Sagittal)")
    viewer_3d = napari.Viewer(show=False, title="3D View")
    viewers = [viewer_xy, viewer_xz, viewer_yz, viewer_3d]

    limits = [float(np.percentile(raw, 1)), float(np.percentile(raw, 99.5))]
    for viewer in viewers:
        viewer.add_image(raw, name="C. elegans Raw", colormap="gray", contrast_limits=limits)

    layers = create_synchronized_bbox_layers(
        main_viewer=viewer_xy,
        sub_viewers=[viewer_xz, viewer_yz, viewer_3d],
        image_shape=raw.shape,
    )
    layers[0].add_boxes(bboxes)

    for layer in layers:
        if hasattr(layer, "edge_color"):
            layer.edge_color = "cyan"
        if hasattr(layer, "edge_width"):
            layer.edge_width = 3.0

    viewer_xy.dims.ndisplay = 2
    viewer_xy.dims.order = (0, 1, 2)
    viewer_xy.dims.set_point(0, raw.shape[0] // 2)
    viewer_xy.camera.zoom = 0.95

    viewer_xz.dims.ndisplay = 2
    viewer_xz.dims.order = (1, 0, 2)
    viewer_xz.dims.set_point(1, raw.shape[1] // 2)
    viewer_xz.camera.zoom = 0.9

    viewer_yz.dims.ndisplay = 2
    viewer_yz.dims.order = (2, 0, 1)
    viewer_yz.dims.set_point(2, raw.shape[2] // 2)
    viewer_yz.camera.zoom = 0.9

    viewer_3d.dims.ndisplay = 3
    viewer_3d.camera.angles = (22, -28, 135)
    viewer_3d.camera.zoom = 0.52

    # Force one initial sync for sub-viewers.
    # Without this, XZ/YZ can stay empty until the first manual slice movement.
    for layer in layers[1:]:
        layer._sync_shapes_from_bboxes()

    if not hasattr(bbox_widget_module, "logger"):
        bbox_widget_module.logger = logging.getLogger(__name__)

    main_window = QMainWindow()
    main_window.resize(1800, 1100)
    main_window.setWindowTitle("Interactive C. elegans Multi-View")

    grid_widget = QWidget()
    layout = QGridLayout(grid_widget)
    layout.setContentsMargins(2, 2, 2, 2)
    layout.setSpacing(2)
    layout.addWidget(viewer_xy.window.qt_viewer, 0, 0)
    layout.addWidget(viewer_xz.window.qt_viewer, 0, 1)
    layout.addWidget(viewer_yz.window.qt_viewer, 1, 0)
    layout.addWidget(viewer_3d.window.qt_viewer, 1, 1)
    main_window.setCentralWidget(grid_widget)

    control_widget = bbox_widget_module.BoundingBoxControlWidget(viewer_xy)
    dock = QDockWidget("BBox Controls", main_window)
    dock.setWidget(control_widget)
    main_window.addDockWidget(Qt.RightDockWidgetArea, dock)

    screenshot_panel = QWidget()
    screenshot_layout = QVBoxLayout(screenshot_panel)
    screenshot_layout.setContentsMargins(8, 8, 8, 8)

    save_button = QPushButton("Save Screenshot")
    status_label = QLabel("Ready")
    screenshot_layout.addWidget(save_button)
    screenshot_layout.addWidget(status_label)

    screenshot_dock = QDockWidget("Capture", main_window)
    screenshot_dock.setWidget(screenshot_panel)
    main_window.addDockWidget(Qt.RightDockWidgetArea, screenshot_dock)

    def _save_screenshot() -> None:
        out_dir = Path("paper_results")
        out_dir.mkdir(exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = out_dir / f"Screenshot5_CElegans_MultiView_manual_{ts}.png"

        pixmap = main_window.grab()
        pixmap.save(str(out_path))

        try:
            from PIL import Image

            with Image.open(out_path) as image:
                image.save(out_path, dpi=(300, 300))
        except Exception:
            pass

        status_label.setText(f"Saved: {out_path.name}")
        print(f"Saved screenshot: {out_path}")

    save_button.clicked.connect(_save_screenshot)

    main_window.show()
    print("Interactive napari session running. Close the window to exit.")
    napari.run()


if __name__ == "__main__":
    main()
