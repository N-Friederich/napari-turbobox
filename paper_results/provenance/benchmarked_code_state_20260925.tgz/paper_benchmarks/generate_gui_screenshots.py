"""Generate GUI screenshots suitable for paper figures.

This script creates annotated screenshots showing:
- Multi-view synchronized annotation workflow
- Control panel interface
- 3D visualization with bounding boxes
"""

import logging
import time
import zipfile
from pathlib import Path

import napari
import numpy as np
import requests
import tifffile
from qtpy.QtWidgets import QApplication

try:
    from napari_turbobox import create_synchronized_bbox_layers
    HAS_PLUGIN = True
except ImportError:
    print("⚠️  napari-turbobox not installed")
    HAS_PLUGIN = False


def create_demo_data(shape=(50, 256, 256)):
    """Create synthetic 3D image data with blob-like structures."""
    from scipy import ndimage

    # Create random blobs
    np.random.seed(42)
    data = np.zeros(shape, dtype=np.float32)

    n_blobs = 15
    for _ in range(n_blobs):
        z = np.random.randint(5, shape[0] - 5)
        y = np.random.randint(30, shape[1] - 30)
        x = np.random.randint(30, shape[2] - 30)

        # Create Gaussian blob
        zz, yy, xx = np.ogrid[:shape[0], :shape[1], :shape[2]]
        blob = np.exp(-((zz - z)**2 / 20 + (yy - y)**2 / 400 + (xx - x)**2 / 400))
        data += blob * np.random.uniform(0.5, 1.0)

    # Smooth and add noise
    data = ndimage.gaussian_filter(data, sigma=1.5)
    data += np.random.normal(0, 0.05, data.shape)
    data = np.clip(data, 0, 1)

    return (data * 255).astype(np.uint8)


def create_demo_boxes(image_shape, n_boxes=10):
    """Create bounding boxes around blob-like regions."""
    Z, Y, X = image_shape
    boxes = []

    np.random.seed(42)
    for _i in range(n_boxes):
        # Create boxes of varying sizes
        size_z = np.random.randint(8, 15)
        size_y = np.random.randint(20, 40)
        size_x = np.random.randint(20, 40)

        z_start = np.random.randint(5, max(6, Z - size_z - 5))
        y_start = np.random.randint(20, max(21, Y - size_y - 20))
        x_start = np.random.randint(20, max(21, X - size_x - 20))

        mins = np.array([z_start, y_start, x_start], dtype=float)
        maxs = mins + np.array([size_z, size_y, size_x], dtype=float)
        boxes.append([mins, maxs])

    return np.array(boxes, dtype=float)


def download_celegans(base_dir: Path):
    """Download first volume from C. elegans Zenodo dataset (5942575)."""
    base_dir.mkdir(exist_ok=True)

    zip_name = "c_elegans_nuclei.zip"
    zip_url = "https://zenodo.org/api/records/5942575/files/c_elegans_nuclei.zip/content"
    zip_path = base_dir / zip_name

    if not zip_path.exists():
        print(f"⬇️  Downloading {zip_name}...")
        with requests.get(zip_url, stream=True, timeout=60) as response:
            response.raise_for_status()
            with open(zip_path, "wb") as outfile:
                for chunk in response.iter_content(chunk_size=65536):
                    if chunk:
                        outfile.write(chunk)

    raw_out = base_dir / "volume001_raw.tif"
    gt_out = base_dir / "volume001_gt.tif"
    if not raw_out.exists() or not gt_out.exists():
        with zipfile.ZipFile(zip_path) as archive:
            names = archive.namelist()
            train_images = sorted(
                name for name in names
                if "/train/images/" in name and name.lower().endswith(".tif")
            )
            train_masks = sorted(
                name for name in names
                if "/train/masks/" in name and name.lower().endswith(".tif")
            )
            if not train_images or not train_masks:
                raise RuntimeError("Could not find train image/mask TIFFs in C. elegans archive.")

            first_image = train_images[0]
            first_basename = Path(first_image).name
            mask_lookup = {Path(name).name: name for name in train_masks}
            if first_basename not in mask_lookup:
                raise RuntimeError(
                    f"No matching mask found for first training image {first_basename}."
                )

            if not raw_out.exists():
                with archive.open(first_image) as src, open(raw_out, "wb") as dst:
                    dst.write(src.read())

            if not gt_out.exists():
                with archive.open(mask_lookup[first_basename]) as src, open(gt_out, "wb") as dst:
                    dst.write(src.read())

    results = {"raw": raw_out, "gt": gt_out}

    return results


def compute_bboxes(mask_path: Path):
    """Compute axis-aligned 3D bounding boxes from instance masks."""
    masks = tifffile.imread(mask_path)
    labels = np.unique(masks)
    labels = labels[labels != 0]

    bboxes = []
    for label in labels:
        coords = np.argwhere(masks == label)
        if coords.size == 0:
            continue
        z0, y0, x0 = coords.min(axis=0)
        z1, y1, x1 = coords.max(axis=0)
        bboxes.append(np.array([[z0, y0, x0], [z1, y1, x1]], dtype=float))

    return np.array(bboxes, dtype=float)


def screenshot_single_view(output_path: Path):
    """Screenshot 1: Single viewer with bounding boxes."""
    if not HAS_PLUGIN:
        return

    print("📸 Creating Screenshot 1: Single View...")

    viewer = napari.Viewer(show=True)

    # Add demo data
    image_data = create_demo_data()
    viewer.add_image(image_data, name='3D Image', colormap='viridis',
                    contrast_limits=[0, 255])

    # Add bounding boxes
    from napari_turbobox import OptimizedBoundingBoxLayer
    bbox_layer = OptimizedBoundingBoxLayer(
        ndim=3,
        image_shape=image_data.shape,
        name='Bounding Boxes',
        edge_color='cyan',
        edge_width=2
    )
    viewer.add_layer(bbox_layer)

    boxes = create_demo_boxes(image_data.shape, n_boxes=8)
    bbox_layer.add_boxes(boxes)

    # Set nice viewing angle
    viewer.dims.set_point(0, image_data.shape[0] // 2)
    viewer.camera.zoom = 1.5

    # Process events to ensure rendering
    QApplication.processEvents()
    time.sleep(0.5)

    # Take screenshot
    screenshot = viewer.screenshot(canvas_only=False, flash=False)
    output_file = output_path / "Screenshot1_SingleView.png"

    import PIL.Image
    PIL.Image.fromarray(screenshot).save(output_file)
    print(f"✅ Saved to {output_file}")

    viewer.close()
    time.sleep(0.3)


def screenshot_multi_view(output_path: Path):
    """Screenshot 2: Multi-view synchronized annotation."""
    if not HAS_PLUGIN:
        return

    print("📸 Creating Screenshot 2: Multi-View Synchronization...")

    # Create 4 viewers (XY, XZ, YZ, 3D)
    viewer_xy = napari.Viewer(show=True, title='XY View (Axial)')
    viewer_xz = napari.Viewer(show=True, title='XZ View (Coronal)')
    viewer_yz = napari.Viewer(show=True, title='YZ View (Sagittal)')
    viewer_3d = napari.Viewer(show=True, title='3D View')

    # Add demo data to all viewers
    image_data = create_demo_data()

    for v in [viewer_xy, viewer_xz, viewer_yz, viewer_3d]:
        v.add_image(image_data, name='3D Image', colormap='gray',
                   contrast_limits=[0, 255])

    # Create synchronized bbox layers
    layers = create_synchronized_bbox_layers(
        main_viewer=viewer_xy,
        sub_viewers=[viewer_xz, viewer_yz, viewer_3d],
        image_shape=image_data.shape
    )

    # Add boxes
    boxes = create_demo_boxes(image_data.shape, n_boxes=6)
    layers[0].add_boxes(boxes)

    # Set viewing angles
    viewer_xy.dims.ndisplay = 2
    viewer_xy.dims.order = (0, 1, 2)  # ZYX
    viewer_xy.dims.set_point(0, image_data.shape[0] // 2)

    viewer_xz.dims.ndisplay = 2
    viewer_xz.dims.order = (1, 0, 2)  # YZX
    viewer_xz.dims.set_point(0, image_data.shape[1] // 2)

    viewer_yz.dims.ndisplay = 2
    viewer_yz.dims.order = (2, 0, 1)  # XZY
    viewer_yz.dims.set_point(0, image_data.shape[2] // 2)

    viewer_3d.dims.ndisplay = 3

    # Process and wait for rendering
    for _ in range(10):
        QApplication.processEvents()
        time.sleep(0.1)

    # Take screenshots of each view
    import PIL.Image
    for _i, (viewer, name) in enumerate([
        (viewer_xy, 'XY'),
        (viewer_xz, 'XZ'),
        (viewer_yz, 'YZ'),
        (viewer_3d, '3D')
    ]):
        screenshot = viewer.screenshot(canvas_only=True, flash=False)
        output_file = output_path / f"Screenshot2_MultiView_{name}.png"
        PIL.Image.fromarray(screenshot).save(output_file)
        print(f"✅ Saved {name} view to {output_file}")

    # Close all viewers
    for v in [viewer_xy, viewer_xz, viewer_yz, viewer_3d]:
        v.close()
    time.sleep(0.3)


def screenshot_control_panel(output_path: Path):
    """Screenshot 3: Control panel widget."""
    if not HAS_PLUGIN:
        return

    print("📸 Creating Screenshot 3: Control Panel...")

    viewer = napari.Viewer(show=True)

    # Add demo data
    image_data = create_demo_data(shape=(30, 200, 200))
    viewer.add_image(image_data, name='3D Image')

    # Add bbox layer
    from napari_turbobox import OptimizedBoundingBoxLayer
    bbox_layer = OptimizedBoundingBoxLayer(
        ndim=3,
        image_shape=image_data.shape,
        name='Bounding Boxes'
    )
    viewer.add_layer(bbox_layer)

    # Add control widget
    from napari_turbobox.widget import BoundingBoxControlWidget
    widget = BoundingBoxControlWidget(viewer)
    viewer.window.add_dock_widget(widget, area='right', name='BBox Controls')

    # Add a few boxes
    boxes = create_demo_boxes(image_data.shape, n_boxes=3)
    bbox_layer.add_boxes(boxes)

    # Select first box
    if len(bbox_layer.bounding_boxes) > 0:
        bbox_layer.selected_data = {0}

    QApplication.processEvents()
    time.sleep(0.5)

    # Take screenshot
    screenshot = viewer.screenshot(canvas_only=False, flash=False)
    output_file = output_path / "Screenshot3_ControlPanel.png"

    import PIL.Image
    PIL.Image.fromarray(screenshot).save(output_file)
    print(f"✅ Saved to {output_file}")

    viewer.close()
    time.sleep(0.3)


def screenshot_celegans_multiview(output_path: Path):
    """Screenshot 5: C. elegans 2x2 multi-view with GT-derived bounding boxes."""
    if not HAS_PLUGIN:
        return

    print("📸 Creating Screenshot 5: C. elegans Multi-View...")

    from qtpy.QtCore import Qt
    from qtpy.QtWidgets import QDockWidget, QGridLayout, QMainWindow, QWidget

    dataset_dir = output_path / "celegans_data"
    paths = download_celegans(dataset_dir)

    raw = tifffile.imread(paths["raw"])
    bboxes = compute_bboxes(paths["gt"])
    if bboxes.size == 0:
        raise RuntimeError("No bounding boxes were computed from C. elegans ground truth.")

    def best_slice_for_axis(axis: int, axis_size: int) -> int:
        # Pick the slice where the highest number of 3D boxes intersects the plane.
        mins = bboxes[:, 0, axis]
        maxs = bboxes[:, 1, axis]
        intersections = [np.count_nonzero((mins <= idx) & (maxs >= idx)) for idx in range(axis_size)]
        return int(np.argmax(intersections))

    viewer_xy = napari.Viewer(show=False, title="XY (Axial)")
    viewer_xz = napari.Viewer(show=False, title="XZ (Coronal)")
    viewer_yz = napari.Viewer(show=False, title="YZ (Sagittal)")
    viewer_3d = napari.Viewer(show=False, title="3D View")
    viewers = [viewer_xy, viewer_xz, viewer_yz, viewer_3d]

    intensity_limits = [float(np.percentile(raw, 1)), float(np.percentile(raw, 99.5))]
    for viewer in viewers:
        viewer.add_image(raw, name="C. elegans Raw", colormap="gray", contrast_limits=intensity_limits)

    layers = create_synchronized_bbox_layers(
        main_viewer=viewer_xy,
        sub_viewers=[viewer_xz, viewer_yz, viewer_3d],
        image_shape=raw.shape,
    )
    layers[0].add_boxes(bboxes)

    for layer in layers:
        if hasattr(layer, "edge_color"):
            layer.edge_color = "cyan"
        if hasattr(layer, "edge_width"):
            layer.edge_width = 3.5
        if hasattr(layer, "out_of_slice_display"):
            layer.out_of_slice_display = True

    z_slice = best_slice_for_axis(0, raw.shape[0])
    y_slice = best_slice_for_axis(1, raw.shape[1])
    x_slice = best_slice_for_axis(2, raw.shape[2])

    viewer_xy.dims.ndisplay = 2
    viewer_xy.dims.order = (0, 1, 2)
    viewer_xy.dims.set_point(0, z_slice)
    viewer_xy.camera.zoom = 0.95

    viewer_xz.dims.ndisplay = 2
    viewer_xz.dims.order = (1, 0, 2)
    viewer_xz.dims.set_point(1, y_slice)
    viewer_xz.camera.zoom = 0.85

    viewer_yz.dims.ndisplay = 2
    # True YZ view: display (Z, Y), hide X.
    viewer_yz.dims.order = (2, 0, 1)
    viewer_yz.dims.set_point(2, x_slice)
    viewer_yz.camera.zoom = 0.9

    viewer_3d.dims.ndisplay = 3
    viewer_3d.camera.angles = (22, -28, 135)
    viewer_3d.camera.zoom = 0.52

    # Work around a sporadic initial sync race in embedded sub-viewers.
    # Geometry exists, but XZ/YZ can remain visually empty until first user slice move.
    for layer in layers[1:]:
        layer._sync_shapes_from_bboxes()

    main_window = QMainWindow()
    main_window.resize(1800, 1100)
    main_window.setWindowTitle("napari-turbobox Multi-View Workflow (C. elegans)")

    grid_widget = QWidget()
    layout = QGridLayout(grid_widget)
    layout.setContentsMargins(2, 2, 2, 2)
    layout.setSpacing(2)
    layout.addWidget(viewer_xy.window.qt_viewer, 0, 0)
    layout.addWidget(viewer_xz.window.qt_viewer, 0, 1)
    layout.addWidget(viewer_yz.window.qt_viewer, 1, 0)
    layout.addWidget(viewer_3d.window.qt_viewer, 1, 1)
    main_window.setCentralWidget(grid_widget)

    import napari_turbobox.widget as bbox_widget_module

    if not hasattr(bbox_widget_module, "logger"):
        bbox_widget_module.logger = logging.getLogger(__name__)

    control_widget = bbox_widget_module.BoundingBoxControlWidget(viewer_xy)
    dock = QDockWidget("BBox Controls", main_window)
    dock.setWidget(control_widget)
    dock.setFeatures(QDockWidget.DockWidgetFloatable | QDockWidget.DockWidgetMovable)
    main_window.addDockWidget(Qt.RightDockWidgetArea, dock)

    main_window.show()

    for _ in range(30):
        QApplication.processEvents()
        time.sleep(0.1)

    pixmap = main_window.grab()
    output_file = output_path / "Screenshot5_CElegans_MultiView.png"
    pixmap.save(str(output_file))

    try:
        from PIL import Image

        with Image.open(output_file) as image:
            image.save(output_file, dpi=(300, 300))
    except Exception as exc:
        print(f"⚠️  Could not enforce 300 DPI metadata: {exc}")

    print(f"✅ Saved C. elegans multiview to {output_file}")

    main_window.close()
    for viewer in viewers:
        viewer.close()


def create_composite_figure(output_path: Path):
    """Create a composite figure combining multiple screenshots."""
    import PIL.Image
    from PIL import ImageDraw, ImageFont

    screenshots = [
        output_path / "Screenshot1_SingleView.png",
        output_path / "Screenshot2_MultiView_XY.png",
        output_path / "Screenshot2_MultiView_3D.png",
    ]

    # Check if all screenshots exist
    if not all(f.exists() for f in screenshots):
        print("⚠️  Not all screenshots available for composite")
        return

    print("📸 Creating composite figure...")

    # Load images
    images = [PIL.Image.open(f) for f in screenshots]

    # Resize to consistent height
    target_height = 400
    images_resized = []
    for img in images:
        aspect = img.width / img.height
        new_width = int(target_height * aspect)
        images_resized.append(img.resize((new_width, target_height), PIL.Image.Resampling.LANCZOS))

    # Create composite (horizontal layout)
    total_width = sum(img.width for img in images_resized) + 20 * (len(images_resized) - 1)
    composite = PIL.Image.new('RGB', (total_width, target_height + 50), 'white')

    # Paste images
    x_offset = 0
    labels = ['A', 'B', 'C']
    draw = ImageDraw.Draw(composite)

    try:
        font = ImageFont.truetype("Arial.ttf", 24)
    except:
        font = ImageFont.load_default()

    for img, label in zip(images_resized, labels):
        composite.paste(img, (x_offset, 40))

        # Add label
        draw.text((x_offset + 10, 10), label, fill='black', font=font)

        x_offset += img.width + 20

    output_file = output_path / "Figure_GUI_Composite.png"
    composite.save(output_file, dpi=(300, 300))
    print(f"✅ Saved composite to {output_file}")


def generate_all_screenshots(output_dir: str = "."):
    """Generate all GUI screenshots for the paper."""
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)

    print("=" * 80)
    print("GENERATING GUI SCREENSHOTS FOR PAPER")
    print("=" * 80)

    if not HAS_PLUGIN:
        print("\n❌ napari-turbobox not installed!")
        print("   Install with: pip install -e .")
        return

    print("\nNote: This will open napari windows. Please do not interact.")
    print("Screenshots will be captured automatically.\n")

    time.sleep(2)

    try:
        screenshot_single_view(output_path)
        time.sleep(1)

        screenshot_multi_view(output_path)
        time.sleep(1)

        screenshot_control_panel(output_path)
        time.sleep(1)

        screenshot_combined_grid(output_path)
        time.sleep(1)

        screenshot_celegans_multiview(output_path)
        time.sleep(1)

        create_composite_figure(output_path)

    except Exception as e:
        print(f"\\n❌ Error during screenshot generation: {e}")
        import traceback
        traceback.print_exc()

    print("\\n" + "=" * 80)
    print("✅ SCREENSHOT GENERATION COMPLETE")
    print("=" * 80)
    print(f"\\nScreenshots saved to: {output_path.absolute()}")
    print("\\nFor paper figures:")
    print("• Use high-resolution screenshots")
    print("• Add annotations/labels in Inkscape or Illustrator")
    print("• Ensure all UI elements are clearly visible")
    print("• Consider creating a multi-panel figure")


def screenshot_combined_grid(output_path: Path):
    """Screenshot 4: Combined 2x2 grid view integrated into a main window."""
    if not HAS_PLUGIN:
        return

    print("📸 Creating Screenshot 4: Combined 2x2 Grid with Controls...")

    from qtpy.QtCore import Qt
    from qtpy.QtWidgets import QDockWidget, QGridLayout, QMainWindow, QWidget

    # Create viewers (hidden initially)
    viewer_xy = napari.Viewer(show=False, title='XY (Axial)')
    viewer_xz = napari.Viewer(show=False, title='XZ (Coronal)')
    viewer_yz = napari.Viewer(show=False, title='YZ (Sagittal)')
    viewer_3d = napari.Viewer(show=False, title='3D View')

    viewers = [viewer_xy, viewer_xz, viewer_yz, viewer_3d]

    # Add demo data
    image_data = create_demo_data()
    for v in viewers:
        v.add_image(image_data, name='3D Image', colormap='gray', contrast_limits=[0, 255])

    # Synchronize
    layers = create_synchronized_bbox_layers(
        main_viewer=viewer_xy,
        sub_viewers=[viewer_xz, viewer_yz, viewer_3d],
        image_shape=image_data.shape
    )

    # Add boxes
    boxes = create_demo_boxes(image_data.shape, n_boxes=8)
    layers[0].add_boxes(boxes)

    # Configure views
    viewer_xy.dims.ndisplay = 2
    viewer_xy.dims.order = (0, 1, 2)
    viewer_xy.dims.set_point(0, image_data.shape[0] // 2)
    viewer_xy.camera.zoom = 1.2

    viewer_xz.dims.ndisplay = 2
    viewer_xz.dims.order = (1, 0, 2)
    viewer_xz.dims.set_point(0, image_data.shape[1] // 2)
    viewer_xz.camera.zoom = 1.2

    viewer_yz.dims.ndisplay = 2
    viewer_yz.dims.order = (2, 0, 1)
    viewer_yz.dims.set_point(0, image_data.shape[2] // 2)
    viewer_yz.camera.zoom = 1.2

    viewer_3d.dims.ndisplay = 3
    viewer_3d.camera.zoom = 1.0

    # --- Create Custom Main Window ---
    main_window = QMainWindow()
    main_window.resize(1600, 1000)
    main_window.setWindowTitle("napari-turbobox Multi-View Workflow")

    # 1. Central Widget: 2x2 Grid
    grid_widget = QWidget()
    layout = QGridLayout(grid_widget)
    layout.setContentsMargins(2, 2, 2, 2)
    layout.setSpacing(2)

    layout.addWidget(viewer_xy.window.qt_viewer, 0, 0)
    layout.addWidget(viewer_xz.window.qt_viewer, 0, 1)
    layout.addWidget(viewer_yz.window.qt_viewer, 1, 0)
    layout.addWidget(viewer_3d.window.qt_viewer, 1, 1)

    main_window.setCentralWidget(grid_widget)

    # 2. Right Dock: Control Widget
    from napari_turbobox.widget import BoundingBoxControlWidget
    control_widget = BoundingBoxControlWidget(viewer_xy)  # Control main viewer

    dock = QDockWidget("BBox Controls", main_window)
    dock.setWidget(control_widget)
    dock.setFeatures(QDockWidget.DockWidgetFloatable | QDockWidget.DockWidgetMovable)
    main_window.addDockWidget(Qt.RightDockWidgetArea, dock)

    # Show and capture
    main_window.show()

    # Process events
    for _ in range(20):
        QApplication.processEvents()
        time.sleep(0.1)

    # Take screenshot
    pixmap = main_window.grab()
    output_file = output_path / "Screenshot4_CombinedGrid.png"
    pixmap.save(str(output_file))
    print(f"✅ Saved integrated grid view to {output_file}")

    # Cleanup
    main_window.close()
    for v in viewers:
        v.close()

    print("\n" + "=" * 80)
    print("✅ SCREENSHOT GENERATION COMPLETE")
    print("=" * 80)
    print(f"\nScreenshots saved to: {output_path.absolute()}")
    print("\nFor paper figures:")
    print("• Use high-resolution screenshots")
    print("• Add annotations/labels in Inkscape or Illustrator")
    print("• Ensure all UI elements are clearly visible")
    print("• Consider creating a multi-panel figure")


if __name__ == "__main__":
    # Requires scipy for demo data generation
    try:
        import scipy
    except ImportError:
        print("⚠️  scipy required for demo data generation")
        print("   Install with: pip install scipy")
        exit(1)

    generate_all_screenshots(output_dir=".")
