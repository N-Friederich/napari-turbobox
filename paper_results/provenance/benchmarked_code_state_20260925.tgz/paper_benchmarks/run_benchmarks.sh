#!/bin/bash
# Reproduce every paper benchmark number and figure from tracked files.
#
# There is exactly ONE pipeline:
#   drag_session_benchmark.py  -> per-replicate latency CSVs (panels a + b)
#   memory_benchmark.py        -> total + data-structure memory CSVs (panel c)
#   resolution_benchmark.py    -> resolution-independence CSV (supp S2, modern only)
#   make_final_figures.py      -> k=5 aggregation (Welch + bootstrap CI) + figures
#
# Run ONCE PER ENVIRONMENT. napari-bbox needs the legacy env; napari-turbobox the
# modern env. Run the LEGACY env first, then the MODERN env (the modern run does
# the final aggregation + figures, which need both tools' data):
#
#   conda activate legacy-napari && ./run_benchmarks.sh   # writes legacy_* CSVs
#   conda activate mdoern-napari  && ./run_benchmarks.sh   # writes modern_* CSVs + figures
#
# Optional first arg: output dir (default <repo>/paper_results). Numbers are final
# and committed; re-running overwrites them in place.

set -e
cd "$(dirname "$0")/.."                       # repo root: scripts run as -m paper_benchmarks.*
REPO_ROOT="$(pwd)"
N_REPLICATES=5

echo "=============================================="
echo "NAPARI-TURBOBOX BENCHMARK SUITE"
echo "=============================================="

if python -c "import napari_turbobox" 2>/dev/null; then
    echo "✅ Detected: napari-turbobox (modern)"
    TOOL="modern"
elif python -c "from napari_bbox import BoundingBoxLayer" 2>/dev/null; then
    echo "✅ Detected: napari-bbox (legacy)"
    TOOL="legacy"
else
    echo "❌ No plugin detected!"
    exit 1
fi

OUTPUT_DIR="${1:-$REPO_ROOT/paper_results}"
mkdir -p "$OUTPUT_DIR"
echo "📂 Output directory: $OUTPUT_DIR"

echo ""
echo "📊 Drag-session latency ($TOOL): $N_REPLICATES replicates x panels (a) N-sweep + (b) V-sweep..."
for r in $(seq 0 $((N_REPLICATES - 1))); do
    python -m paper_benchmarks.drag_session_benchmark --tool "$TOOL" --replicate "$r" --out "$OUTPUT_DIR"
done

echo ""
echo "📊 Memory (total + data structure) ($TOOL)..."
python -m paper_benchmarks.memory_benchmark --output "$OUTPUT_DIR"

if [[ "$TOOL" == "modern" ]]; then
    echo ""
    echo "📊 Resolution independence (modern, supp S2)..."
    python -m paper_benchmarks.resolution_benchmark --out "$OUTPUT_DIR"

    echo ""
    echo "📊 Aggregating k=5 (Welch + bootstrap CI) and building figures..."
    echo "   (requires the legacy run to have completed first)"
    python -m paper_benchmarks.make_final_figures --results "$OUTPUT_DIR" --out "$OUTPUT_DIR"
fi

echo ""
echo "=============================================="
echo "✅ DONE ($TOOL). Output: $OUTPUT_DIR"
echo "=============================================="
