"""Resolution-independence benchmark (supplementary figure S2).

Per-update latency vs background image size at fixed N=100, V=4 (modern), using
the SAME real-viewer drag-session protocol as ``drag_session_benchmark.py``.
This isolates the plugin's sync + geometry cost: GPU rasterization (which would
scale with image size) is napari/vispy, not the plugin, and is excluded by the
headless measurement. Expectation: flat latency across 128..2048 px/side.

Run (modern env)::

    python -m paper_benchmarks.resolution_benchmark --out paper_results

Output: ``benchmark_resolution.csv`` (image_xy, sub_median_ms, sub_p95_ms),
consumed by ``make_final_figures.py`` (supplementary S2).
"""

from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path

import numpy as np

os.environ.pop("QT_QPA_PLATFORM", None)
from qtpy.QtWidgets import QApplication

from paper_benchmarks.drag_session_benchmark import (
    measure_drag_session,
    setup_modern,
)

N_BOXES = 100
N_VIEWERS = 4
N_DRAGS = 12
SIZES = [128, 256, 512, 1024, 2048]


def measure_resolution(image_xy: int) -> dict:
    """Median per-update latency for one background resolution (N=100, V=4)."""
    shape = (100, image_xy, image_xy)
    adapter, viewers, _layers, current = setup_modern(
        N_BOXES, N_VIEWERS, shape, orthogonal=True, with_3d=False
    )
    for _ in range(50):
        QApplication.processEvents()
    subs: list[float] = []
    for d in range(N_DRAGS):
        s, _c = measure_drag_session(adapter, d, N_BOXES, current, shape)
        subs.extend(s)
    for v in viewers:
        v.close()
    return {"image_xy": image_xy, "n_boxes": N_BOXES, "n_viewers": N_VIEWERS,
                "sub_median_ms": float(np.median(subs)), "sub_p95_ms": float(np.percentile(subs, 95))}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default="paper_results")
    args = ap.parse_args()
    _app = QApplication.instance() or QApplication([])

    rows = []
    for xy in SIZES:
        r = measure_resolution(xy)
        rows.append(r)
        print(f"  image={xy:>4}x{xy:<4}: median={r['sub_median_ms']:6.2f} "
              f"p95={r['sub_p95_ms']:6.2f} ms", flush=True)

    Path(args.out).mkdir(parents=True, exist_ok=True)
    path = os.path.join(args.out, "benchmark_resolution.csv")
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["image_xy", "n_boxes", "n_viewers",
                                          "sub_median_ms", "sub_p95_ms"])
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {path}")


if __name__ == "__main__":
    main()
