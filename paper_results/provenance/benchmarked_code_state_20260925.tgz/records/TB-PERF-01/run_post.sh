#!/bin/bash
# TB-PERF-01 POST: panel (c) memory and panel (f) resolution on the final code, same env as run_final.sh.
set -u
R=<redacted>
cd $R
BB=$R/records/TB-REV-02/envs/bb011_n070/bin/python
LOCK="$BB $R/records/TB-REV-02/scripts/with_lock.py"
LOG=$R/records/TB-PERF-01/logs/final_v2
mkdir -p $LOG
export PYTHONDONTWRITEBYTECODE=1
unset PYTHONPATH
mkdir -p $R/paper_results_v2/resolution $R/paper_results_v2/memory
: "${TB_THUMBS:?}" "${PACING:?}" "${EDIT_VIEW:?}"
export EDIT_VIEW
$LOCK --tag POST-RES -- /bin/bash -c "cd $R && PYTHONPATH=src:. $BB records/TB-PERF-01/resolution_final.py paper_results_v2/resolution > $LOG/POST-RES.log 2>&1"; rc_res=$?
echo "$(date +%H:%M) POST-RES rc=$rc_res"
$LOCK --tag POST-MEM -- /bin/bash -c "cd $R && PYTHONPATH=src:. $BB records/TB-PERF-01/memory_final.py paper_results_v2/memory > $LOG/POST-MEM.log 2>&1"; rc_mem=$?
echo "$(date +%H:%M) POST-MEM rc=$rc_mem"
echo "$(date +%H:%M) POST DONE"
[ $rc_res -eq 0 ] && [ $rc_mem -eq 0 ]
