#!/bin/bash
# TB-PERF-02 FINAL run on the fixed code. One environment for both tools (bb011_n070: napari 0.7.0,
# napari-bbox 0.1.1, PyQt6, bermuda). Protocol: xy_visible drags, XZ/YZ views follow the dragged box
# (--ortho-follow), one untimed warm-up drag per configuration, pacing $PACING, thumbnails as decided.
# Every process waits for AC power, runs under caffeinate and is checked against the pmset log;
# a run with a sleep/battery event is moved aside and repeated once. Usage:
#   TB_THUMBS=on|off BB_SYNC=per_box|per_box_nothumb|per_box_quiet PACING=sleep|spin EDIT_VIEW=api|mouse [STAGES="large main sleep post tut"] run_final_v2.sh
# EDIT_VIEW=mouse: both tools drag the box in the XY view through napari's mouse dispatch and their own
# drag handlers (napari-bbox: needs BB_SYNC=per_box_nothumb or per_box_quiet for the other views).
# Final configuration: TB_THUMBS=off BB_SYNC=per_box_quiet PACING=spin EDIT_VIEW=mouse.
# Stop cleanly between processes: touch records/TB-PERF-01/STOP (the running process finishes first).
set -u
: "${TB_THUMBS:?}" "${BB_SYNC:?}" "${PACING:?}" "${EDIT_VIEW:?}"
export EDIT_VIEW
STAGES="${STAGES:-large main sleep post tut}"
MAIN_DRAGS="${MAIN_DRAGS:-50}"   # preliminary run: MAIN_DRAGS=10 MAIN_DIR=main_prelim
MAIN_DIR="${MAIN_DIR:-main}"
LARGE_DRAGS="${LARGE_DRAGS:-50}"  # preliminary run: LARGE_DRAGS=10 LARGE_DIR=large_n_prelim
LARGE_DIR="${LARGE_DIR:-large_n}"
[ -e $(dirname "$0")/STOP ] && { echo "refusing to run: $(dirname "$0")/STOP exists (remove it first)"; exit 1; }
# refuse to run with reduced priority (e.g. started with & in zsh, which nices background jobs)
[ "$(ps -o nice= -p $$ | tr -d ' ')" = 0 ] || { echo "refusing to run: nice=$(ps -o nice= -p $$)"; exit 1; }
R=<redacted>
cd $R
BB=$R/records/TB-REV-02/envs/bb011_n070/bin/python
LOCK="$BB $R/records/TB-REV-02/scripts/with_lock.py"
LOG=$R/records/TB-PERF-01/logs/final_v2
V=$R/paper_results_v2
mkdir -p $LOG $V/$MAIN_DIR $V/$LARGE_DIR $V/sleep_pacing $V/sleep_pacing_spin $V/tutorial_full
caffeinate -dims -w $$ &  # no idle/display/system sleep while the driver runs (not even between processes)
export PYTHONDONTWRITEBYTECODE=1
unset PYTHONPATH
# code state of this run set (the sidecars also record it per process)
(git diff 1b2ba33 -- src paper_benchmarks > $V/code_state_vs_1b2ba33.patch; git ls-files --others --exclude-standard src paper_benchmarks > $V/code_state_untracked.txt)
HB="-m paper_benchmarks.drag_session_benchmark --drag-protocol xy_visible --ortho-follow --warmup 1"
H="$HB --pacing $PACING"
EV="--edit-view $EDIT_VIEW"
MS=$([ $EDIT_VIEW = mouse ] && echo -mouse)
TB="--tool modern --thumbnails $TB_THUMBS $EV"
LG="--tool legacy --legacy-sync $BB_SYNC $EV"
tagfile() {  # expected file tag of a run tag (for skipping finished runs on a restart)
  case $1 in
    *-SLEEP-TB-*) echo "modern-xy_visible$([ $TB_THUMBS = on ] && echo -thumbs_on)-follow-warm1$MS";;
    *-SLEEP-BB-*) echo "legacy-${BB_SYNC}-xy_visible-follow-warm1$MS";;
    *-TB-*) echo "modern-xy_visible$([ $TB_THUMBS = on ] && echo -thumbs_on)-follow-warm1$([ $PACING = spin ] && echo -spin)$MS";;
    *-TUT-*) echo "legacy-xy_visible-follow-warm1$([ $PACING = spin ] && echo -spin)";;
    *) echo "legacy-${BB_SYNC}-xy_visible-follow-warm1$([ $PACING = spin ] && echo -spin)$MS";;
  esac
}
wait_ac() { until pmset -g batt | grep -q "AC Power"; do echo "$(date +%H:%M) waiting for AC power"; sleep 30; done; }
stop_requested() { [ -e $R/records/TB-PERF-01/STOP ]; }
run() {  # tag outdir args...  (RUN_H overrides the harness prefix for one stage)
  tag=$1; out=$2; shift 2
  local HH="${RUN_H:-$H}"
  if stop_requested; then echo "$(date +%H:%M) $tag skipped (STOP)"; return; fi
  if [ -n "$(ls $out/drag_session_*_rep*.csv 2>/dev/null | grep -F "_rep${tag##*-r}.csv" | grep -F "$(tagfile $tag)")" ]; then
    echo "$(date +%H:%M) $tag skipped (result exists)"; return
  fi
  for attempt in 1 2; do
    wait_ac
    t0=$(date +%s)
    before=$(ls $out 2>/dev/null)
    { echo "load at start: $(sysctl -n vm.loadavg)"; } > $LOG/$tag.power
    caffeinate -dims $LOCK --tag $tag -- /bin/bash -c "cd $R && PYTHONPATH=src $BB $HH $* --out $out > $LOG/$tag.log 2>&1"
    rc=$?
    { echo "load at end: $(sysctl -n vm.loadavg)"; } >> $LOG/$tag.power
    if [ $rc -eq 0 ] && /usr/bin/python3 $R/records/TB-PERF-01/sleep_check.py $t0 $(date +%s) >> $LOG/$tag.power 2>&1; then
      echo "$(date +%H:%M) $tag rc=$rc clean"; return
    fi
    echo "$(date +%H:%M) $tag rc=$rc INVALID (crash, sleep or battery), attempt $attempt"
    mkdir -p $V/_superseded_protocol/_invalid_v2/$tag-a$attempt
    for f in $(ls $out); do echo "$before" | grep -qxF "$f" || mv -n $out/$f $V/_superseded_protocol/_invalid_v2/$tag-a$attempt/; done
    mv $LOG/$tag.log $LOG/INVALID-$tag-a$attempt.log; mv $LOG/$tag.power $LOG/INVALID-$tag-a$attempt.power
  done
  echo "$(date +%H:%M) $tag INVALID twice - aborting the run for a person to decide"; touch $V/ABORTED; exit 1
}
# 1) large N (first, so N = 10^4 is in hand early) (Figure 3a/d): N = 2000/5000/10000, k = 5 x 10 drags
[[ " $STAGES " == *" large "* ]] && for r in 0 1 2 3 4; do
  run FIN2-LARGE-TB-r$r $V/$LARGE_DIR $TB --panels a --ns 2000,5000,10000 --drags $LARGE_DRAGS --replicate $r
  run FIN2-LARGE-BB-r$r $V/$LARGE_DIR $LG --panels a --ns 2000,5000,10000 --drags $LARGE_DRAGS --replicate $r
done
echo "$(date +%H:%M) LARGE DONE"
# 2) main: panels a (N = 10..1000) + b, k = 5 x 50 drags, tools interleaved per replicate
[[ " $STAGES " == *" main "* ]] && for r in 0 1 2 3 4; do
  run FIN2-MAIN-TB-r$r $V/$MAIN_DIR $TB --drags $MAIN_DRAGS --replicate $r
  run FIN2-MAIN-BB-r$r $V/$MAIN_DIR $LG --drags $MAIN_DRAGS --replicate $r
done
echo "$(date +%H:%M) MAIN DONE"
# 3) pacing sensitivity: the same protocol with idle waiting (sleep) between moves, k = 3 x 10 drags,
#    panel a N = 10/100/1000/10000 and panel b, each replicate followed by a matched busy-waiting control
[[ " $STAGES " == *" sleep "* ]] && for r in 0 1 2; do
  RUN_H="$HB --pacing sleep" run FIN2-SLEEP-TB-r$r $V/sleep_pacing $TB --ns 10,100,1000,10000 --drags 10 --replicate $r
  RUN_H="$HB --pacing sleep" run FIN2-SLEEP-BB-r$r $V/sleep_pacing $LG --ns 10,100,1000,10000 --drags 10 --replicate $r
  # matched busy-waiting control (same drags, same order in time), for a clean per-tool sleep-vs-spin comparison
  RUN_H="$HB --pacing spin" run FIN2-SPINCTL-TB-r$r $V/sleep_pacing_spin $TB --ns 10,100,1000,10000 --drags 10 --replicate $r
  RUN_H="$HB --pacing spin" run FIN2-SPINCTL-BB-r$r $V/sleep_pacing_spin $LG --ns 10,100,1000,10000 --drags 10 --replicate $r
done
unset RUN_H
echo "$(date +%H:%M) SLEEP DONE"
# 4) panels c and f (memory; image size with the same pacing/thumbnail settings)
if [[ " $STAGES " == *" post "* ]] && ! stop_requested && [ ! -s $V/memory/benchmark_memory.csv -o ! -s $V/resolution/benchmark_resolution.csv ]; then
  for attempt in 1 2; do
    wait_ac; t0=$(date +%s)
    PACING=$PACING TB_THUMBS=$TB_THUMBS EDIT_VIEW=$EDIT_VIEW caffeinate -dims $R/records/TB-PERF-01/run_post.sh > $LOG/post.out 2>&1; rc=$?
    if [ $rc -eq 0 ] && /usr/bin/python3 $R/records/TB-PERF-01/sleep_check.py $t0 $(date +%s) > $LOG/POST.power 2>&1; then
      echo "$(date +%H:%M) POST rc=$rc clean"; break
    fi
    echo "$(date +%H:%M) POST rc=$rc INVALID (crash, sleep or battery), attempt $attempt"
    mkdir -p $V/_superseded_protocol/_invalid_v2/POST-a$attempt
    mv -n $V/memory $V/resolution $LOG/post.out $LOG/POST.power $V/_superseded_protocol/_invalid_v2/POST-a$attempt/ 2>/dev/null
    mkdir -p $V/memory $V/resolution
    if [ $attempt -eq 2 ]; then echo "$(date +%H:%M) POST INVALID twice - aborting"; touch $V/ABORTED; exit 1; fi
  done
fi
# 5) full-reassignment baseline (napari's multiple-viewer example pattern), panel a N <= 1000, k = 3 x 10 drags
[[ " $STAGES " == *" tut "* ]] && for r in 0 1 2; do
  run FIN2-TUT-BB-r$r $V/tutorial_full --tool legacy --legacy-sync full --edit-view api --panels a --drags 10 --replicate $r
done
echo "$(date +%H:%M) FINAL DONE"
