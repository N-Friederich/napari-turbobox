"""Event helpers for batching bounding box updates."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Protocol
from weakref import WeakSet


class BoundingBoxSubscriber(Protocol):
    """Protocol for listeners interested in bbox updates."""

    def handle_event(self, event_type: str, payload) -> None: ...


@dataclass
class _QueuedEvent:
    event_type: str
    payload: object


class BoundingBoxEventManager:
    """Lightweight pub/sub manager with optional batching."""

    def __init__(self) -> None:
        self._subscribers: WeakSet[BoundingBoxSubscriber] = WeakSet()
        self._batch_stack = 0
        self._queued_events: list[_QueuedEvent] = []

    def subscribe(self, subscriber: BoundingBoxSubscriber) -> None:
        self._subscribers.add(subscriber)

    def unsubscribe(self, subscriber: BoundingBoxSubscriber) -> None:
        try:
            self._subscribers.remove(subscriber)
        except KeyError:
            pass

    def emit(self, event_type: str, payload) -> None:
        if self._batch_stack:
            self._queued_events.append(_QueuedEvent(event_type, payload))
            return
        for subscriber in list(self._subscribers):
            subscriber.handle_event(event_type, payload)

    @contextmanager
    def batch(self) -> Iterator[None]:
        """Group multiple events into a single emission cycle."""
        self._batch_stack += 1
        try:
            yield
        finally:
            self._batch_stack = max(0, self._batch_stack - 1)
            if self._batch_stack == 0 and self._queued_events:
                unique_events = {}
                for event in self._queued_events:
                    unique_events[event.event_type] = event
                self._queued_events.clear()
                for event in unique_events.values():
                    self.emit(event.event_type, event.payload)
