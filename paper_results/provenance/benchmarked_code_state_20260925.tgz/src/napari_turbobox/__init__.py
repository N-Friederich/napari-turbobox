"""
napari-TurboBox
===============

Synchronized multi-viewer bounding-box annotation for napari >= 0.6.6 (npe2
plugin). Boxes are axis-aligned and have 2 or 3 spatial axes.

Features
--------
- **TurboBoxLayer**: napari Shapes layer that renders the boxes of a
  ``BBoxDataStore`` (slice rectangles in 2D views, one wireframe per box in 3D)
- **Multi-viewer sync**: ``create_synchronized_bbox_layers`` shares one store
  between an editable layer and read-only layers in other viewers
- **Interactive editing**: drag to move; Shift+drag or drag near an edge to resize
- **3D navigation**: boxes are shown on the slices they intersect
- **Control panel**: widget to add, list, delete, import and export boxes
  (native .npy/.json, per-slice COCO JSON, per-slice YOLO)

Usage
-----
Synchronized layers in several viewers::

    from napari_turbobox import create_synchronized_bbox_layers

    layers = create_synchronized_bbox_layers(
        main_viewer, [viewer_xz, viewer_yz, viewer_3d], image_shape=(10, 512, 512)
    )
    layers[0].add_boxes([[[z_min, y_min, x_min], [z_max, y_max, x_max]]])

One layer in the current viewer (shape, scale and translation are taken from
an image layer)::

    from napari_turbobox import create_nd_bbox_layer

    layer = create_nd_bbox_layer(viewer)

Or open the control panel from napari's Plugins menu:
"BBox Control Panel (napari-TurboBox)".

Components
----------
TurboBoxLayer
    Layer class extending napari's Shapes layer with bbox-specific functionality

BBoxDataStore
    Shared (N, 2, D) box store that notifies the layers of all viewers

create_synchronized_bbox_layers
    Creates one editable and several read-only layers sharing one store

create_nd_bbox_layer
    Factory function to create a bbox layer in a viewer

create_control_panel
    Factory function to create the control widget for managing bboxes

BoundingBoxControlWidget
    Qt widget providing UI controls for bbox management
"""

import warnings

from ._factory import create_control_panel, create_nd_bbox_layer
from .data_store import BBoxDataStore
from .layer import TurboBoxLayer
from .multi_view import create_synchronized_bbox_layers, sync_existing_layer_to_viewers
from .widget import BoundingBoxControlWidget


# Deprecated alias for backwards compatibility
class OptimizedBoundingBoxLayer(TurboBoxLayer):
    """Deprecated alias for TurboBoxLayer."""

    def __init__(self, *args, **kwargs):
        warnings.warn(
            "OptimizedBoundingBoxLayer is deprecated and will be removed in a future version. "
            "Please use TurboBoxLayer instead.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        super().__init__(*args, **kwargs)


__all__ = [
    "BBoxDataStore",
    "BoundingBoxControlWidget",
    "OptimizedBoundingBoxLayer",
    "TurboBoxLayer",
    "create_control_panel",
    "create_nd_bbox_layer",
    "create_synchronized_bbox_layers",
    "sync_existing_layer_to_viewers",
]
