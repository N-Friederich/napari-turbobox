"""Export TurboBox bounding boxes to AI-ready 2D detection formats.

COCO and YOLO are **2D, per-image** annotation formats, while TurboBox boxes
are nD axis-aligned boxes (typically 3D, spanning a z-range). The 3D->2D
projection policy is therefore made explicit and selectable:

- ``mode="per_slice"`` (default): each 3D box emits one 2D annotation on every
  integer slice it **fully covers** -- ``ceil(z_min) .. floor(z_max)``
  inclusive -- all sharing the same ``(x, y, w, h)`` and category. This is the
  artifact of the per-slice 2D-prompt workflow: place one 3D box, decompose it
  into per-slice 2D box prompts, run a 2D box-promptable model slice-by-slice
  (e.g. nnInteractive, whose box prompt is 2D), then recombine into a 3D mask.
  A sub-slice-thin box (``ceil(z_min) > floor(z_max)``, e.g. z in 4.2..4.6)
  does not silently vanish: it emits a single annotation on the rounded
  mid-slice ``round((z_min + z_max) / 2)``.
- ``mode="max_projection"``: each box collapses to its ``(x, y, w, h)``
  footprint and emits a single 2D annotation on one composite image.

Coordinate convention
---------------------
TurboBox boxes follow napari axis order: ``(z, y, x)`` for 3D, ``(y, x)`` for
2D. COCO/YOLO ``x`` is the **last** axis (column) and ``y`` the second-to-last
(row). COCO ``bbox`` is ``[x, y, w, h]`` (top-left + size, absolute pixels);
YOLO is ``class x_center y_center w h`` normalized to ``[0, 1]``.

Out-of-bounds boxes are **clamped** to the image bounds and a warning is
emitted (the layer rejects out-of-range API writes and clamps mouse edits when
it knows the image shape, so an out-of-range box at export time signals an
upstream problem worth surfacing rather than swallowing).
"""

from __future__ import annotations

import logging
import warnings
from collections.abc import Sequence

import numpy as np

logger = logging.getLogger(__name__)


def _as_minmax(boxes: np.ndarray) -> np.ndarray:
    """Coerce to a ``(N, 2, D)`` float array with corner 0 = mins, 1 = maxs."""
    arr = np.asarray(boxes, dtype=float)
    if arr.size == 0:
        d = arr.shape[-1] if arr.ndim == 3 else 0
        return arr.reshape(0, 2, d)
    if arr.ndim != 3 or arr.shape[1] != 2:
        raise ValueError(f"boxes must have shape (N, 2, D); got {arr.shape}")
    mins = np.minimum(arr[:, 0], arr[:, 1])
    maxs = np.maximum(arr[:, 0], arr[:, 1])
    return np.stack([mins, maxs], axis=1)


def _image_hw(image_shape: Sequence[int] | None, ndim: int) -> tuple[int, int] | None:
    """Return ``(height, width) = (Y, X)`` -- always the last two axes."""
    if image_shape is None:
        return None
    s = tuple(round(v) for v in image_shape)
    return s[-2], s[-1]


def _slice_indices(box: np.ndarray, mode: str, n_slices: int | None) -> list[int]:
    """Slice indices a 3D box projects onto, per the projection mode."""
    if mode == "max_projection":
        return [0]
    z_min, z_max = float(box[0, 0]), float(box[1, 0])
    lo, hi = int(np.ceil(z_min)), int(np.floor(z_max))
    idxs = [round((z_min + z_max) / 2.0)] if lo > hi else list(range(lo, hi + 1))
    if n_slices is not None:
        idxs = [min(max(i, 0), n_slices - 1) for i in idxs]
    seen: set[int] = set()
    out: list[int] = []
    for i in idxs:  # dedup, preserve order (rounding/clamping can collide)
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out


def _records(
    boxes: np.ndarray,
    image_shape: Sequence[int] | None,
    mode: str,
    category_ids: Sequence[int] | None,
) -> tuple[list[dict], int | None, int | None, int]:
    """Flatten boxes into per-image 2D annotation records.

    Returns ``(records, H, W, ndim)``. Each record is
    ``{"image_id", "x", "y", "w", "h", "cls"}`` with ``image_id`` the slice
    index (``per_slice`` 3D) or ``0`` (``max_projection`` / 2D).
    """
    if mode not in ("per_slice", "max_projection"):
        raise ValueError(f"mode must be 'per_slice' or 'max_projection'; got {mode!r}")
    boxes = _as_minmax(boxes)
    n = boxes.shape[0]
    if n == 0:
        return [], None, None, boxes.shape[-1]
    ndim = boxes.shape[-1]
    if ndim not in (2, 3):
        raise ValueError(f"COCO/YOLO export supports 2D or 3D boxes; got D={ndim}")
    if category_ids is not None and len(category_ids) != n:
        raise ValueError(f"category_ids has length {len(category_ids)}, expected {n}")

    hw = _image_hw(image_shape, ndim)
    if hw is None:
        derived_h = int(np.ceil(boxes[:, 1, -2].max())) + 1
        derived_w = int(np.ceil(boxes[:, 1, -1].max())) + 1
        warnings.warn(
            "No image_shape provided; deriving (H, W) from box extents.",
            UserWarning,
            stacklevel=3,
        )
        hw = (derived_h, derived_w)
    h_img, w_img = hw
    n_slices = round(image_shape[0]) if (ndim == 3 and image_shape is not None) else None
    cats = list(category_ids) if category_ids is not None else [None] * n

    records: list[dict] = []
    n_clamped = 0
    for i in range(n):
        box = boxes[i]
        x_min, x_max = float(box[0, -1]), float(box[1, -1])  # last axis = x
        y_min, y_max = float(box[0, -2]), float(box[1, -2])  # 2nd-to-last = y
        cx_min, cx_max = min(max(x_min, 0.0), w_img), min(max(x_max, 0.0), w_img)
        cy_min, cy_max = min(max(y_min, 0.0), h_img), min(max(y_max, 0.0), h_img)
        if (cx_min, cx_max, cy_min, cy_max) != (x_min, x_max, y_min, y_max):
            n_clamped += 1
        x, y = cx_min, cy_min
        w, h = max(cx_max - cx_min, 0.0), max(cy_max - cy_min, 0.0)
        slices = [0] if ndim == 2 else _slice_indices(box, mode, n_slices)
        for s in slices:
            image_id = int(s) if (ndim == 3 and mode == "per_slice") else 0
            records.append({"image_id": image_id, "x": x, "y": y, "w": w, "h": h, "cls": cats[i]})
    if n_clamped:
        warnings.warn(
            f"{n_clamped} box(es) had coordinates outside image bounds and were clamped.",
            UserWarning,
            stacklevel=3,
        )
    return records, h_img, w_img, ndim


def _filename(image_id: int, ndim: int, mode: str, ext: str) -> str:
    if ndim == 3 and mode == "per_slice":
        return f"slice_{image_id:04d}.{ext}"
    return f"image.{ext}"


def boxes_to_coco(
    boxes: np.ndarray,
    image_shape: Sequence[int] | None,
    *,
    mode: str = "per_slice",
    category_ids: Sequence[int] | None = None,
    category_names: dict[int, str] | None = None,
) -> dict:
    """Convert ``(N, 2, D)`` boxes to a COCO-format detection dict.

    Parameters
    ----------
    boxes : np.ndarray
        ``(N, 2, D)`` min/max boxes in napari ``(z, y, x)`` / ``(y, x)`` order.
    image_shape : sequence of int or None
        Volume/image shape ``(Z, Y, X)`` / ``(Y, X)``. Used for the ``images``
        entries and for slice bounds. If ``None``, ``(H, W)`` is derived from
        box extents (with a warning).
    mode : {"per_slice", "max_projection"}
        3D->2D projection policy (see module docstring).
    category_ids : sequence of int, optional
        Per-box 0-indexed class id. Default: all boxes -> COCO ``category_id`` 1.
    category_names : dict, optional
        Maps a 0-indexed class id to a display name.

    Returns
    -------
    dict
        ``{"images": [...], "annotations": [...], "categories": [...]}``. COCO
        ``bbox`` is ``[x, y, w, h]`` (top-left + size). Boxes with provided
        ``category_ids`` map to ``category_id = class_id + 1``.
    """
    records, _h, _w, ndim = _records(boxes, image_shape, mode, category_ids)

    if category_ids is None:
        categories = [{"id": 1, "name": "object"}]
    else:
        names = category_names or {}
        categories = [
            {"id": int(c) + 1, "name": names.get(int(c), f"class_{int(c)}")}
            for c in sorted({int(c) for c in category_ids})
        ]

    images: dict[int, dict] = {}
    annotations: list[dict] = []
    for rec in records:
        iid = rec["image_id"]
        if iid not in images:
            images[iid] = {
                "id": iid,
                "file_name": _filename(iid, ndim, mode, "png"),
                "width": _w,
                "height": _h,
            }
        category_id = 1 if rec["cls"] is None else int(rec["cls"]) + 1
        annotations.append(
            {
                "id": len(annotations) + 1,
                "image_id": iid,
                "category_id": category_id,
                "bbox": [rec["x"], rec["y"], rec["w"], rec["h"]],
                "area": rec["w"] * rec["h"],
                "iscrowd": 0,
            }
        )
    return {"images": list(images.values()), "annotations": annotations, "categories": categories}


def boxes_to_yolo(
    boxes: np.ndarray,
    image_shape: Sequence[int] | None,
    *,
    mode: str = "per_slice",
    category_ids: Sequence[int] | None = None,
) -> dict[str, str]:
    """Convert ``(N, 2, D)`` boxes to YOLO label files.

    Returns a ``{filename: file_contents}`` mapping (one ``.txt`` per image) so
    the caller writes each file. Each line is
    ``class x_center y_center w h`` normalized to ``[0, 1]`` against that
    image's ``(H, W)``. Class index defaults to ``0`` (YOLO is 0-indexed);
    provided ``category_ids`` are used verbatim as the class index. An empty
    store yields ``{}`` (no files).
    """
    records, h_img, w_img, ndim = _records(boxes, image_shape, mode, category_ids)
    if not records:
        return {}
    by_image: dict[int, list[dict]] = {}
    for rec in records:
        by_image.setdefault(rec["image_id"], []).append(rec)
    files: dict[str, str] = {}
    for iid, recs in by_image.items():
        lines = []
        for rec in recs:
            cls = 0 if rec["cls"] is None else int(rec["cls"])
            xc = (rec["x"] + rec["w"] / 2.0) / w_img
            yc = (rec["y"] + rec["h"] / 2.0) / h_img
            lines.append(f"{cls} {xc:.6f} {yc:.6f} {rec['w'] / w_img:.6f} {rec['h'] / h_img:.6f}")
        files[_filename(iid, ndim, mode, "txt")] = "\n".join(lines) + "\n"
    return files
