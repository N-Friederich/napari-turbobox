"""Undo/Redo system for bounding box operations."""

from __future__ import annotations

import logging

import numpy as np

logger = logging.getLogger(__name__)


class UndoStack:
    """
    Manages undo/redo history for bounding box data.

    The stack stores deep copies of the bbox array at each modification.
    Memory-efficient: only stores changed states, not every intermediate step.

    Parameters
    ----------
    max_size : int
        Maximum number of undo steps to remember (default: 50)
        Each step stores ~(N_boxes * 48 bytes) for the bbox array
        Example: 100 boxes * 48 bytes * 50 steps ~ 240 KB
    """

    def __init__(self, max_size: int = 50):
        self.max_size = max_size
        self._history = []
        self._current_index = -1
        self._enabled = True
        logger.info("UndoStack initialized (max_size=%s)", max_size)

    def push(self, state: np.ndarray, description: str = "Edit"):
        """
        Push a new state onto the undo stack.

        Parameters
        ----------
        state : np.ndarray
            Current bbox data to save (will be deep copied)
        description : str
            Human-readable description of the action
        """
        if not self._enabled:
            return
        state_copy = state.copy()
        if self._current_index < len(self._history) - 1:
            self._history = self._history[: self._current_index + 1]
            logger.debug("Truncated redo history (%ssteps remain)", len(self._history))
        self._history.append((state_copy, description))
        self._current_index += 1
        if len(self._history) > self.max_size:
            self._history.pop(0)
            self._current_index -= 1
            logger.debug("Evicted oldest undo state (limit=%s)", self.max_size)
        logger.debug(
            "Pushed state: '%s' (index=%s/%s)",
            description,
            self._current_index,
            len(self._history) - 1,
        )

    def undo(self) -> tuple[np.ndarray, str] | None:
        """
        Undo to the previous state.

        Returns
        -------
        (state, description) or None
            The previous state and its description, or None if no undo available
        """
        if not self.can_undo():
            logger.warning("Cannot undo: no previous state")
            return None
        self._current_index -= 1
        state, description = self._history[self._current_index]
        logger.info(
            "Undo: '%s' (index=%s/%s)", description, self._current_index, len(self._history) - 1
        )
        return (state.copy(), description)

    def redo(self) -> tuple[np.ndarray, str] | None:
        """
        Redo to the next state.

        Returns
        -------
        (state, description) or None
            The next state and its description, or None if no redo available
        """
        if not self.can_redo():
            logger.warning("Cannot redo: no future state")
            return None
        self._current_index += 1
        state, description = self._history[self._current_index]
        logger.info(
            "Redo: '%s' (index=%s/%s)", description, self._current_index, len(self._history) - 1
        )
        return (state.copy(), description)

    def can_undo(self) -> bool:
        """Check if undo is available."""
        return self._current_index > 0

    def can_redo(self) -> bool:
        """Check if redo is available."""
        return self._current_index < len(self._history) - 1

    def clear(self):
        """Clear all history."""
        self._history.clear()
        self._current_index = -1
        logger.info("Cleared undo history")

    def disable(self):
        """Temporarily disable undo recording (e.g., during restore)."""
        self._enabled = False

    def enable(self):
        """Re-enable undo recording."""
        self._enabled = True

    def get_undo_description(self) -> str | None:
        """Get description of the action that would be undone."""
        if self.can_undo():
            return self._history[self._current_index - 1][1]
        return None

    def get_redo_description(self) -> str | None:
        """Get description of the action that would be redone."""
        if self.can_redo():
            return self._history[self._current_index + 1][1]
        return None

    @property
    def size(self) -> int:
        """Number of states in history."""
        return len(self._history)

    @property
    def current_position(self) -> int:
        """Current position in history (0-indexed)."""
        return self._current_index

    def get_memory_usage(self) -> int:
        """Estimate memory usage in bytes."""
        if not self._history:
            return 0
        bytes_per_state = sum((state.nbytes for state, _ in self._history))
        overhead = len(self._history) * 100
        return bytes_per_state + overhead

    def __repr__(self) -> str:
        mem_kb = self.get_memory_usage() / 1024
        return f"UndoStack(size={self.size}/{self.max_size}, position={self._current_index}, memory={mem_kb:.1f}KB, can_undo={self.can_undo()}, can_redo={self.can_redo()})"
