"""Spatial index for efficient bounding box queries."""

from __future__ import annotations

import logging
from collections.abc import Sequence

import numpy as np

logger = logging.getLogger(__name__)

# Coordinate dtype for the index copy + sorted arrays. Kept in sync with
# BBoxDataStore's float32 storage so index queries exactly match the store.
# float32 is exact for integer voxel indices up to 2**24; never float16.
_COORD_DTYPE = np.float32


class SpatialIndex:
    """A simple spatial index for axis-aligned bounding boxes using sorted arrays.

    This allows for fast O(log N) querying of boxes that contain a given point.
    It works by maintaining sorted lists of min and max coordinates for each dimension.

    Parameters
    ----------
    boxes : np.ndarray
        Array of bounding boxes with shape (N, 2, ndim).

    Examples
    --------
    >>> bboxes = np.array([
    ...     [[0, 0], [10, 10]],
    ...     [[5, 5], [15, 15]],
    ... ])
    >>> index = SpatialIndex(bboxes)
    >>> candidates = index.query_point([7, 7])  # Returns [0, 1]
    >>> candidates = index.query_point([12, 12])  # Returns [1]
    """

    def __init__(self, boxes: np.ndarray):
        """Initialize the spatial index.

        Parameters
        ----------
        boxes : np.ndarray
            Array of bounding boxes with shape (N, 2, ndim).
        """
        # Own a writable copy. Callers pass the store's read-only view
        # (``BBoxDataStore.data``), and the store mutates that buffer in place
        # before notifying listeners. Aliasing it here would (a) make the
        # in-place ``update_box`` write raise on the read-only array and
        # (b) leave the index's own pre-update value unavailable, so the
        # incremental re-sort cannot compute the correct shift. A private copy
        # decouples the index from live store mutations.
        boxes = np.asarray(boxes, dtype=_COORD_DTYPE)
        self._boxes = boxes.copy()
        self._ndim = boxes.shape[-1] if boxes.size > 0 else 0
        self._count = boxes.shape[0] if boxes.size > 0 else 0
        self._sorted_mins = []
        self._sorted_maxs = []
        self._sorted_indices_mins = []
        self._sorted_indices_maxs = []
        self._position_in_sorted_mins = []
        self._position_in_sorted_maxs = []
        if self._count > 0:
            for d in range(self._ndim):
                mins = boxes[:, 0, d]
                sort_idx_min = np.argsort(mins)
                self._sorted_mins.append(mins[sort_idx_min])
                self._sorted_indices_mins.append(sort_idx_min)
                inv_mins = np.empty_like(sort_idx_min)
                inv_mins[sort_idx_min] = np.arange(self._count)
                self._position_in_sorted_mins.append(inv_mins)
                maxs = boxes[:, 1, d]
                sort_idx_max = np.argsort(maxs)
                self._sorted_maxs.append(maxs[sort_idx_max])
                self._sorted_indices_maxs.append(sort_idx_max)
                inv_maxs = np.empty_like(sort_idx_max)
                inv_maxs[sort_idx_max] = np.arange(self._count)
                self._position_in_sorted_maxs.append(inv_maxs)
        self._max_extent = (
            (boxes[:, 1].astype(float) - boxes[:, 0].astype(float)).max(axis=0)
            if self._count > 0
            else np.zeros(self._ndim)
        )

    def _window(self, d: int, q_lo: float, q_hi: float) -> np.ndarray:
        """Boxes intersecting [q_lo, q_hi] along dimension ``d``.

        Every box with ``max >= q_lo`` and ``min <= q_hi`` has its min in
        ``[q_lo - max_extent_d, q_hi]``, a contiguous run of the sorted mins:
        O(log N + window) instead of materialising all mins <= q_hi.
        """
        lo = 0
        if np.isfinite(q_lo):
            ext = self._max_extent[d]
            # float64 rounding of (q_lo - ext) may exceed the exact bound by a few
            # ulps; widen by a relative margin (extra candidates are filtered below).
            bound = q_lo - ext - 4 * np.finfo(np.float64).eps * (abs(q_lo) + ext + 1e-300)
            lo = np.searchsorted(self._sorted_mins[d], bound, side="left")
        hi = np.searchsorted(self._sorted_mins[d], q_hi, side="right")
        cand = self._sorted_indices_mins[d][lo:hi]
        return cand[self._boxes[cand, 1, d].astype(np.float64) >= q_lo]

    def query_point(self, point: np.ndarray) -> list[int]:
        """Find indices of boxes that contain the given point.

        Parameters
        ----------
        point : np.ndarray
            Point coordinates (ndim,).

        Returns
        -------
        List[int]
            Indices of boxes containing the point.

        Notes
        -----
        Uses binary search (O(log N)) for efficient spatial queries.
        A point is considered inside a bbox if:
            mins[i] <= point[i] <= maxs[i] for all dimensions i
        """
        if self._count == 0:
            return []
        candidates = None
        for d in range(min(len(point), self._ndim)):
            val = float(point[d])
            valid_in_dim = self._window(d, val, val)
            if candidates is None:
                candidates = valid_in_dim
            else:
                candidates = np.intersect1d(candidates, valid_in_dim, assume_unique=True)
            if len(candidates) == 0:
                return []
        return candidates.tolist() if candidates is not None else []

    def intersection(self, box: np.ndarray) -> list[int]:
        """Find indices of boxes that intersect with the given box.

        Parameters
        ----------
        box : np.ndarray
            Query box with shape (2, ndim) -> [[mins], [maxs]].

        Returns
        -------
        List[int]
            Indices of intersecting boxes.
        """
        if self._count == 0:
            return []
        candidates = None
        query_mins = box[0]
        query_maxs = box[1]
        for d in range(min(len(query_mins), self._ndim)):
            q_lo, q_hi = float(query_mins[d]), float(query_maxs[d])
            if q_lo == -np.inf and q_hi == np.inf:
                continue  # unbounded (displayed) axis: no constraint
            valid_in_dim = self._window(d, q_lo, q_hi)
            if candidates is None:
                candidates = valid_in_dim
            else:
                candidates = np.intersect1d(candidates, valid_in_dim, assume_unique=True)
            if len(candidates) == 0:
                return []
        if candidates is None:
            return list(range(self._count))
        return candidates.tolist()

    def query_point_approximate(self, point: np.ndarray, tolerance: float = 0.0) -> list[int]:
        """Find indices of boxes that contain the point within a tolerance.

        Useful for "near edge" checks.

        Parameters
        ----------
        point : np.ndarray
            Point coordinates (ndim,).
        tolerance : float, optional
            Tolerance for approximate matching. Default is 0.0 (exact match).

        Returns
        -------
        List[int]
            Indices of boxes containing the point within tolerance.
        """
        return self.query_point(point)

    def rebuild(self, boxes: np.ndarray) -> None:
        """Rebuild the index with new bounding boxes.

        Parameters
        ----------
        boxes : np.ndarray
            New array of bounding boxes with shape (N, 2, ndim).
        """
        # Own a writable copy. Callers pass the store's read-only view
        # (``BBoxDataStore.data``), and the store mutates that buffer in place
        # before notifying listeners. Aliasing it here would (a) make the
        # in-place ``update_box`` write raise on the read-only array and
        # (b) leave the index's own pre-update value unavailable, so the
        # incremental re-sort cannot compute the correct shift. A private copy
        # decouples the index from live store mutations.
        boxes = np.asarray(boxes, dtype=_COORD_DTYPE)
        self._boxes = boxes.copy()
        self._ndim = boxes.shape[-1] if boxes.size > 0 else 0
        self._count = boxes.shape[0] if boxes.size > 0 else 0
        self._sorted_mins = []
        self._sorted_maxs = []
        self._sorted_indices_mins = []
        self._sorted_indices_maxs = []
        self._position_in_sorted_mins = []
        self._position_in_sorted_maxs = []
        if self._count > 0:
            for d in range(self._ndim):
                mins = boxes[:, 0, d]
                sort_idx_min = np.argsort(mins)
                self._sorted_mins.append(mins[sort_idx_min])
                self._sorted_indices_mins.append(sort_idx_min)
                inv_mins = np.empty_like(sort_idx_min)
                inv_mins[sort_idx_min] = np.arange(self._count)
                self._position_in_sorted_mins.append(inv_mins)
                maxs = boxes[:, 1, d]
                sort_idx_max = np.argsort(maxs)
                self._sorted_maxs.append(maxs[sort_idx_max])
                self._sorted_indices_maxs.append(sort_idx_max)
                inv_maxs = np.empty_like(sort_idx_max)
                inv_maxs[sort_idx_max] = np.arange(self._count)
                self._position_in_sorted_maxs.append(inv_maxs)
        self._max_extent = (
            (boxes[:, 1].astype(float) - boxes[:, 0].astype(float)).max(axis=0)
            if self._count > 0
            else np.zeros(self._ndim)
        )

    def update_box(self, index: int, new_bbox: np.ndarray) -> None:
        """Update a single bounding box in the spatial index.

        🚀 OPTIMIZATION: Highly optimized O(shifted) incremental re-sorting.
        Uses O(1) position mapping arrays and targeted element shifts.

        Parameters
        ----------
        index : int
            Index of the box to update.
        new_bbox : np.ndarray
            New bounding box with shape (2, ndim).
        """
        if index < 0 or index >= self._count:
            logger.warning("Invalid box index%s(valid range: 0-%s)", index, self._count - 1)
            return
        old_bbox = self._boxes[index].copy()
        self._boxes[index] = new_bbox
        self._max_extent = np.maximum(
            self._max_extent, self._boxes[index, 1].astype(float) - self._boxes[index, 0].astype(float)
        )
        for d in range(self._ndim):
            old_val_min = old_bbox[0, d]
            new_val_min = new_bbox[0, d]
            if old_val_min != new_val_min:
                pos = self._position_in_sorted_mins[d][index]
                if new_val_min < old_val_min:
                    insert_pos = np.searchsorted(self._sorted_mins[d][:pos], new_val_min)
                    slice_indices = self._sorted_indices_mins[d][insert_pos:pos].copy()
                    self._sorted_mins[d][insert_pos + 1 : pos + 1] = self._sorted_mins[d][
                        insert_pos:pos
                    ]
                    self._sorted_indices_mins[d][insert_pos + 1 : pos + 1] = slice_indices
                    self._sorted_mins[d][insert_pos] = new_val_min
                    self._sorted_indices_mins[d][insert_pos] = index
                    self._position_in_sorted_mins[d][slice_indices] += 1
                    self._position_in_sorted_mins[d][index] = insert_pos
                else:
                    insert_offset = np.searchsorted(
                        self._sorted_mins[d][pos + 1 :], new_val_min, side="right"
                    )
                    target_pos = pos + insert_offset
                    slice_indices = self._sorted_indices_mins[d][pos + 1 : target_pos + 1].copy()
                    self._sorted_mins[d][pos:target_pos] = self._sorted_mins[d][
                        pos + 1 : target_pos + 1
                    ]
                    self._sorted_indices_mins[d][pos:target_pos] = slice_indices
                    self._sorted_mins[d][target_pos] = new_val_min
                    self._sorted_indices_mins[d][target_pos] = index
                    self._position_in_sorted_mins[d][slice_indices] -= 1
                    self._position_in_sorted_mins[d][index] = target_pos
            old_val_max = old_bbox[1, d]
            new_val_max = new_bbox[1, d]
            if old_val_max != new_val_max:
                pos = self._position_in_sorted_maxs[d][index]
                if new_val_max < old_val_max:
                    insert_pos = np.searchsorted(self._sorted_maxs[d][:pos], new_val_max)
                    slice_indices = self._sorted_indices_maxs[d][insert_pos:pos].copy()
                    self._sorted_maxs[d][insert_pos + 1 : pos + 1] = self._sorted_maxs[d][
                        insert_pos:pos
                    ]
                    self._sorted_indices_maxs[d][insert_pos + 1 : pos + 1] = slice_indices
                    self._sorted_maxs[d][insert_pos] = new_val_max
                    self._sorted_indices_maxs[d][insert_pos] = index
                    self._position_in_sorted_maxs[d][slice_indices] += 1
                    self._position_in_sorted_maxs[d][index] = insert_pos
                else:
                    insert_offset = np.searchsorted(
                        self._sorted_maxs[d][pos + 1 :], new_val_max, side="right"
                    )
                    target_pos = pos + insert_offset
                    slice_indices = self._sorted_indices_maxs[d][pos + 1 : target_pos + 1].copy()
                    self._sorted_maxs[d][pos:target_pos] = self._sorted_maxs[d][
                        pos + 1 : target_pos + 1
                    ]
                    self._sorted_indices_maxs[d][pos:target_pos] = slice_indices
                    self._sorted_maxs[d][target_pos] = new_val_max
                    self._sorted_indices_maxs[d][target_pos] = index
                    self._position_in_sorted_maxs[d][slice_indices] -= 1
                    self._position_in_sorted_maxs[d][index] = target_pos
        logger.debug("Updated box%sin spatial index (incremental)", index)

    def add_boxes(self, new_boxes: np.ndarray) -> None:
        """Add new bounding boxes to the spatial index.

        🚀 OPTIMIZATION: Efficiently adds boxes without full rebuild.
        If the number of new boxes M <= N/10, uses searchsorted + insert true merge.
        Otherwise falls back to bulk sorting.

        Parameters
        ----------
        new_boxes : np.ndarray
            Array of new bounding boxes with shape (M, 2, ndim).
        """
        new_boxes = np.asarray(new_boxes, dtype=_COORD_DTYPE)
        if new_boxes.size == 0:
            return
        n_new = new_boxes.shape[0]
        old_count = self._count
        self._boxes = np.vstack([self._boxes, new_boxes]) if self._boxes.size > 0 else new_boxes
        self._count = self._boxes.shape[0]
        if old_count == 0:
            self.rebuild(self._boxes)
            logger.debug("Added%sboxes to spatial index (initial build)", n_new)
            return
        self._max_extent = np.maximum(
            self._max_extent, (new_boxes[:, 1].astype(float) - new_boxes[:, 0].astype(float)).max(axis=0)
        )
        use_incremental_merge = n_new <= old_count // 10
        for d in range(self._ndim):
            new_mins = new_boxes[:, 0, d]
            new_maxs = new_boxes[:, 1, d]
            if use_incremental_merge:
                sort_new_mins = np.argsort(new_mins)
                sorted_new_mins = new_mins[sort_new_mins]
                new_indices_mins = old_count + sort_new_mins
                insert_positions = np.searchsorted(self._sorted_mins[d], sorted_new_mins)
                self._sorted_mins[d] = np.insert(
                    self._sorted_mins[d], insert_positions, sorted_new_mins
                )
                self._sorted_indices_mins[d] = np.insert(
                    self._sorted_indices_mins[d], insert_positions, new_indices_mins
                )
                new_inv_mins = np.empty(self._count, dtype=int)
                new_inv_mins[self._sorted_indices_mins[d]] = np.arange(self._count)
                self._position_in_sorted_mins[d] = new_inv_mins
                sort_new_maxs = np.argsort(new_maxs)
                sorted_new_maxs = new_maxs[sort_new_maxs]
                new_indices_maxs = old_count + sort_new_maxs
                insert_positions_max = np.searchsorted(self._sorted_maxs[d], sorted_new_maxs)
                self._sorted_maxs[d] = np.insert(
                    self._sorted_maxs[d], insert_positions_max, sorted_new_maxs
                )
                self._sorted_indices_maxs[d] = np.insert(
                    self._sorted_indices_maxs[d], insert_positions_max, new_indices_maxs
                )
                new_inv_maxs = np.empty(self._count, dtype=int)
                new_inv_maxs[self._sorted_indices_maxs[d]] = np.arange(self._count)
                self._position_in_sorted_maxs[d] = new_inv_maxs
            else:
                extended_mins = np.concatenate([self._sorted_mins[d], new_mins])
                new_indices = np.arange(old_count, self._count)
                extended_indices_mins = np.concatenate([self._sorted_indices_mins[d], new_indices])
                sort_order = np.argsort(extended_mins)
                self._sorted_mins[d] = extended_mins[sort_order]
                self._sorted_indices_mins[d] = extended_indices_mins[sort_order]
                inv_mins = np.empty(self._count, dtype=int)
                inv_mins[self._sorted_indices_mins[d]] = np.arange(self._count)
                self._position_in_sorted_mins[d] = inv_mins
                extended_maxs = np.concatenate([self._sorted_maxs[d], new_maxs])
                extended_indices_maxs = np.concatenate([self._sorted_indices_maxs[d], new_indices])
                sort_order = np.argsort(extended_maxs)
                self._sorted_maxs[d] = extended_maxs[sort_order]
                self._sorted_indices_maxs[d] = extended_indices_maxs[sort_order]
                inv_maxs = np.empty(self._count, dtype=int)
                inv_maxs[self._sorted_indices_maxs[d]] = np.arange(self._count)
                self._position_in_sorted_maxs[d] = inv_maxs
        logger.debug(
            "Added%sboxes to spatial index (incremental=%s, total=%s)",
            n_new,
            use_incremental_merge,
            self._count,
        )

    def remove_boxes(self, indices: Sequence[int]) -> None:
        """Remove bounding boxes from the spatial index.

        🚀 OPTIMIZATION: Efficiently removes boxes without full rebuild.

        Parameters
        ----------
        indices : Sequence[int]
            Indices of boxes to remove.
        """
        if not indices:
            return
        indices_to_remove = np.asarray(indices, dtype=int)
        if len(indices_to_remove) == 0:
            return
        if np.any(indices_to_remove < 0) or np.any(indices_to_remove >= self._count):
            logger.warning("Some removal indices out of range (valid: 0-%s)", self._count - 1)
            indices_to_remove = indices_to_remove[
                (indices_to_remove >= 0) & (indices_to_remove < self._count)
            ]
            if len(indices_to_remove) == 0:
                return
        n_removed = len(indices_to_remove)
        keep_mask = np.ones(self._count, dtype=bool)
        keep_mask[indices_to_remove] = False
        self._boxes = self._boxes[keep_mask]
        self._count = self._boxes.shape[0]
        if self._count == 0:
            self._ndim = 0
            self._sorted_mins = []
            self._sorted_maxs = []
            self._sorted_indices_mins = []
            self._sorted_indices_maxs = []
            self._position_in_sorted_mins = []
            self._position_in_sorted_maxs = []
            logger.debug("Removed%sboxes from spatial index (now empty)", n_removed)
            return
        new_indices = np.full(self._count + n_removed, -1, dtype=int)
        new_indices[keep_mask] = np.arange(self._count)
        for d in range(self._ndim):
            old_sorted_indices = self._sorted_indices_mins[d]
            valid_mask = keep_mask[old_sorted_indices]
            self._sorted_mins[d] = self._sorted_mins[d][valid_mask]
            self._sorted_indices_mins[d] = new_indices[old_sorted_indices[valid_mask]]
            new_inv_mins = np.empty(self._count, dtype=int)
            new_inv_mins[self._sorted_indices_mins[d]] = np.arange(self._count)
            self._position_in_sorted_mins[d] = new_inv_mins
            old_sorted_indices = self._sorted_indices_maxs[d]
            valid_mask = keep_mask[old_sorted_indices]
            self._sorted_maxs[d] = self._sorted_maxs[d][valid_mask]
            self._sorted_indices_maxs[d] = new_indices[old_sorted_indices[valid_mask]]
            new_inv_maxs = np.empty(self._count, dtype=int)
            new_inv_maxs[self._sorted_indices_maxs[d]] = np.arange(self._count)
            self._position_in_sorted_maxs[d] = new_inv_maxs
        logger.debug(
            "Removed%sboxes from spatial index (incremental, remaining=%s)", n_removed, self._count
        )
