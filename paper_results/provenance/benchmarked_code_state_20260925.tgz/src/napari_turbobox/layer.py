"""Custom napari layer that exposes nD axis-aligned bounding boxes."""

from __future__ import annotations

import dataclasses
import logging
import time
from collections.abc import Iterable, Sequence
from typing import Any, Literal

import numpy as np
from napari.layers import Shapes
from napari.utils.events import Event

from .data_store import BBoxDataStore
from .event_manager import BoundingBoxEventManager
from .geometry import (
    bbox_from_path,
    ensure_bbox_array,
    extrude_2d_to_3d_box,
    path_from_bbox,
    paths_from_bboxes,
    slice_paths_from_bbox,
    slice_paths_from_bboxes,
    wireframe_path_from_bbox,
)
from .spatial_index import SpatialIndex
from .undo import UndoStack

logger = logging.getLogger(__name__)


def _select_unless_bbox_drag(layer, event):
    """napari's select handler, skipped for drags that TurboBox's handler owns.

    TurboBox's ``_on_mouse_drag`` runs first (index 0) and sets ``_drag_state``
    when the press hits a box; napari's ``select`` would otherwise also shift
    the displayed shape (napari never checks ``event.handled``).
    """
    if getattr(layer, "_drag_state", None) is not None:
        return
    from napari.layers.shapes._shapes_mouse_bindings import select

    yield from select(layer, event)


def _move_last_shape(dv, pos: int) -> None:
    """Move the last shape of napari's ShapeList ``dv`` to index ``pos``.

    Each shape owns one contiguous block of rows in the vertex, mesh-vertex and
    triangle arrays; ``*_index[i]`` is where the block of shape ``i`` starts and
    ``*_index[i + 1]`` where it ends. Moving the last shape to ``pos`` rotates
    the rows from block ``pos`` on, shifts the block starts behind it, and
    renumbers the mesh-vertex indices stored in the triangles. The z-order and
    the displayed arrays are left to napari (``_update_z_order``).
    """
    last = len(dv.shapes) - 1
    if pos == last:
        return
    mesh = dv._mesh

    def move_rows(index, *arrays):
        """Rotate the rows of ``arrays`` and return the new block starts."""
        start, moved, end = int(index[pos]), int(index[last]), int(index[last + 1])
        rotated = [
            np.concatenate([a[:start], a[moved:end], a[start:moved], a[end:]]) for a in arrays
        ]
        new_index = index.copy()
        new_index[pos + 1 : last + 1] = index[pos:last] + (end - moved)
        return new_index, rotated, (start, moved, end)

    dv.shapes.insert(pos, dv.shapes.pop())
    dv._z_index, dv._edge_color, dv._face_color = (
        np.concatenate([a[:pos], a[last:], a[pos:last]])
        for a in (dv._z_index, dv._edge_color, dv._face_color)
    )
    dv._vertices_index, (dv._vertices,), _ = move_rows(dv._vertices_index, dv._vertices)
    mesh.vertices_index, rotated, (start, moved, end) = move_rows(
        mesh.vertices_index, mesh.vertices, mesh.vertices_centers, mesh.vertices_offsets
    )
    mesh.vertices, mesh.vertices_centers, mesh.vertices_offsets = rotated
    # Where each old mesh-vertex row went, for the indices held by the triangles.
    dtype = mesh.triangles.dtype
    new_row = np.concatenate([
        np.arange(start, dtype=dtype),
        np.arange(start + end - moved, end, dtype=dtype),
        np.arange(start, start + end - moved, dtype=dtype),
        np.arange(end, len(mesh.vertices), dtype=dtype),
    ])
    mesh.triangles_index, (triangles, mesh.triangles_colors), _ = move_rows(
        mesh.triangles_index, mesh.triangles, mesh.triangles_colors
    )
    mesh.triangles = new_row[triangles]


class TurboBoxLayer(Shapes):
    """Axis-aligned 2D/3D bounding boxes rendered through a napari Shapes layer.

    This layer provides interactive annotation of axis-aligned bounding boxes
    in 2D images and 3D volumes (2 or 3 spatial axes). It extends
    napari's Shapes layer with bbox-specific functionality including efficient
    multi-viewer synchronization, slice-aware rendering, and interactive
    editing capabilities.

    The layer uses a shared data store pattern to enable synchronized bbox
    visualization across multiple napari viewers, making it ideal for multi-view
    workflows (e.g., XY/XZ/YZ + 3D rendering).

    Attributes:
        layer_type (str): Layer type identifier "turbobox"
        bounding_boxes (np.ndarray): Array of bounding boxes with shape (N, 2, ndim)
            where N is the number of boxes
    """

    layer_type = "turbobox"
    _type_string = "turbobox"

    def __init__(
        self,
        data: Iterable[Sequence[Sequence[float]]] | np.ndarray | None = None,
        *,
        ndim: int | None = None,
        image_shape: Sequence[int] | None = None,
        name: str | None = "Bounding Boxes",
        edge_color: str | Sequence[str] = "cyan",
        edge_width: float = 2.0,
        face_color: str = "transparent",
        auto_extrude: bool = False,
        bbox_data_store: BBoxDataStore | None = None,
        interactive: bool = True,
        sync_mode: Literal["live", "on_commit"] | None = None,
        **kwargs,
    ) -> None:
        """Initialize an optimized nD bounding box layer.

        Args:
            data: Initial bounding box data. Can be:
                - None: Create empty layer
                - np.ndarray of shape (N, 2, ndim): N boxes as [mins, maxs] pairs
                - Iterable of [[mins], [maxs]] pairs
            ndim: Number of dimensions. If None, inferred from data or defaults to 3.
            image_shape: Shape of the image volume. If provided, API writes outside
                [0, image_shape - 1] are rejected (ValueError) and mouse edits are
                clamped to that range.
            name: Layer name displayed in napari layer list.
            edge_color: Color for bbox edges. Supports color names ("cyan"), hex codes,
                or RGB(A) tuples.
            edge_width: Width of bbox edges in pixels.
            face_color: Fill color for bbox faces. Usually "transparent" for better
                visibility of underlying image data.
            auto_extrude: If True, automatically extrude 2D boxes (drawn in slice view)
                to span full range of hidden dimensions. Useful for quickly creating
                3D boxes from 2D annotations.
            bbox_data_store: Shared data store for multi-viewer synchronization. If None,
                creates a private store. To synchronize across viewers, pass the same
                BBoxDataStore instance to multiple layers.
            interactive: If True, layer allows editing (move, resize, add, delete boxes).
                If False, layer is read-only (display only). Useful for synchronized
                viewers where only one should be editable.
            sync_mode: Synchronization mode for this layer's shared-store subscription.
                "live" notifies the layer on every store change; "on_commit" defers
                notifications until the active edit session ends. If None (default),
                falls back to "live". The caller (e.g. create_synchronized_bbox_layers)
                is responsible for passing "on_commit" for layers shown in 3D. Only
                meaningful when bbox_data_store is shared (interactive subscription).
            **kwargs: Additional keyword arguments passed to parent Shapes layer.

        Examples:
            Create layer with initial boxes::

                layer = TurboBoxLayer(
                    data=[[[10, 20, 20], [50, 80, 80]]],
                    ndim=3,
                    image_shape=(100, 512, 512),
                    edge_color="cyan",
                    edge_width=3.0
                )

            Create synchronized layers for multi-viewer::

                from napari_turbobox import BBoxDataStore

                shared_store = BBoxDataStore()
                layer1 = TurboBoxLayer(
                    bbox_data_store=shared_store,
                    interactive=True  # Main viewer
                )
                layer2 = TurboBoxLayer(
                    bbox_data_store=shared_store,
                    interactive=False  # Read-only display
                )

        Notes:
            - Bboxes are always axis-aligned (no rotation support)
            - In 2D view mode (ndisplay=2), shows slice-intersecting rectangles
            - In 3D view mode (ndisplay=3), shows one wireframe path per box
              (a 2D layer keeps showing its rectangles, like napari's Shapes)
            - Mode switching is automatic based on viewer dims
        """
        boxes = ensure_bbox_array(data, ndim)
        ndim = boxes.shape[-1] if boxes.size else ndim or 3
        if bbox_data_store is None:
            self._bbox_store = BBoxDataStore(initial_data=boxes)
            self._owns_store = True
        else:
            self._bbox_store = bbox_data_store
            self._owns_store = False
            if boxes.size > 0:
                self._bbox_store.add_boxes(boxes)
        logger.debug(
            "__init__: Creating layer with%sboxes (shared_store=%s, interactive=%s)",
            len(self._bbox_store.data),
            not self._owns_store,
            interactive,
        )
        logger.debug("__init__: edge_width=%s, edge_color=%s", edge_width, edge_color)
        super().__init__(
            data=[],
            ndim=ndim,
            shape_type="path",
            edge_color=edge_color,
            edge_width=edge_width,
            face_color=face_color,
            name=name,
            **kwargs,
        )
        self._force_sync = True
        self.edge_width = edge_width
        self.current_edge_width = edge_width
        logger.debug("__init__: After super().__init__, self.edge_width =%s", self.edge_width)
        self._image_shape = self._normalize_image_shape(image_shape, ndim)
        self._interactive = interactive
        self._pending_remove = None
        self._napari_adding = False  # between napari's 'adding' and 'added' events
        self._reset_editable()  # read-only layers: editable=False -> napari forces PAN_ZOOM
        self._sync_guard = False
        self._event_manager = BoundingBoxEventManager()
        self._drag_state = None
        self._session_active = False
        self._auto_extrude = auto_extrude
        self._last_bbox_count = 0
        self._bbox_is_moving = False
        self._just_finished_drag = False
        self._drag_end_time = 0.0
        self._sync_mode: Literal["live", "on_commit"] = sync_mode or "live"
        # Every layer follows its store, also one it owns, so that edits made
        # through ``layer.store`` show up exactly like edits made by the layer.
        self._bbox_store.register_listener(self._on_shared_data_changed, sync_mode=self._sync_mode)
        self.events.add(bboxes=Event)
        self.events.data.connect(self._on_shapes_data_changed)
        self.mouse_drag_callbacks.insert(0, self._on_mouse_drag)
        self._allow_thumbnail_update = True
        # Rasterize the thumbnail once when a store edit session ends (it is
        # skipped for every store-driven update inside the session).
        self._bbox_store.events.session_ended.connect(self._on_store_session_ended)
        self._moving_coordinates = None
        self.events.mode.connect(self._on_mode_change)
        self._dims_connected = False
        if not hasattr(self, "_value") or self._value is None:
            self._value = (None, None)
        if not hasattr(self, "_moving_value"):
            self._moving_value = (None, None)
        if not hasattr(self, "_drag_box"):
            self._drag_box = None
        if not hasattr(self, "_drag_box_stored"):
            self._drag_box_stored = None
        if not hasattr(self, "_value_stored"):
            self._value_stored = (None, None)
        self.current_edge_width = edge_width
        self.edge_width = edge_width
        self._spatial_index = SpatialIndex(self._bbox_store.data)
        self._path_cache = {}
        self._cache_max_size = 10000
        self._undo_stack = UndoStack(max_size=50)
        self._undo_stack.push(self._bbox_store.data.copy(), "Initial state")
        if self._bbox_store.data.size > 0:
            self._sync_shapes_from_bboxes()

    def _post_init(self) -> None:
        """Called after the layer is fully initialized and added to a viewer."""
        logger.debug("_post_init() called")
        super()._post_init()
        self._dims_connected = True
        self._sync_shapes_from_bboxes()
        from napari.layers.shapes._shapes_constants import Mode

        self.mode = Mode.SELECT if self._interactive else Mode.PAN_ZOOM
        self.bind_key("Control-Z", self.undo, overwrite=True)
        self.bind_key("Control-Y", self.redo, overwrite=True)
        self.bind_key("Command-Z", self.undo, overwrite=True)
        self.bind_key("Command-Shift-Z", self.redo, overwrite=True)
        logger.info("Undo/Redo keyboard shortcuts registered (Ctrl+Z, Ctrl+Y)")
        logger.info("_post_init() completed, mode set to SELECT")
        logger.debug("Click anywhere inside a bbox to move it")
        logger.debug("Click near an edge/corner to resize it (or hold Shift anywhere)")

    @property
    def _slice_input(self):
        if hasattr(self, "_mock_slice_input"):
            return self._mock_slice_input
        return super()._slice_input

    @_slice_input.setter
    def _slice_input(self, value):
        self._mock_slice_input = value

    @property
    def _extent_data(self) -> np.ndarray:
        """Return the spatial extent of the layer.

        If image_shape is specified, returns the bounds of the image volume
        [[0, ..., 0], image_shape] to prevent slider range clipping.
        Otherwise falls back to the bounds of the bounding box data.
        """
        if self._image_shape is not None:
            mins = np.zeros(self.ndim)
            maxs = np.asarray(self._image_shape, dtype=float)
            return np.stack([mins, maxs], axis=0)
        return super()._extent_data

    @property
    def sync_mode(self) -> Literal["live", "on_commit"]:
        """Synchronization mode for this layer's shared-store subscription.

        ``"live"`` notifies this layer immediately on every store change;
        ``"on_commit"`` defers notifications until the active edit session
        ends (see :meth:`BBoxDataStore.begin_edit_session`).

        Notes
        -----
        The mode is decided once, at construction, typically from the
        viewer's ``ndisplay`` (3D viewers use ``"on_commit"``). It is **not**
        updated automatically if the viewer later toggles between 2D and 3D
        display — assign this property manually if the display mode changes
        at runtime.
        """
        return self._sync_mode

    @sync_mode.setter
    def sync_mode(self, value: Literal["live", "on_commit"]) -> None:
        """Change the sync mode at runtime.

        "live" updates the layer on every store change; "on_commit" defers the
        update until the store's edit session ends.
        """
        self._sync_mode = value
        self._bbox_store.set_listener_sync_mode(self._on_shared_data_changed, value)
        logger.debug("Layer sync_mode changed to %r", value)

    @property
    def store(self) -> BBoxDataStore:
        """The :class:`BBoxDataStore` this layer displays (shared by synchronized layers).

        Writes to the store (for example ``store.update_box``) update every layer
        that displays it. They are not validated and not recorded for undo; use
        ``bounding_boxes`` or ``add_boxes`` for that.
        """
        return self._bbox_store

    @property
    def bounding_boxes(self) -> np.ndarray:
        """Return a copy of the current bounding boxes."""
        return self._bbox_store.data.copy()

    @bounding_boxes.setter
    def bounding_boxes(self, value: Iterable[Sequence[Sequence[float]]] | np.ndarray) -> None:
        if not self._interactive:
            logger.warning(
                "Layer is in read-only mode (interactive=False), ignoring bbox modification"
            )
            return
        boxes = ensure_bbox_array(value, self.ndim)
        if boxes.size:
            boxes = np.asarray([self._expand_hidden_axes(b) for b in boxes], dtype=float)
            self._validate_box(boxes)
        self._bbox_store.data = boxes  # the store notifies this layer and all others
        if hasattr(self, "_undo_stack"):
            self._undo_stack.push(self.bounding_boxes.copy(), "Set boxes")  # no-op during undo/redo

    def add_boxes(self, boxes: Iterable[Sequence[Sequence[float]]] | np.ndarray) -> None:
        """Add new bounding boxes to the layer."""
        if not self._interactive:
            logger.warning("Layer is in read-only mode (interactive=False), ignoring add_boxes")
            return
        logger.debug("add_boxes() called with boxes:%s", boxes)
        logger.debug("self.ndim =%s", self.ndim)
        new_boxes = ensure_bbox_array(boxes, self.ndim)
        logger.debug("After ensure_bbox_array: new_boxes.shape =%s", new_boxes.shape)
        logger.debug("new_boxes =%s", new_boxes)
        if new_boxes.size == 0:
            logger.warning("new_boxes is empty, returning")
            return
        if new_boxes.size:
            new_boxes = np.asarray([self._expand_hidden_axes(b) for b in new_boxes], dtype=float)
        self._validate_box(new_boxes)
        self._bbox_store.add_boxes(new_boxes)
        logger.debug(
            "Before _sync_shapes_from_bboxes(), _bbox_data.shape =%s", self._bbox_store.data.shape
        )
        logger.debug("current_edge_width =%s", self.current_edge_width)
        self._spatial_index = SpatialIndex(self.bounding_boxes)
        self._sync_shapes_from_bboxes()
        if self.nshapes > 0 and hasattr(self, "current_edge_width"):
            logger.debug("Forcing edge_width to%s", self.current_edge_width)
            self.edge_width = self.current_edge_width
            logger.debug("After forcing: edge_width =%s", self.edge_width)
        logger.info("_sync_shapes_from_bboxes() completed")
        if hasattr(self, "_undo_stack"):
            n_added = len(new_boxes)
            self._undo_stack.push(
                self.bounding_boxes.copy(), f"Add {n_added} box{('es' if n_added > 1 else '')}"
            )
        self.events.bboxes(value=self.bounding_boxes)
        self._event_manager.emit("added", self.bounding_boxes)

    def _safe_set_shape_data(
        self, paths: list[np.ndarray], shape_type: str | None = None
    ) -> bool:
        """Push path data into the underlying Shapes layer; return False if napari refused it.

        Works around empty-shapes rendering issues in napari. When
        ``shape_type`` is given, each path is tagged with it so napari builds
        shapes of that type — the 3D wireframe must be ``'path'`` (it is a
        non-planar, self-touching polyline and would be mis-triangulated as a
        polygon). When ``shape_type`` is None the existing behaviour is kept.

        napari's data setter sizes the new shapes and data view by the viewer's
        ``ndisplay``, while ``Shapes._set_view_slice`` keeps the data view at
        ``min(ndim, ndisplay)``; a 2D layer in a 3D viewer then raises on any
        data set (plain Shapes does too). The setter therefore sees ``ndisplay``
        capped at the layer's ndim.
        """
        slice_input = self._slice_input
        capped = not hasattr(self, "_mock_slice_input") and slice_input.ndisplay > self.ndim
        if capped:
            self._mock_slice_input = dataclasses.replace(slice_input, ndisplay=self.ndim)
        try:
            if not paths:
                self.data = np.empty((0, 2, self.ndim), dtype=float)
            elif shape_type is not None:
                self.data = [(np.asarray(p, dtype=float), shape_type) for p in paths]
            else:
                self.data = paths
        except ValueError:
            if not capped:
                raise
            # napari < 0.7 ignores _mock_slice_input and cannot set Shapes data
            # while a lower-dimensional layer is shown in 3D; the view is
            # redrawn when the viewer returns to 2D display.
            logger.warning("2D box layer not redrawn while the viewer shows 3D (napari < 0.7)")
            return False
        finally:
            if capped:
                del self._mock_slice_input
                # Back to napari's state after a display toggle: the viewer's
                # ndisplay is stored, and the layer is editable only in 2D display.
                self._ndisplay_stored = slice_input.ndisplay
                self._reset_editable()
        return True

    def clear_boxes(self) -> None:
        if not self._interactive:
            logger.warning("Layer is in read-only mode (interactive=False), ignoring clear_boxes")
            return
        if self._bbox_store.data.size == 0:
            return
        n_boxes = len(self._bbox_store.data)
        self._bbox_store.clear()
        if hasattr(self, "_undo_stack"):
            self._undo_stack.push(
                self.bounding_boxes.copy(), f"Clear {n_boxes} box{('es' if n_boxes > 1 else '')}"
            )
        self._event_manager.emit("cleared", self.bounding_boxes)

    def subscribe(self, subscriber) -> None:
        """Subscribe to external bbox change notifications."""
        self._event_manager.subscribe(subscriber)

    def unsubscribe(self, subscriber) -> None:
        self._event_manager.unsubscribe(subscriber)

    def _clamp_to_valid_range(self, boxes: np.ndarray) -> np.ndarray:
        """Actively coerce boxes to satisfy the box invariant (producer side).

        Used by the drag / resize paths, which legitimately produce
        out-of-range values and are expected to fix them up. When
        ``image_shape`` is set, mins and maxs are clipped into
        ``[0, image_shape - 1]``; then a minimum extent of 1 is enforced on
        every axis with the heuristic "max wins, min follows":

        - if ``max >= 1``: ``min = max - 1``
        - else (box against the lower edge): ``max = 1``, ``min = 0``

        Parameters
        ----------
        boxes : np.ndarray
            Boxes of shape (N, 2, ndim).

        Returns
        -------
        np.ndarray
            A new array of valid boxes (same shape).
        """
        if boxes.size == 0:
            return boxes
        boxes = np.array(boxes, dtype=float)
        upper = self._axis_maxes()  # image_shape - 1, or None
        if upper is not None:
            boxes[:, 0] = np.clip(boxes[:, 0], 0.0, upper)
            boxes[:, 1] = np.clip(boxes[:, 1], 0.0, upper)
        mins = boxes[:, 0]
        maxs = boxes[:, 1]
        too_thin = (maxs - mins) < 1.0
        pull_min = too_thin & (maxs >= 1.0)
        mins[pull_min] = maxs[pull_min] - 1.0
        push_max = too_thin & (maxs < 1.0)
        maxs[push_max] = 1.0
        mins[push_max] = 0.0
        return boxes

    def _validate_box(self, boxes: np.ndarray) -> None:
        """Raise ``ValueError`` if any box violates the box invariant.

        Per axis ``i``: ``0 <= mins[i]``, ``maxs[i] <= image_shape[i] - 1``
        and ``maxs[i] - mins[i] >= 1``. When ``image_shape`` is None only the
        minimum-extent rule is checked (no upper/lower bounds).

        This is the consumer-side guard for the API entry points
        (``add_boxes``, the ``bounding_boxes`` setter,
        ``_on_shapes_data_changed``) — no silent clamping there; invalid
        input is rejected outright.

        Parameters
        ----------
        boxes : np.ndarray
            Boxes of shape (N, 2, ndim).
        """
        boxes = np.asarray(boxes, dtype=float)
        if boxes.size == 0:
            return
        upper = self._axis_maxes()  # None if image_shape is None
        for b, box in enumerate(boxes):
            mins, maxs = box[0], box[1]
            for i in range(self.ndim):
                if upper is not None:
                    if mins[i] < 0:
                        raise ValueError(
                            f"Box {b} axis {i}: min ({mins[i]}) is below 0"
                        )
                    if maxs[i] > upper[i]:
                        raise ValueError(
                            f"Box {b} axis {i}: max ({maxs[i]}) exceeds "
                            f"image_shape - 1 ({upper[i]:g})"
                        )
                # float32 storage may round an extent of exactly 1 slightly below 1
                tol = 4 * np.finfo(np.float32).eps * max(1.0, abs(mins[i]), abs(maxs[i]))
                if maxs[i] - mins[i] < 1.0 - tol:
                    raise ValueError(
                        f"Box {b} axis {i}: min-max distance "
                        f"({maxs[i] - mins[i]:g}) below required minimum 1"
                    )

    def _is_3d_view(self) -> bool:
        """True when the layer is currently rendering in 3D (ndisplay == 3).

        This is exactly the regime in which ``_current_paths`` emits single
        wireframe paths, which must be set as ``shape_type='path'``. A 2D layer
        in a 3D viewer only has two displayed axes and keeps its 2D slice view.
        """
        slice_input = getattr(self, "_slice_input", None)
        return (
            slice_input is not None
            and getattr(slice_input, "ndisplay", None) == 3
            and self.ndim >= 3
        )

    def _sync_shapes_from_bboxes(self) -> None:
        """Write the canonical bbox representation back to the Shapes data."""
        self._sync_guard = True
        try:
            self._pending_shape_state = (None, None, None)
            paths = self._current_paths()
            # Pin shape_type explicitly per render mode. Passing None lets
            # napari fall back to its internal shape_type memory, which can
            # carry over a stale 'rectangle' from the add-rectangle mouse
            # binding — napari then tries to build a Rectangle (4 vertices)
            # from our 5-vertex closed slice path and raises ValueError.
            # 3D wireframe = 'path' (non-planar polyline); 2D slice = 'polygon'.
            shape_type = "path" if self._is_3d_view() else "polygon"
            # napari's data setter gives new shapes width 1 and refreshes; the
            # width is then set for all shapes, which refreshes again. Block both
            # and refresh once.
            with self._block_refresh():
                if not self._safe_set_shape_data(paths, shape_type):
                    self._shapes_mode = None  # nothing drawn: no incremental edits
                    return
                if hasattr(self, "current_edge_width"):
                    self.edge_width = self.current_edge_width
            self.refresh()
            # Remember which box each shape shows, so single-box edits can be
            # applied to one shape instead of rebuilding the whole layer.
            mode, box_ids, view_key = self._pending_shape_state
            self._shapes_mode = mode
            self._shape_box_ids = box_ids
            self._shapes_view_key = view_key
        finally:
            self._sync_guard = False

    def _on_store_session_ended(self, event=None) -> None:
        """Rasterize the thumbnail once if it was skipped during the session."""
        if getattr(self, "_thumbnail_stale", False):
            self._update_thumbnail()

    def _slice_query(self):
        """Return ``(current_step, displayed, view_key)`` for the current 2D slice."""
        slice_input = self._slice_input
        displayed = tuple(slice_input.displayed)
        point = self._slice_point_data()
        # Keyed on the data-space point the paths are built at, so a changed
        # scale or translate (same world point, different data point) is a new view.
        view_key = (slice_input.ndisplay, displayed, tuple(np.round(point, decimals=6)))
        return point, displayed, view_key

    def _slice_point_data(self) -> np.ndarray:
        """Current slice point in this layer's data coordinates (boxes live in data space)."""
        pt = np.asarray(self._slice_input.world_slice.point, dtype=float)
        if len(pt) < self.ndim:
            pt = np.pad(pt, (self.ndim - len(pt), 0), constant_values=0)
        return np.asarray(self.world_to_data(pt), dtype=float)

    def _incremental_shape_update(self, changed_idx: int, new_data: np.ndarray) -> bool:
        """Apply a single-box change to its one shape instead of a full rebuild.

        A box that enters or leaves the slice gets its shape added or removed
        (``_add_or_remove_shape``). Returns ``False`` when the change cannot be
        applied incrementally (the view changed since the last full rebuild,
        the shape bookkeeping is unknown, or an enter/leave that only a full
        rebuild handles); the caller then falls back to a full rebuild.
        """
        mode = getattr(self, "_shapes_mode", None)
        if mode is None or self._sync_guard:
            return False
        bbox = np.asarray(new_data[changed_idx], dtype=float)
        if mode == "3d":
            if not self._is_3d_view() or self.nshapes != len(new_data):
                return False
            pos = int(changed_idx)
            path = wireframe_path_from_bbox(bbox)
        else:
            if self._is_3d_view():
                return False
            box_ids = self._shape_box_ids
            current_step, displayed, view_key = self._slice_query()
            if view_key != self._shapes_view_key or self.nshapes != len(box_ids):
                return False
            pos = int(np.searchsorted(box_ids, changed_idx))
            was_visible = pos < len(box_ids) and box_ids[pos] == changed_idx
            new_paths = slice_paths_from_bbox(bbox, displayed, current_step)
            if not was_visible and not new_paths:
                return True  # off-slice before and after: nothing to draw
            if not (was_visible and new_paths):
                # enters or leaves the slice
                path = np.asarray(new_paths[0], dtype=float) if new_paths else None
                return self._add_or_remove_shape(pos, int(changed_idx), path)
            path = new_paths[0]
        self._sync_guard = True
        try:
            self._edit_shape(pos, np.asarray(path, dtype=float))
            if self._shapes_mode is None:
                return False  # the shape's row counts changed: full rebuild
            self.refresh()
            if pos in self.selected_data:
                # napari recomputes the selection's interaction box and outline
                # only when the selection changes; the selected box itself moved.
                self._selected_box = self.interaction_box(self.selected_data)
                self._set_highlight(force=True)
        finally:
            self._sync_guard = False
        return True

    def _add_or_remove_shape(self, pos: int, box_idx: int, path: np.ndarray | None) -> bool:
        """Show a box that entered the slice (``path``) or hide one that left it (``None``).

        A full rebuild re-creates every visible shape. Here only the one shape
        is added at, or removed from, its place ``pos`` in the sorted visible
        order, and the selection and hover state a rebuild resets are reset
        the same way, so the shapes, colours, z-order and displayed arrays are
        those of a full rebuild. Like an in-slice edit, it emits no napari
        ``data`` event. Returns ``False`` (full rebuild) when that cannot be
        guaranteed: shapes with their own style (see ``_uniform_shape_style``),
        an empty view before or after, a layer without ``image_shape`` (its
        extent follows the shapes shown, and the viewer only re-reads it on
        the ``data`` events of a rebuild), or a napari without the ShapeList
        internals used here. If napari raises part-way, the exception is passed
        on and the next update rebuilds the view.
        """
        dv = self._data_view
        n = len(dv.shapes)
        mesh = getattr(dv, "_mesh", None)
        indices = (getattr(dv, "_vertices_index", ()), getattr(mesh, "vertices_index", ()),
                   getattr(mesh, "triangles_index", ()))
        if (
            self._image_shape is None
            or n < (1 if path is not None else 2)
            or self._slice_input.ndisplay != 2
            or any(len(index) != n + 1 for index in indices)
            or not all(hasattr(dv, name) for name in ("_update_z_order", "_clear_cache"))
            or not hasattr(self, "_feature_table")
        ):
            return False
        style = self._uniform_shape_style(entering=path is not None)
        if style is None:
            return False
        edge_color, face_color = style
        self._sync_guard = True
        try:
            # What napari's data setter does before it replaces the shapes.
            with self._block_refresh():
                self._finish_drawing()
            if self.selected_data:
                self.selected_data = set()
            with dv.batched_updates():
                if path is not None:
                    from napari.layers.shapes._shapes_models import Polygon

                    slice_input = self._slice_input
                    shape = Polygon(
                        path,
                        edge_width=self.current_edge_width,
                        z_index=0,
                        dims_order=slice_input.order,
                        ndisplay=slice_input.ndisplay,
                    )
                    # The list form takes napari's batch path, the one a full
                    # rebuild uses (it keeps napari's float32/int32 arrays).
                    dv.add([shape], face_color=[face_color], edge_color=[edge_color], z_refresh=False)
                    _move_last_shape(dv, pos)
                    dv._update_z_order()
                    dv._clear_cache()
                    self._shape_box_ids = np.insert(self._shape_box_ids, pos, box_idx)
                else:
                    dv.remove(pos)  # also re-derives the z-order
                    # napari's Shapes.remove drops the colours itself, not the ShapeList.
                    dv._edge_color = np.delete(dv._edge_color, pos, axis=0)
                    dv._face_color = np.delete(dv._face_color, pos, axis=0)
                    self._shape_box_ids = np.delete(self._shape_box_ids, pos)
            self._feature_table.resize(len(dv.shapes))
            self.refresh()
        except Exception:
            # napari failed part-way: its shape list may hold one shape more or less
            # than its colour and index arrays. The next update rebuilds the view, and
            # a rebuild takes each shape's colour from here: give every shape the
            # colours they all share (see _uniform_shape_style).
            self._shapes_mode = None
            n = len(dv.shapes)
            dv._edge_color = np.repeat([edge_color], n, axis=0).astype(dv._edge_color.dtype)
            dv._face_color = np.repeat([face_color], n, axis=0).astype(dv._face_color.dtype)
            dv._z_index = np.asarray(dv.z_indices, dtype=dv._z_index.dtype)
            raise
        finally:
            self._sync_guard = False
        return True

    def _uniform_shape_style(self, entering: bool) -> tuple[np.ndarray, np.ndarray] | None:
        """Edge and face colour for a shape added or removed in place, or None.

        napari's data setter hands z-index, colours and edge width to the new
        shapes by position (it keeps the old values of the first shapes and
        pads the rest), and ``_sync_shapes_from_bboxes`` then sets every edge
        width to ``current_edge_width``. Adding or removing one shape in place
        gives the same layer only while no shape has a style of its own: all
        z-indices are 0 (an entering shape gets 0) or, for a removal, equal;
        all shapes share one edge and one face colour, which for an entering
        shape must be the colour napari gives a new shape; every edge width is
        ``current_edge_width``; the layer has no features and constant text.
        A fresh TurboBox layer is always in this state; napari's per-shape
        tools (move to front, colouring selected shapes) leave it, and the
        layer then keeps the full rebuild.
        """
        dv = self._data_view
        z_index = np.asarray(dv._z_index)
        if np.any(z_index != (0 if entering else z_index[0])):
            return None
        if self._feature_table.values.shape[1] or not all(
            hasattr(encoding, "constant") for encoding in (self.text.string, self.text.color)
        ):
            return None
        width = self.current_edge_width
        if any(shape.edge_width != width for shape in dv.shapes):
            return None
        if entering:
            from napari.layers.utils.color_transformations import (
                normalize_and_broadcast_colors,
                transform_color_with_defaults,
            )

            colors = []
            for attribute in ("edge", "face"):
                color = transform_color_with_defaults(
                    num_entries=1,
                    colors=self._get_new_shape_color(1, attribute=attribute),
                    elem_name=f"{attribute}_color",
                    default="white",
                )
                colors.append(np.asarray(normalize_and_broadcast_colors(1, color), np.float32)[0])
            edge_color, face_color = colors
        else:
            edge_color, face_color = dv._edge_color[0], dv._face_color[0]
        if not (np.all(dv._edge_color == edge_color) and np.all(dv._face_color == face_color)):
            return None
        return edge_color, face_color

    def _edit_shape(self, pos: int, path: np.ndarray) -> None:
        """Replace the vertices of shape ``pos`` in napari's shape list.

        ``ShapeList.edit`` re-derives the displayed-shape bookkeeping and the
        z-order of *all* shapes after every edit, which is O(N_visible) Python
        work. A box edit keeps the shape's slice, z-index and triangulation,
        so neither changes: the shape's vertices are updated in place and only
        its rows of the displayed-vertex copy are refreshed. A changed
        triangulation with the same counts (e.g. a box that becomes one voxel
        thin) or a napari without these internals falls back to
        ``ShapeList.edit``, which also rebuilds the displayed triangles. Other
        counts (only a box with a zero extent has them) are left to a full
        rebuild: ``ShapeList.edit`` would keep or move the shape's row slot,
        which napari < 0.7 gets wrong, so ``_shapes_mode`` is cleared and the
        caller rebuilds.
        """
        dv = self._data_view
        shape = dv.shapes[pos]
        before = (shape.vertices_count, getattr(shape, "face_vertices_count", None),
                  shape.triangles_count, shape.data_displayed.shape[0])
        face0 = np.array(getattr(shape, "_face_triangles", None))
        edge0 = np.array(getattr(shape, "_edge_triangles", None))
        shape.data = path
        after = (shape.vertices_count, getattr(shape, "face_vertices_count", None),
                 shape.triangles_count, shape.data_displayed.shape[0])
        same_triangulation = (
            face0.ndim == 2
            and edge0.ndim == 2
            and np.array_equal(face0, getattr(shape, "_face_triangles", None))
            and np.array_equal(edge0, getattr(shape, "_edge_triangles", None))
        )
        rows = None
        if before == after and same_triangulation and hasattr(dv, "_ShapeList__update_displayed_called"):
            vslice = dv._vertices_slice_available(pos)
            rows = np.flatnonzero(dv.displayed_vertices_to_shape_num == pos)
            if len(rows) not in (0, vslice.stop - vslice.start):
                rows = None
        if rows is None:
            if before != after:
                self._shapes_mode = None
                return
            dv.edit(pos, path)
            return
        pending = dv._ShapeList__update_displayed_called
        with dv.batched_updates():
            dv._update_vertices(pos)
            dv._update_mesh_triangles(pos)
            dv._update_mesh_vertices(pos, edge=True, face=True)
            # The displayed set and its order are unchanged: skip the O(N)
            # recomputation that the updates above schedule.
            dv._ShapeList__update_displayed_called = pending
        if len(rows):
            dv.displayed_vertices[rows] = dv._vertices[vslice]

    def _update_thumbnail(self, *args, **kwargs):
        """Honour ``_allow_thumbnail_update`` to skip thumbnail rasterization.

        napari rasterizes the layer thumbnail on every refresh. During a drag
        (``_allow_thumbnail_update`` is set ``False`` at mouse-press) that cost
        is paid once per frame for no visible benefit -- the thumbnail is
        re-rasterized once at release. Outside a drag the flag is ``True`` and
        behaviour is unchanged. Mirrors napari-bbox's ``_is_moving``-gated
        thumbnail suppression.
        """
        if not getattr(self, "_allow_thumbnail_update", True):
            return
        store = getattr(self, "_bbox_store", None)
        if (
            store is not None
            and store.in_edit_session
            and getattr(self, "suppress_thumbnail_in_session", True)
        ):
            # Rasterized once at session end (_on_store_session_ended).
            self._thumbnail_stale = True
            return
        self._thumbnail_stale = False
        return super()._update_thumbnail(*args, **kwargs)

    def _current_paths(self) -> list[np.ndarray]:
        """Generate appropriate path representations based on current view mode.

        Uses intelligent caching to avoid redundant geometry calculations when
        the view state hasn't changed (e.g., during rendering or event processing
        without actual view changes).
        """
        if not self._bbox_store.data.size:
            return []
        if not hasattr(self, "_slice_input") or self._slice_input is None:
            logger.warning(
                "_current_paths: _slice_input not available, using default edge representation"
            )
            return paths_from_bboxes(self._bbox_store.data)
        slice_input = self._slice_input
        view_key = (
            slice_input.ndisplay,
            tuple(slice_input.displayed) if hasattr(slice_input, "displayed") else None,
            None,
        )
        if not self._is_3d_view():
            current_step, _, view_key_2d = self._slice_query()
            view_key = view_key_2d
            query_mins = np.full(self.ndim, -np.inf)
            query_maxs = np.full(self.ndim, np.inf)
            tolerance = 1e-06
            hidden_axes = [ax for ax in range(self.ndim) if ax not in slice_input.displayed]
            for ax in hidden_axes:
                query_mins[ax] = current_step[ax] - tolerance
                query_maxs[ax] = current_step[ax] + tolerance
            query_box = np.stack([query_mins, query_maxs], axis=0)
            # Sorted, so shape k shows the k-th visible box in index order
            # (the window query returns candidates in coordinate order).
            visible_indices = np.sort(
                np.asarray(self._spatial_index.intersection(query_box), dtype=np.intp)
            )
            self._pending_shape_state = ("2d", visible_indices, view_key_2d)
            if not len(visible_indices):
                return []
            paths = []
            visible_boxes = self._bbox_store.data[visible_indices]
            if len(visible_indices) > 1000:
                return slice_paths_from_bboxes(visible_boxes, slice_input.displayed, current_step)
            for bbox in visible_boxes:
                box_hash = hash(bbox.tobytes())
                cached = self._path_cache.get(box_hash)
                if cached and cached[1] == view_key:
                    paths.extend(cached[0])
                else:
                    new_paths = slice_paths_from_bbox(bbox, slice_input.displayed, current_step)
                    self._path_cache[box_hash] = (new_paths, view_key)
                    paths.extend(new_paths)
                    if len(self._path_cache) > self._cache_max_size:
                        items = list(self._path_cache.items())
                        self._path_cache = dict(items[-self._cache_max_size // 2 :])
                        logger.debug(
                            "Cache eviction: kept%s/%sentries",
                            len(self._path_cache),
                            self._cache_max_size,
                        )
            return paths
        elif self.ndim == 3:
            logger.debug("_current_paths: 3D mode - generating wireframe paths")
            self._pending_shape_state = ("3d", None, None)
            paths = []
            for bbox in self._bbox_store.data:
                box_hash = hash(bbox.tobytes())
                cached = self._path_cache.get(box_hash)
                if cached and cached[1] == view_key:
                    paths.extend(cached[0])
                else:
                    # One wireframe path per box (was 6 face loops). Cached
                    # value stays a list so the extend/cache logic is shared
                    # with the 2D branch.
                    new_paths = [wireframe_path_from_bbox(bbox)]
                    self._path_cache[box_hash] = (new_paths, view_key)
                    paths.extend(new_paths)
            return paths
        else:
            logger.debug("_current_paths: Fallback - using edge representation")
            return paths_from_bboxes(self._bbox_store.data)

    def _on_shared_data_changed(self, new_data: np.ndarray, changed_idx=None) -> None:
        """
        Callback when shared bbox store data changes.
        """
        self._perform_sync(new_data, changed_idx=changed_idx)

    def _perform_sync(self, new_data: np.ndarray, changed_idx=None) -> None:
        """Actual synchronization logic."""
        logger.debug("_perform_sync:%sboxes (interactive=%s)", len(new_data), self._interactive)
        old_count = self._spatial_index._count if hasattr(self, "_spatial_index") else 0
        new_count = len(new_data)
        single_box_edit = False
        if new_count == 0:
            self._spatial_index = SpatialIndex(self.bounding_boxes)
            logger.debug("Rebuilt spatial index (empty)")
        elif old_count == 0:
            self._spatial_index = SpatialIndex(self.bounding_boxes)
            logger.debug("Built spatial index (%sboxes)", new_count)
        elif new_count == old_count:
            if changed_idx is not None:
                self._spatial_index.update_box(changed_idx, new_data[changed_idx])
                single_box_edit = True
                logger.debug("Incremental spatial index update for box%s", changed_idx)
            else:
                self._spatial_index = SpatialIndex(self.bounding_boxes)
                logger.debug("Rebuilt spatial index (%sboxes, same count)", new_count)
        elif new_count > old_count:
            n_added = new_count - old_count
            # Incremental add is only valid for an append: a re-insert (undo of a
            # delete) or a batch with in-place edits shifts or changes old rows.
            appended = np.array_equal(
                self._spatial_index._boxes, np.asarray(new_data[:old_count], dtype=np.float32)
            )
            if appended and (n_added <= 10 or n_added / old_count < 0.2):
                new_boxes = self.bounding_boxes[old_count:]
                self._spatial_index.add_boxes(new_boxes)
                logger.debug("Incremental add:%sboxes (total=%s)", n_added, new_count)
            else:
                self._spatial_index = SpatialIndex(self.bounding_boxes)
                logger.debug("Rebuilt spatial index (added%sboxes, total=%s)", n_added, new_count)
        else:
            self._spatial_index = SpatialIndex(self.bounding_boxes)
            logger.debug(
                "Rebuilt spatial index (removed%sboxes, total=%s)", old_count - new_count, new_count
            )
            current_hashes = {hash(bbox.tobytes()) for bbox in new_data}
            self._path_cache = {h: v for h, v in self._path_cache.items() if h in current_hashes}
        if not (single_box_edit and self._incremental_shape_update(changed_idx, new_data)):
            self._sync_shapes_from_bboxes()
        # Read-only view of the shared store: no per-layer (N, 2, D) copy per notification.
        view = self._bbox_store.data
        self.events.bboxes(value=view)
        self._event_manager.emit("updated", view)

    def _set_view_slice(self) -> None:
        """Override napari's view slice update to regenerate paths."""
        if not hasattr(self, "_sync_guard") or not hasattr(self, "_bbox_store"):
            super()._set_view_slice()
            return
        super()._set_view_slice()
        if (
            not self._sync_guard
            and self._bbox_store.data.size > 0
            and not getattr(self, "_is_creating", False)
            and not getattr(self, "_napari_adding", False)
        ):
            logger.debug(
                "_set_view_slice called - regenerating paths (ndisplay=%s)",
                self._slice_input.ndisplay if self._slice_input else "?",
            )
            self._sync_shapes_from_bboxes()

    def _axis_maxes(self) -> np.ndarray | None:
        if self._image_shape is not None:
            maxes = self._image_shape.astype(float) - 1.0
            maxes[maxes < 0] = 0.0
            return maxes
        return None

    def _expand_hidden_axes(self, bbox: np.ndarray) -> np.ndarray:
        bbox = np.asarray(bbox, dtype=float)
        mins, maxs = bbox
        expanded = np.stack([mins.copy(), maxs.copy()], axis=0)
        if hasattr(self, "_slice_input") and self._slice_input is not None:
            displayed = set(self._slice_input.displayed)
            maxes_hint = self._axis_maxes()
        else:
            if self._interactive:
                logger.warning(
                    "_expand_hidden_axes called but _slice_input is None. Expansion skipped."
                )
            return expanded
        expanded_count = 0
        for axis in range(self.ndim):
            if axis in displayed:
                continue
            if np.isclose(expanded[0, axis], expanded[1, axis], atol=1e-05):
                expanded[0, axis] = 0.0
                if (
                    maxes_hint is not None
                    and axis < maxes_hint.size
                    and (not np.isnan(maxes_hint[axis]))
                ):
                    expanded[1, axis] = maxes_hint[axis]
                else:
                    expanded[1, axis] = expanded[1, axis] + 1.0
                expanded_count += 1
        if expanded_count > 0:
            logger.debug("Expanded%shidden axes for new bbox", expanded_count)
        return expanded

    def _normalize_image_shape(
        self, image_shape: Sequence[int] | None, ndim: int
    ) -> np.ndarray | None:
        if image_shape is None:
            return None
        arr = np.asarray(image_shape, dtype=float)
        if arr.size > ndim:
            arr = arr[-ndim:]
        elif arr.size < ndim:
            arr = np.pad(arr, (ndim - arr.size, 0), mode="edge")
        return arr

    def _connect_dims_events(self) -> None:
        """Legacy method - no longer needed with _set_view_slice approach."""
        if not self._dims_connected:
            self._dims_connected = True
            logger.info(
                "_connect_dims_events: Using _set_view_slice for updates (no manual connection needed)"
            )

    def _on_mode_change(self, event) -> None:
        """Handle mode changes to guide users."""
        from napari.layers.shapes._shapes_constants import Mode

        mode = event.value if hasattr(event, "value") else self.mode
        if isinstance(mode, str):
            try:
                mode = Mode(mode)
            except ValueError:
                logger.warning("Unknown mode:%s", mode)
                return
        if mode == Mode.TRANSFORM:
            logger.error("TRANSFORM mode is NOT supported for axis-aligned bounding boxes!")
            logger.debug("Bounding boxes must stay parallel to X/Y/Z axes (no rotation allowed)")
            logger.debug("Switching back to SELECT mode...")
            self.mode = Mode.SELECT
            return
        blocked_add_modes = {
            Mode.ADD_ELLIPSE,
            Mode.ADD_LINE,
            Mode.ADD_PATH,
            Mode.ADD_POLYGON,
            Mode.ADD_POLYGON_LASSO,
        }
        if mode in blocked_add_modes:
            logger.error("'Add%s' mode is NOT supported for bounding boxes!", mode.name)
            logger.debug("Use 'Add Rectangle' mode instead to draw axis-aligned bboxes")
            self.mode = Mode.SELECT
            return
        elif mode == Mode.ADD_RECTANGLE:
            logger.info("ADD_RECTANGLE mode active")
            logger.debug("Click and drag to draw a bounding box")
            logger.debug("The box will automatically extend through hidden dimensions")
        elif mode == Mode.SELECT:
            logger.info("SELECT mode active")
            logger.debug("Click inside bbox center  Move it")
            logger.debug("Click near edge/corner  Resize it")
        elif mode == Mode.PAN_ZOOM:
            logger.debug("PAN_ZOOM mode: Navigate the view (hold Space anytime)")

    def _on_parent_change(self, event) -> None:
        """Called when layer is added to/removed from a viewer."""
        if not self._sync_guard and self._bbox_store.data.size > 0:
            self._sync_shapes_from_bboxes()

    def _on_shapes_data_changed(self, event) -> None:
        """Map a napari-side shape edit onto the store by ``event.action``.

        The store is authoritative and the view shows only the boxes that
        intersect the current slice, so the store is never rebuilt from
        ``self.data``. Pre-change events (adding/removing/changing) never write;
        a finished drawing (added) appends one box (hidden axes extruded,
        clamped; a click without drag is dropped); a removal (removed) deletes
        exactly the boxes behind the removed shapes; any other napari edit
        (changed) is discarded by re-syncing from the store. Read-only layers
        never write.
        """
        if self._sync_guard:
            return
        if hasattr(self, "_bbox_is_moving") and self._bbox_is_moving:
            return
        action = str(getattr(event, "action", "") or "")
        if action in ("adding", "removing", "changing"):
            # Pre-change events: remember what napari is about to do; never write.
            if action == "removing":
                box_ids = self._displayed_box_ids()
                self._pending_remove = [
                    int(box_ids[p])
                    for p in getattr(event, "data_indices", ())
                    if box_ids is not None and 0 <= p < len(box_ids)
                ]
            elif action == "adding":
                self._napari_adding = True  # keep napari's new shape until 'added'
            return
        self._napari_adding = False
        pending, self._pending_remove = self._pending_remove, None
        if getattr(self, "_just_finished_drag", False):
            # napari's own post-release event of a TurboBox drag: nothing to write.
            self._just_finished_drag = False
            if action not in ("added", "removed"):
                return
        if not self._interactive:
            self._sync_shapes_from_bboxes()
            return
        if action == "removed":
            if pending:
                self._bbox_store.remove_boxes(sorted(set(pending)))
                self._undo_stack.push(self.bounding_boxes.copy(), f"Delete {len(pending)} box(es)")
            else:
                self._sync_shapes_from_bboxes()
            return
        if action == "added" and len(self.data) > 0:
            bbox = bbox_from_path(np.asarray(self.data[-1], dtype=float))
            self._sync_shapes_from_bboxes()  # drop napari's shape; the store re-renders it
            if bbox is None or self._slice_input is None:
                return
            disp = list(self._slice_input.displayed)
            if np.any(bbox[1, disp] - bbox[0, disp] < 1.0):
                return  # click without drag: no box
            if self._auto_extrude and self._is_2d_box(bbox):
                bbox = self._auto_extrude_bbox(bbox)
            bbox = self._expand_hidden_axes(bbox)
            self.add_boxes(self._clamp_to_valid_range(bbox[None]))
            return
        self._sync_shapes_from_bboxes()  # 'changed' (vertex/move edits outside _on_mouse_drag)

    def _displayed_box_ids(self) -> np.ndarray | None:
        """Box index behind each currently displayed shape (None if unknown)."""
        mode = getattr(self, "_shapes_mode", None)
        if mode == "2d":
            return self._shape_box_ids
        if mode == "3d":
            return np.arange(len(self._bbox_store.data))
        return None

    def _is_2d_box(self, bbox: np.ndarray) -> bool:
        """Check if a bbox is essentially 2D (has a flat dimension)."""
        mins, maxs = bbox
        for axis in range(self.ndim):
            if np.isclose(mins[axis], maxs[axis]):
                return True
        return False

    def _auto_extrude_bbox(self, bbox: np.ndarray) -> np.ndarray:
        """Auto-extrude a 2D bbox to 3D."""
        if not hasattr(self, "_slice_input") or self._slice_input is None:
            logger.warning("Auto-extrude: _slice_input not available, returning bbox as-is")
            return bbox
        slice_input = self._slice_input
        displayed = slice_input.displayed
        current_step = self._slice_point_data()
        extrusion_range = None
        if self._image_shape is not None:
            hidden_axes = [ax for ax in range(self.ndim) if ax not in displayed]
            if hidden_axes:
                axis = hidden_axes[0]
                extrusion_range = (0.0, float(self._image_shape[axis] - 1))
        logger.debug(
            "Auto-extruding bbox with displayed=%s, current_step=%s, extrusion_range=%s",
            displayed,
            current_step,
            extrusion_range,
        )
        return extrude_2d_to_3d_box(bbox, displayed, current_step, extrusion_range)

    def _current_shape_box_ids(self) -> np.ndarray | None:
        """Box index shown by each 2D shape, if the bookkeeping matches the view."""
        box_ids = getattr(self, "_shape_box_ids", None)
        if (
            box_ids is None
            or getattr(self, "_slice_input", None) is None
            or getattr(self, "_shapes_mode", None) != "2d"
            or self._is_3d_view()
            or self.nshapes != len(box_ids)
        ):
            return None
        if self._slice_query()[2] != self._shapes_view_key:
            return None
        return box_ids

    def _bbox_index_to_path_index(self, bbox_idx: int) -> int | None:
        """Map a bbox index to its first corresponding shape/path index."""
        if not self._bbox_store.data.size or bbox_idx >= self._bbox_store.data.shape[0]:
            return None
        box_ids = self._current_shape_box_ids()
        if box_ids is not None:
            # O(log N): shape k shows the k-th visible box (sorted indices).
            pos = int(np.searchsorted(box_ids, bbox_idx))
            return pos if pos < len(box_ids) and box_ids[pos] == bbox_idx else None
        if getattr(self, "_shapes_mode", None) == "3d" and self._is_3d_view():
            return int(bbox_idx)
        cumulative = 0
        for i in range(bbox_idx):
            paths = self._paths_for_single_bbox(self._bbox_store.data[i])
            cumulative += len(paths)
        return cumulative

    def _path_index_to_bbox_index(self, path_idx: int) -> int | None:
        """Map a shape/path index to the corresponding bounding box index."""
        if not self._bbox_store.data.size:
            return None
        box_ids = self._current_shape_box_ids()
        if box_ids is not None:
            return int(box_ids[path_idx]) if 0 <= path_idx < len(box_ids) else None
        paths_per_bbox = self._count_paths_per_bbox()
        if paths_per_bbox == 0:
            return None
        bbox_idx = path_idx // paths_per_bbox
        if bbox_idx >= self._bbox_store.data.shape[0]:
            cumulative = 0
            for i, bbox in enumerate(self._bbox_store.data):
                paths = self._paths_for_single_bbox(bbox)
                cumulative += len(paths)
                if path_idx < cumulative:
                    return i
            return None
        return bbox_idx

    def _count_paths_per_bbox(self) -> int:
        """Count how many paths are generated per bbox in current view mode."""
        if not self._bbox_store.data.size:
            return 0
        first_bbox = self._bbox_store.data[0]
        paths = self._paths_for_single_bbox(first_bbox)
        return len(paths)

    def _paths_for_single_bbox(self, bbox: np.ndarray) -> list[np.ndarray]:
        """Generate paths for a single bbox in current view mode."""
        if not hasattr(self, "_slice_input") or self._slice_input is None:
            return path_from_bbox(bbox)
        slice_input = self._slice_input
        if not self._is_3d_view():
            current_step = self._slice_point_data()
            return slice_paths_from_bbox(bbox, slice_input.displayed, current_step)
        if self.ndim == 3:
            # One wireframe path per box — must match _current_paths' 3D
            # branch so path-index <-> bbox-index mapping stays consistent.
            return [wireframe_path_from_bbox(bbox)]
        return path_from_bbox(bbox)

    def _hit_test_bbox(self, position: np.ndarray) -> tuple[int | None, bool]:
        """Check if position is inside any bbox, considering only displayed dims."""
        if self._bbox_store.data.size == 0:
            return (None, False)
        current_step = np.zeros(self.ndim, dtype=float)
        displayed_axes = list(range(self.ndim))
        hidden_axes = []
        if hasattr(self, "_slice_input") and self._slice_input is not None:
            displayed_axes = tuple(self._slice_input.displayed)
            hidden_axes = [ax for ax in range(self.ndim) if ax not in displayed_axes]
            current_step = self._slice_point_data()
        elif hasattr(self, "dims"):
            displayed_axes = tuple(self.dims.displayed)
            hidden_axes = [ax for ax in range(self.ndim) if ax not in displayed_axes]
            current_step = np.asarray(self.dims.point, dtype=float)
        pos = np.asarray(position, dtype=float)
        if len(pos) < self.ndim:
            pos = np.pad(pos, (0, self.ndim - len(pos)), constant_values=0)
        elif len(pos) > self.ndim:
            pos = pos[: self.ndim]
        query_point = np.zeros(self.ndim, dtype=float)
        query_point[list(displayed_axes)] = pos[list(displayed_axes)]
        for ax in hidden_axes:
            query_point[ax] = current_step[ax]
        if hasattr(self, "_spatial_index"):
            candidates = self._spatial_index.query_point(query_point)
        else:
            candidates = range(self._bbox_store.data.shape[0])
        if len(candidates) == 0:
            return (None, False)
        candidates = sorted(candidates)
        # Nested/overlapping boxes: the innermost (smallest displayed area) box wins;
        # the stable sort keeps the lower index on ties.
        disp_list = list(displayed_axes)
        data = self._bbox_store.data
        candidates.sort(key=lambda i: float(np.prod(data[i, 1, disp_list] - data[i, 0, disp_list])))
        for i in candidates:
            bbox = self._bbox_store.data[i]
            mins, maxs = (bbox[0], bbox[1])
            pos_displayed = pos[list(displayed_axes)]
            mins_displayed = mins[list(displayed_axes)]
            maxs_displayed = maxs[list(displayed_axes)]
            bbox_size = maxs_displayed - mins_displayed
            edge_threshold = bbox_size * 0.2
            near_edge = np.any(pos_displayed - mins_displayed < edge_threshold) or np.any(
                maxs_displayed - pos_displayed < edge_threshold
            )
            if near_edge:
                logger.debug("Click is near edge/corner (resize mode)")
            else:
                logger.debug("Click is in center (move mode)")
            return (int(i), near_edge)
        logger.debug("Hit test: position%sis not inside any visible bbox on this slice", pos)
        return (None, False)

    def _reset_editable(self) -> None:
        """napari calls this after every data-setter call; keep read-only layers read-only."""
        super()._reset_editable()
        if not getattr(self, "_interactive", True):
            self.editable = False

    @Shapes.editable.setter
    def editable(self, editable: bool) -> None:
        # napari's layer controls also set ``editable`` directly (on creation and
        # on every display change): a read-only layer stays read-only.
        Shapes.editable.fset(self, editable and getattr(self, "_interactive", True))

    def _compute_vertices_and_box(self):
        """Override to ensure _value is always valid.

        This prevents TypeError when napari tries to access _value[0].
        """
        if self._value is None:
            self._value = (None, None)
        return super()._compute_vertices_and_box()

    def _get_value(self, position, *, world=False):
        """Override napari's hit testing to use our custom bbox hit test.

        This prevents napari from doing vertex/edge selection.

        MUST return (shape_index, vertex_index) or None.
        vertex_index must be an integer or None, NOT a string!
        """
        from napari.layers.shapes._shapes_constants import Mode

        in_add_mode = hasattr(self, "mode") and self.mode == Mode.ADD_RECTANGLE
        is_drawing = hasattr(self, "_mouse_drag_gen") and len(self._mouse_drag_gen) > 0
        if in_add_mode or is_drawing:
            logger.debug(
                "_get_value: Delegating to parent (in_add_mode=%s, is_drawing=%s)",
                in_add_mode,
                is_drawing,
            )
            return super()._get_value(position)
        if self._bbox_store.data.size == 0:
            return (None, None)
        bbox_idx, _ = self._hit_test_bbox(position)
        if bbox_idx is not None:
            path_idx = self._bbox_index_to_path_index(bbox_idx)
            if path_idx is not None:
                return (path_idx, None)
        return (None, None)

    def _on_mouse_drag(self, layer, event: Any):
        """Support translating (drag) and resizing (Shift+drag) bounding boxes.

        This is a generator function that napari calls for press, move, and release events.
        Note: napari 0.6.6+ passes layer as first argument to mouse callbacks.
        """
        from napari.layers.shapes._shapes_constants import Mode

        in_add_mode = hasattr(self, "mode") and self.mode == Mode.ADD_RECTANGLE
        is_drawing = hasattr(self, "_mouse_drag_gen") and len(self._mouse_drag_gen) > 1
        in_pan_zoom = hasattr(self, "mode") and self.mode == Mode.PAN_ZOOM
        if in_add_mode or is_drawing or in_pan_zoom or not self._interactive:
            logger.debug(
                "_on_mouse_drag: Skipping (in_add_mode=%s, is_drawing=%s, in_pan_zoom=%s)",
                in_add_mode,
                is_drawing,
                in_pan_zoom,
            )
            return
        logger.debug("_on_mouse_drag: event.type=%s", event.type)
        if event.type == "mouse_press":
            logger.debug(
                "mouse_press at position=%s, modifiers=%s", event.position, event.modifiers
            )
            press_pos = np.asarray(self.world_to_data(event.position), dtype=float)
            bbox_idx, is_near_edge = self._hit_test_bbox(press_pos)
            if bbox_idx is not None:
                logger.debug("Click inside bbox %s, forcing selection", bbox_idx)
                path_idx = self._bbox_index_to_path_index(bbox_idx)
                if path_idx is not None:
                    self.selected_data = {path_idx}
                    self._set_highlight(force=True)  # outline the newly grabbed box right away
                mode = "resize" if is_near_edge or "Shift" in event.modifiers else "translate"
                self._drag_state = {
                    "index": bbox_idx,
                    "start_bbox": self.bounding_boxes[bbox_idx].copy(),
                    "start_pos": press_pos,
                    "dims_displayed": tuple(event.dims_displayed),
                    "mode": mode,
                }
                self._bbox_is_moving = True
                # Suppress per-frame thumbnail rasterization for the duration of
                # the drag; re-enabled and rasterized once at release (finally).
                self._allow_thumbnail_update = False
                self._bbox_store.begin_edit_session()
                self._session_active = True
                logger.debug("Drag state initialized: mode=%s, bbox_idx=%s", mode, bbox_idx)
                event.handled = True
            else:
                self._drag_state = None
                logger.debug("No bbox hit, clearing drag state")
                return
        try:
            yield
            while event.type == "mouse_move":
                if not self._drag_state:
                    break
                logger.debug("mouse_move: dragging bbox %s", self._drag_state["index"])
                event.handled = True
                bbox_idx = self._drag_state["index"]
                if bbox_idx >= self._bbox_store.data.shape[0]:
                    logger.warning("bbox_idx%sout of range", bbox_idx)
                    break
                current_pos = np.asarray(self.world_to_data(event.position), dtype=float)
                start_pos = self._drag_state["start_pos"]
                delta = current_pos - start_pos
                dims_displayed = self._drag_state["dims_displayed"]
                start_bbox = self._drag_state["start_bbox"]
                if self._drag_state["mode"] == "translate":
                    nd_delta = np.zeros(self.ndim, dtype=float)
                    for axis in dims_displayed:
                        if axis < self.ndim:
                            nd_delta[axis] = delta[axis]
                    upper = self._axis_maxes()
                    if upper is not None:
                        # Stop the box at the image border instead of letting
                        # the per-coordinate clamp below shrink it.
                        nd_delta = np.clip(nd_delta, -start_bbox[0], upper - start_bbox[1])
                    new_bbox = start_bbox + np.stack([nd_delta, nd_delta], axis=0)
                    logger.debug("Translating by%s", nd_delta)
                else:
                    new_bbox = start_bbox.copy()
                    center = start_bbox.mean(axis=0)
                    for axis in dims_displayed:
                        if axis >= self.ndim:
                            continue
                        if start_pos[axis] >= center[axis]:
                            new_bbox[1, axis] = start_bbox[1, axis] + delta[axis]
                        else:
                            new_bbox[0, axis] = start_bbox[0, axis] + delta[axis]
                    mins = np.minimum(new_bbox[0], new_bbox[1])
                    maxs = np.maximum(new_bbox[0], new_bbox[1])
                    # Enforce a minimum extent of 1 per axis before clamping,
                    # so resizing against an edge cannot collapse the box.
                    # Same "max wins, min follows" heuristic as
                    # _clamp_to_valid_range, which re-adjusts below if needed.
                    thin = (maxs - mins) < 1.0
                    pull = thin & (maxs >= 1.0)
                    mins[pull] = maxs[pull] - 1.0
                    push = thin & (maxs < 1.0)
                    maxs[push] = 1.0
                    mins[push] = 0.0
                    new_bbox = np.stack([mins, maxs], axis=0)
                    logger.debug("Resizing")
                new_bbox = self._clamp_to_valid_range(new_bbox[None, ...])[0]
                # Notify listeners: live 2D views (incl. this one) re-render
                # from the store; on_commit (3D) views stay deferred.
                self._bbox_store.update_box(bbox_idx, new_bbox)
                yield
        finally:
            if self._session_active:
                self._bbox_store.end_edit_session()
                self._session_active = False
                logger.debug("finally: Edit session closed")
            drag_state_idx = self._drag_state["index"] if self._drag_state else None
            if self._drag_state:
                logger.debug(
                    "finally: Cleaning up drag state for bbox%s", self._drag_state["index"]
                )
            self._drag_state = None
            self._bbox_is_moving = False
            # Re-enable thumbnail updates; the final _sync_shapes_from_bboxes
            # below rasterizes the thumbnail exactly once for the whole drag.
            self._allow_thumbnail_update = True
            logger.debug("finally: Cleanup complete. _bbox_is_moving = False")
            self._just_finished_drag = True
            self._drag_end_time = time.time()
            logger.debug("finally: Set _just_finished_drag = True and timestamp")
            # Every drag step went through update_box and this layer's sync, so
            # its spatial index and shapes already show the final box. Rebuild
            # only if that bookkeeping is not intact (index count mismatch, or
            # the shapes no longer match the view); otherwise just rasterize the
            # thumbnail that was suppressed during the drag.
            idx_count = getattr(getattr(self, "_spatial_index", None), "_count", -1)
            if idx_count != len(self._bbox_store.data):
                self._spatial_index = SpatialIndex(self.bounding_boxes)
                self._sync_shapes_from_bboxes()
            elif drag_state_idx is None or (
                self._current_shape_box_ids() is None
                and not (getattr(self, "_shapes_mode", None) == "3d" and self._is_3d_view())
            ):
                self._sync_shapes_from_bboxes()
            else:
                self._update_thumbnail()
                if self.selected_data:
                    self._selected_box = self.interaction_box(self.selected_data)
                    self._set_highlight(force=True)
            if hasattr(self, "_undo_stack"):
                self._undo_stack.push(self.bounding_boxes.copy(), "Move/Resize box")
                logger.debug("finally: Pushed undo state")
            self.events.bboxes(value=self.bounding_boxes)
            self._event_manager.emit("updated", self.bounding_boxes)

    def undo(self, *args) -> bool:
        """
        Undo the last action.

        Returns
        -------
        bool
            True if undo was successful, False if no undo available
        """
        result = self._undo_stack.undo()
        if result:
            state, description = result
            self._undo_stack.disable()
            try:
                self.bounding_boxes = state
                logger.info("Undone:%s", description)
            finally:
                self._undo_stack.enable()
            return True
        return False

    def redo(self, *args) -> bool:
        """
        Redo the last undone action.

        Returns
        -------
        bool
            True if redo was successful, False if no redo available
        """
        result = self._undo_stack.redo()
        if result:
            state, description = result
            self._undo_stack.disable()
            try:
                self.bounding_boxes = state
                logger.info("Redone:%s", description)
            finally:
                self._undo_stack.enable()
            return True
        return False

    def can_undo(self) -> bool:
        """Check if undo is available."""
        return self._undo_stack.can_undo()

    def can_redo(self) -> bool:
        """Check if redo is available."""
        return self._undo_stack.can_redo()

    def clear_undo_history(self):
        """Clear all undo/redo history."""
        self._undo_stack.clear()
        logger.info("Cleared undo history")

    @property
    def undo_limit(self) -> int:
        """Maximum number of undo steps to remember."""
        return self._undo_stack.max_size

    @undo_limit.setter
    def undo_limit(self, value: int):
        """Set maximum number of undo steps."""
        if value < 1:
            raise ValueError("undo_limit must be at least 1")
        self._undo_stack.max_size = value
        logger.info("Undo limit set to%s", value)

    @property
    def cache_limit(self) -> int:
        """Maximum number of path cache entries."""
        return self._cache_max_size

    @cache_limit.setter
    def cache_limit(self, value: int):
        """Set maximum number of cache entries."""
        if value < 100:
            raise ValueError("cache_limit must be at least 100")
        self._cache_max_size = value
        logger.info("Cache limit set to%s", value)

    def get_undo_info(self) -> dict:
        """Get information about undo/redo state."""
        return {
            "can_undo": self.can_undo(),
            "can_redo": self.can_redo(),
            "undo_description": self._undo_stack.get_undo_description(),
            "redo_description": self._undo_stack.get_redo_description(),
            "history_size": self._undo_stack.size,
            "history_position": self._undo_stack.current_position,
            "memory_usage_kb": self._undo_stack.get_memory_usage() / 1024,
        }


def _install_drag_modes() -> None:
    from napari.layers.shapes._shapes_constants import Mode

    modes = dict(Shapes._drag_modes)
    modes[Mode.SELECT] = _select_unless_bbox_drag
    modes[Mode.DIRECT] = _select_unless_bbox_drag
    TurboBoxLayer._drag_modes = modes


_install_drag_modes()
