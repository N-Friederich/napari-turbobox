"""
Multi-viewer synchronization utilities for napari-turbobox.

This module provides factory functions to create synchronized bbox layers
across multiple napari viewers, enabling consistent bbox visualization in
multi-view applications (e.g., XY/XZ/YZ slice views + 3D view).
"""

from __future__ import annotations

import logging
import warnings
from typing import Literal

import napari
import numpy as np

from .data_store import BBoxDataStore
from .layer import TurboBoxLayer

logger = logging.getLogger(__name__)


def _sync_mode_for_viewer(viewer: napari.Viewer) -> Literal["live", "on_commit"]:
    """Pick a per-layer ``sync_mode`` from a viewer's current display mode.

    A viewer rendering in 3D (``ndisplay == 3``) gets ``"on_commit"`` so its
    layer rebuilds only once per edit session instead of on every intermediate
    store update; 2D viewers get ``"live"`` for immediate feedback.

    The decision is made once, at layer-creation time, and is **not**
    re-evaluated if the viewer later toggles ``ndisplay`` — no listener is
    attached to ``viewer.dims.events.ndisplay`` (intentionally out of scope).
    Reassign ``layer.sync_mode`` manually if a viewer's display mode changes
    at runtime.
    """
    try:
        ndisplay = viewer.dims.ndisplay
    except AttributeError:
        logger.warning(
            "Viewer %r exposes no dims.ndisplay; defaulting sync_mode to 'live'", viewer
        )
        return "live"
    return "on_commit" if ndisplay == 3 else "live"


def create_synchronized_bbox_layers(
    main_viewer: napari.Viewer,
    sub_viewers: list[napari.Viewer],
    bbox_data: np.ndarray | None = None,
    image_shape: tuple | None = None,
    sync_mode: Literal["live", "on_commit", "snapshot"] = "live",
    **layer_kwargs,
) -> list[TurboBoxLayer]:
    """
    Create synchronized BBox layers for multiple viewers.

    This function creates multiple TurboBoxLayer instances (one per
    viewer) that all share the same underlying bbox data. When one layer is
    modified, all other layers automatically update their visualization.

    The main viewer's layer is interactive (allows editing), while sub-viewers'
    layers are read-only for display purposes only.

    Parameters
    ----------
    main_viewer : napari.Viewer
        The primary viewer where users interact with bboxes
    sub_viewers : list of napari.Viewer
        Additional viewers that should display the same bboxes (read-only)
    bbox_data : np.ndarray, optional
        Initial bounding boxes as array of shape (N, 2, D)
    image_shape : tuple, optional
        Shape of the image volume for coordinate clamping
    sync_mode : Literal["live", "on_commit", "snapshot"], optional
        Selects the overall layout of the created layers:
        - "live" / "on_commit": all layers share a single BBoxDataStore. The
          per-layer sync mode is then derived automatically from each viewer's
          ``ndisplay`` (3D viewers -> "on_commit", 2D viewers -> "live"), so
          these two function-level values produce identical results.
        - "snapshot": Independent, non-synchronized layers, each initialized
          with a copy of bbox_data.
        Default is "live".
    **layer_kwargs : dict
        Additional keyword arguments passed to TurboBoxLayer
        (e.g., edge_color, edge_width, name)

    Returns
    -------
    list of TurboBoxLayer
        One layer per viewer (main + subs), all sharing the same data.
        Layers are automatically added to their respective viewers.

    Examples
    --------
    Create synchronized views for a multi-viewer widget::

        bbox_layers = create_synchronized_bbox_layers(
            main_viewer=viewer,
            sub_viewers=[viewer_xy, viewer_xz, viewer_yz, viewer_3d],
            image_shape=(10, 512, 512),
            edge_color="cyan",
            edge_width=2.0
        )

        # Add a bbox in main viewer - all views update automatically!
        bbox_layers[0].add_boxes([[[0, 10, 10], [5, 50, 50]]])

    Access synchronized layers::

        main_layer = bbox_layers[0]  # Interactive layer
        display_layers = bbox_layers[1:]  # Read-only display layers

    Notes
    -----
    - Main viewer layer: interactive=True (allows editing)
    - Sub-viewer layers: interactive=False (read-only display)
    - All layers share the same BBoxDataStore instance
    - Changes propagate automatically via the store's event system
    - Each layer's sync_mode is derived from its viewer's ``ndisplay`` once,
      at creation time. Toggling a viewer between 2D and 3D afterwards does
      NOT update sync_mode automatically — reassign ``layer.sync_mode`` if
      needed.
    """
    logger.info(
        "Creating synchronized bbox layers: main=%s sub_viewers=%d sync_mode=%s",
        main_viewer,
        len(sub_viewers),
        sync_mode,
    )
    layers = []
    if sync_mode == "snapshot":
        main_store = BBoxDataStore(initial_data=bbox_data)
        main_layer = TurboBoxLayer(
            bbox_data_store=main_store, interactive=True, image_shape=image_shape, **layer_kwargs
        )
        main_viewer.add_layer(main_layer)
        layers.append(main_layer)
        logger.info("Created main snapshot layer '%s'", main_layer.name)
        for i, sub_viewer in enumerate(sub_viewers):
            sub_store = BBoxDataStore(
                initial_data=bbox_data.copy() if bbox_data is not None else None
            )
            sub_layer = TurboBoxLayer(
                bbox_data_store=sub_store,
                interactive=False,
                image_shape=image_shape,
                name=f"{layer_kwargs.get('name', 'Bounding Boxes')} (View {i + 1})",
                **{k: v for k, v in layer_kwargs.items() if k != "name"},
            )
            sub_viewer.add_layer(sub_layer)
            layers.append(sub_layer)
            logger.info("Created snapshot sub layer %d '%s'", i + 1, sub_layer.name)
    else:
        shared_store = BBoxDataStore(initial_data=bbox_data)
        main_layer_sync = _sync_mode_for_viewer(main_viewer)
        main_layer = TurboBoxLayer(
            bbox_data_store=shared_store,
            interactive=True,
            image_shape=image_shape,
            sync_mode=main_layer_sync,
            **layer_kwargs,
        )
        main_viewer.add_layer(main_layer)
        layers.append(main_layer)
        logger.info(
            "Created main synchronized layer '%s' (sync_mode=%s)",
            main_layer.name,
            main_layer_sync,
        )
        for i, sub_viewer in enumerate(sub_viewers):
            sub_layer_sync = _sync_mode_for_viewer(sub_viewer)
            sub_layer = TurboBoxLayer(
                bbox_data_store=shared_store,
                interactive=False,
                image_shape=image_shape,
                sync_mode=sub_layer_sync,
                name=f"{layer_kwargs.get('name', 'Bounding Boxes')} (View {i + 1})",
                **{k: v for k, v in layer_kwargs.items() if k != "name"},
            )
            sub_viewer.add_layer(sub_layer)
            layers.append(sub_layer)
            logger.info(
                "Created synchronized sub layer %d '%s' (sync_mode=%s)",
                i + 1,
                sub_layer.name,
                sub_layer_sync,
            )
    logger.info("Synchronized %d layers", len(layers))
    return layers


def sync_existing_layer_to_viewers(
    source_layer: TurboBoxLayer, target_viewers: list[napari.Viewer], **layer_kwargs
) -> list[TurboBoxLayer]:
    """
    Create synchronized copies of an existing bbox layer in other viewers.

    This is useful when you already have a bbox layer and want to display it
    in additional viewers while keeping them synchronized.

    Parameters
    ----------
    source_layer : TurboBoxLayer
        The existing layer to synchronize from
    target_viewers : list of napari.Viewer
        Viewers that should display the synchronized layer
    **layer_kwargs : dict
        Additional keyword arguments for the new layers

    Returns
    -------
    list of TurboBoxLayer
        New synchronized layers (one per target viewer)

    Examples
    --------
    Sync existing layer to multiple views::

        # Existing layer in main viewer
        bbox_layer = viewer.layers['Bounding Boxes']

        # Create synchronized views
        sync_layers = sync_existing_layer_to_viewers(
            source_layer=bbox_layer,
            target_viewers=[viewer_xy, viewer_xz, viewer_yz]
        )

    Notes
    -----
    - Creates a new shared store from source layer's current data
    - Source layer is NOT modified or re-created
    - Target layers are read-only (interactive=False)
    - Changes to source layer do NOT auto-sync (use create_synchronized_bbox_layers for bidirectional sync)
    """
    warnings.warn(
        "sync_existing_layer_to_viewers is deprecated and will be removed in a future release. Use create_synchronized_bbox_layers instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    shared_store = source_layer._bbox_store
    current_data = shared_store.data
    logger.info(
        "Syncing existing layer '%s' to %d viewers with %d boxes",
        source_layer.name,
        len(target_viewers),
        len(current_data),
    )
    layers = []
    for i, viewer in enumerate(target_viewers):
        edge_color = source_layer.edge_color
        edge_width = source_layer.edge_width
        if hasattr(edge_color, "__len__") and (not isinstance(edge_color, str)):
            edge_color = edge_color[0] if len(edge_color) > 0 else "cyan"
        if hasattr(edge_width, "__len__"):
            edge_width = edge_width[0] if len(edge_width) > 0 else 2.0
        sync_layer = TurboBoxLayer(
            bbox_data_store=shared_store,
            interactive=False,
            image_shape=source_layer._image_shape,
            edge_color=edge_color,
            edge_width=edge_width,
            name=f"{source_layer.name} (Sync {i + 1})",
            **layer_kwargs,
        )
        viewer.add_layer(sync_layer)
        layers.append(sync_layer)
        logger.info("Created synchronized copy %d '%s'", i + 1, sync_layer.name)
    logger.info("Finished creating %d synchronized layers", len(layers))
    return layers
