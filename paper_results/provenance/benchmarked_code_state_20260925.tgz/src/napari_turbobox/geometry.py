"""Geometry helpers for nD bounding boxes."""

from __future__ import annotations

import logging
from collections.abc import Iterable, Sequence
from functools import lru_cache
from itertools import product

import numpy as np

logger = logging.getLogger(__name__)
MIN_EDGE_LENGTH_DATA = 0.1


def ensure_bbox_array(
    data: Iterable[Sequence[Sequence[float]]] | np.ndarray | None, ndim: int | None = None
) -> np.ndarray:
    """Normalize arbitrary bbox-like input to a (N, 2, ndim) float array."""
    if data is None:
        if ndim is None:
            ndim = 3
        return np.empty((0, 2, ndim), dtype=float)
    arr = np.asarray(data, dtype=float)
    if arr.size == 0:
        if ndim is None:
            ndim = 3
        return np.empty((0, 2, ndim), dtype=float)
    if arr.ndim == 1:
        if ndim is None:
            if arr.size % 2 != 0:
                raise ValueError("Unable to infer ndim from 1D bbox array.")
            ndim = arr.size // 2
        arr = arr.reshape(1, 2, ndim)
    elif arr.ndim == 2:
        if ndim is None:
            ndim = arr.shape[-1]
        arr = arr.reshape(-1, 2, ndim)
    elif arr.ndim == 3:
        if ndim is None:
            ndim = arr.shape[-1]
    else:
        raise ValueError(f"Expected bbox array with ndim <= 3, got shape {arr.shape}.")
    if arr.shape[-2] != 2:
        raise ValueError(f"Bounding box array must have shape (N, 2, ndim), got {arr.shape}.")
    if ndim is not None and arr.shape[-1] != ndim:
        raise ValueError(f"Bounding box ndim mismatch: expected {ndim}, got {arr.shape[-1]}.")
    mins = np.minimum(arr[:, 0], arr[:, 1])
    maxs = np.maximum(arr[:, 0], arr[:, 1])
    return np.stack([mins, maxs], axis=1)


@lru_cache(maxsize=32)
def _edge_index_template(ndim: int) -> np.ndarray:
    """Return edge index pairs for a unit hyper-cube."""
    if ndim not in (2, 3):
        raise ValueError("Only 2D and 3D bounding boxes are supported.")
    corners = list(product((0, 1), repeat=ndim))
    corner_to_index = {tuple(corner): idx for idx, corner in enumerate(corners)}
    edges: list[tuple[int, int]] = []
    for idx, corner in enumerate(corners):
        for axis in range(ndim):
            neighbour = list(corner)
            neighbour[axis] = 1 - neighbour[axis]
            neighbour = tuple(neighbour)
            neighbour_idx = corner_to_index[neighbour]
            if idx < neighbour_idx:
                edges.append((idx, neighbour_idx))
    return np.asarray(edges, dtype=int)


def corners_from_bbox(bbox: np.ndarray) -> np.ndarray:
    """Return axis-aligned corner coordinates for a single bounding box."""
    mins, maxs = np.asarray(bbox, dtype=float)
    ndim = mins.shape[0]
    offsets = np.array(list(product((0, 1), repeat=ndim)), dtype=float)
    ranges = maxs - mins
    return mins + offsets * ranges


def edges_from_bbox(bbox: np.ndarray) -> np.ndarray:
    """Return all edges of a bounding box as (M, 2, ndim) array."""
    corners = corners_from_bbox(bbox)
    ndim = corners.shape[-1]
    indices = _edge_index_template(ndim)
    return corners[indices]


def paths_from_bbox(bbox: np.ndarray) -> list[np.ndarray]:
    """Convert a single bounding box to a list of edge paths.

    Coordinate System details:
    BBox coordinates are defined in the layer's data coordinate space (world coordinates
    scaled by the layer's scale/affine transform). This coordinate space is independent of
    the screen/canvas scale. The degenerate edge filtering threshold is applied in this data
    coordinate space.

    Parameters
    ----------
    bbox : np.ndarray
        Bounding box array of shape (2, D) specifying [mins, maxs].

    Returns
    -------
    List[np.ndarray]
        List of non-degenerate edge paths of shape (2, D).
    """
    edges = edges_from_bbox(bbox)
    if edges.size == 0:
        return []
    valid_edges = []
    for edge in edges:
        start, end = (edge[0], edge[1])
        length = np.linalg.norm(end - start)
        if length > MIN_EDGE_LENGTH_DATA:
            valid_edges.append(edge)
        else:
            logger.debug("Skipping degenerate edge %s -> %s (length=%.6f)", start, end, length)
    logger.debug("Generated %d valid edges from %d total edges", len(valid_edges), len(edges))
    return valid_edges


path_from_bbox = paths_from_bbox


def paths_from_bboxes(bboxes: np.ndarray) -> list[np.ndarray]:
    """Vectorised conversion from bounding boxes to Shapes path data.

    Returns a flat list of all edge paths from all bboxes.
    """
    if bboxes.size == 0:
        return []
    all_paths = []
    for bbox in bboxes:
        all_paths.extend(path_from_bbox(bbox))
    return all_paths


def _closed_loop(points: Sequence[np.ndarray]) -> np.ndarray:
    """Return a closed polyline from the provided ndim-aligned points."""
    pts = [np.asarray(pt, dtype=float) for pt in points]
    if not pts:
        return np.empty((0, 0), dtype=float)
    if not np.allclose(pts[0], pts[-1]):
        pts.append(pts[0].copy())
    return np.vstack(pts)


def slice_paths_from_bbox(
    bbox: np.ndarray, dims_displayed: Sequence[int], current_step: Sequence[float]
) -> list[np.ndarray]:
    """Return closed rectangular slice paths for an nD bbox on a 2D view."""
    mins, maxs = np.asarray(bbox, dtype=float)
    ndim = mins.shape[0]
    displayed = tuple(int(ax) for ax in dims_displayed)
    if len(displayed) != 2:
        return []
    step = np.asarray(current_step, dtype=float)
    if step.shape[0] < ndim:
        pad_width = ndim - step.shape[0]
        step = np.pad(step, (pad_width, 0), mode="constant", constant_values=0.0)
    hidden_axes = [ax for ax in range(ndim) if ax not in displayed]
    for axis in hidden_axes:
        tolerance = 1e-06
        if step[axis] + tolerance < mins[axis] or step[axis] - tolerance > maxs[axis]:
            return []
    d0, d1 = displayed
    corners = [
        (mins[d0], mins[d1]),
        (mins[d0], maxs[d1]),
        (maxs[d0], maxs[d1]),
        (maxs[d0], mins[d1]),
    ]
    loop_points: list[np.ndarray] = []
    for cx, cy in corners:
        point = step.copy()
        point[d0] = cx
        point[d1] = cy
        loop_points.append(point)
    return [_closed_loop(loop_points)]


def slice_paths_from_bboxes(
    bboxes: np.ndarray, dims_displayed: Sequence[int], current_step: Sequence[float]
) -> list[np.ndarray]:
    """Return slice-aligned rectangular loops for multiple bounding boxes.

    🚀 OPTIMIZATION: Vectorized spatial pruning filters out boxes that don't
    intersect the current slice before path generation.
    """
    if bboxes.size == 0:
        return []
    ndim = bboxes.shape[-1]
    displayed = tuple(int(ax) for ax in dims_displayed)
    if len(displayed) != 2:
        loops: list[np.ndarray] = []
        for bbox in bboxes:
            loops.extend(slice_paths_from_bbox(bbox, dims_displayed, current_step))
        return loops
    step = np.asarray(current_step, dtype=float)
    if step.shape[0] < ndim:
        pad_width = ndim - step.shape[0]
        step = np.pad(step, (pad_width, 0), mode="constant", constant_values=0.0)
    hidden_axes = [ax for ax in range(ndim) if ax not in displayed]
    if not hidden_axes:
        visible_boxes = bboxes
    else:
        mins = bboxes[:, 0, :]
        maxs = bboxes[:, 1, :]
        tolerance = 1e-06
        visible_mask = np.ones(len(bboxes), dtype=bool)
        for axis in hidden_axes:
            axis_visible = (mins[:, axis] - tolerance <= step[axis]) & (
                step[axis] <= maxs[:, axis] + tolerance
            )
            visible_mask &= axis_visible
        visible_boxes = bboxes[visible_mask]
    if visible_boxes.size == 0:
        return []
    d0, d1 = displayed
    rect_mins = visible_boxes[:, 0, [d0, d1]]
    rect_maxs = visible_boxes[:, 1, [d0, d1]]
    n_vis = len(visible_boxes)
    all_pts = np.tile(step, (n_vis, 5, 1))
    all_pts[:, 0, d0] = rect_mins[:, 0]
    all_pts[:, 0, d1] = rect_mins[:, 1]
    all_pts[:, 1, d0] = rect_mins[:, 0]
    all_pts[:, 1, d1] = rect_maxs[:, 1]
    all_pts[:, 2, d0] = rect_maxs[:, 0]
    all_pts[:, 2, d1] = rect_maxs[:, 1]
    all_pts[:, 3, d0] = rect_maxs[:, 0]
    all_pts[:, 3, d1] = rect_mins[:, 1]
    all_pts[:, 4, d0] = rect_mins[:, 0]
    all_pts[:, 4, d1] = rect_mins[:, 1]
    return list(all_pts)


def face_loops_from_bbox(bbox: np.ndarray) -> list[np.ndarray]:
    """Return closed loops outlining each face of a 3D bounding box."""
    bbox = np.asarray(bbox, dtype=float)
    if bbox.shape[-1] != 3:
        raise ValueError("face_loops_from_bbox only supports 3D boxes.")
    mins, maxs = bbox
    z_loops = [
        [
            (mins[0], mins[1], mins[2]),
            (mins[0], maxs[1], mins[2]),
            (maxs[0], maxs[1], mins[2]),
            (maxs[0], mins[1], mins[2]),
        ],
        [
            (mins[0], mins[1], maxs[2]),
            (mins[0], maxs[1], maxs[2]),
            (maxs[0], maxs[1], maxs[2]),
            (maxs[0], mins[1], maxs[2]),
        ],
    ]
    x_loops = [
        [
            (mins[0], mins[1], mins[2]),
            (mins[0], mins[1], maxs[2]),
            (mins[0], maxs[1], maxs[2]),
            (mins[0], maxs[1], mins[2]),
        ],
        [
            (maxs[0], mins[1], mins[2]),
            (maxs[0], mins[1], maxs[2]),
            (maxs[0], maxs[1], maxs[2]),
            (maxs[0], maxs[1], mins[2]),
        ],
    ]
    y_loops = [
        [
            (mins[0], mins[1], mins[2]),
            (mins[0], mins[1], maxs[2]),
            (maxs[0], mins[1], maxs[2]),
            (maxs[0], mins[1], mins[2]),
        ],
        [
            (mins[0], maxs[1], mins[2]),
            (mins[0], maxs[1], maxs[2]),
            (maxs[0], maxs[1], maxs[2]),
            (maxs[0], maxs[1], mins[2]),
        ],
    ]
    loops = []
    for faces in (z_loops, x_loops, y_loops):
        for face in faces:
            loops.append(_closed_loop(face))
    return loops


# Deterministic corner traversal covering all 12 edges of a 3D box with a
# single open polyline. Corner index = binary (axis0, axis1, axis2), matching
# the itertools.product((0, 1), repeat=3) ordering used by corners_from_bbox.
#
#   0-1-3-2-0   front face (axis0 = min)
#   0-4         connector edge to the back face
#   4-5-7-6-4   back face (axis0 = max)
#   4-5 1-3 6-7 are each retraced once to reach the three remaining
#               connector edges 1-5, 3-7 and 2-6.
#
# The cube graph has no Eulerian path (all 8 vertices have odd degree 3),
# so exactly 3 edges must be retraced. Result: 16 vertices / 15 segments
# covering all 12 unique edges.
_WIREFRAME_TRAVERSAL = (0, 1, 3, 2, 0, 4, 5, 7, 6, 4, 5, 1, 3, 7, 6, 2)


def wireframe_path_from_bbox(bbox: np.ndarray) -> np.ndarray:
    """Return a single (16, 3) path tracing all 12 edges of a 3D bbox.

    The 8 box corners are visited in a fixed, deterministic order so that a
    single open polyline draws every one of the 12 box edges at least once.
    Because the cube graph is non-Eulerian (all 8 vertices have odd degree 3),
    exactly **3 edges are retraced**: corner4-corner5, corner1-corner3 and
    corner6-corner7. The returned path therefore has 16 vertices / 15
    segments covering the 12 unique edges.

    This replaces the previous 6-closed-face-loop representation (6 napari
    shapes per box) with one shape per box — adapted from napari-bbox's
    single-shape-per-box pattern (see commit_profile_comparison.md).

    Parameters
    ----------
    bbox : np.ndarray
        Bounding box of shape (2, 3), i.e. [mins, maxs].

    Returns
    -------
    np.ndarray
        A (16, 3) array of path vertices. Render with napari
        ``shape_type='path'`` — the wireframe is a non-planar, self-touching
        polyline and must not be treated as a polygon.
    """
    bbox = np.asarray(bbox, dtype=float)
    if bbox.shape[-1] != 3:
        raise ValueError("wireframe_path_from_bbox only supports 3D boxes.")
    corners = corners_from_bbox(bbox)
    return corners[list(_WIREFRAME_TRAVERSAL)]


def face_loops_from_bboxes(bboxes: np.ndarray) -> list[np.ndarray]:
    """Return face loops for a batch of 3D bounding boxes."""
    if bboxes.size == 0:
        return []
    loops: list[np.ndarray] = []
    for bbox in bboxes:
        loops.extend(face_loops_from_bbox(bbox))
    return loops


def bbox_from_path(path: np.ndarray) -> np.ndarray | None:
    """Derive (min, max) coordinates from a Shapes path array."""
    points = np.asarray(path, dtype=float)
    if points.size == 0:
        return None
    mask = ~np.isnan(points).any(axis=1)
    points = points[mask]
    if points.size == 0:
        return None
    mins = points.min(axis=0)
    maxs = points.max(axis=0)
    return np.stack([mins, maxs], axis=0)


def extrude_2d_to_3d_box(
    bbox_2d: np.ndarray,
    displayed_axes: Sequence[int],
    current_step: Sequence[float],
    extrusion_range: tuple[float, float] | None = None,
) -> np.ndarray:
    """Convert a 2D bounding box to a 3D box by extruding along the hidden axis.

    Parameters
    ----------
    bbox_2d : np.ndarray
        A (2, ndim) array representing [mins, maxs] in nD space.
        The hidden axis should have mins==maxs at the current slice position.
    displayed_axes : Sequence[int]
        The axes that are currently displayed (typically [1, 2] for y,x in a z-stack).
    current_step : Sequence[float]
        The current position in each dimension.
    extrusion_range : Tuple[float, float] | None
        Optional (min, max) values for the hidden axis.
        If None, extrudes from 0 to current_step (or current_step to end if available).

    Returns
    -------
    np.ndarray
        A (2, ndim) array representing the 3D bounding box.
    """
    bbox = np.asarray(bbox_2d, dtype=float).copy()
    mins, maxs = bbox
    ndim = mins.shape[0]
    hidden_axes = [ax for ax in range(ndim) if ax not in displayed_axes]
    if not hidden_axes:
        return bbox
    for axis in hidden_axes:
        if extrusion_range is not None:
            mins[axis] = extrusion_range[0]
            maxs[axis] = extrusion_range[1]
        else:
            current_pos = current_step[axis] if axis < len(current_step) else 0.0
            mins[axis] = 0.0
            maxs[axis] = max(current_pos, 1.0)
    return np.stack([mins, maxs], axis=0)
