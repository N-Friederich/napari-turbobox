"""
Shared bounding box data store for multi-viewer synchronization.

This module provides BBoxDataStore, which manages bbox data that can be shared
across multiple TurboBoxLayer instances in different viewers.
"""

from __future__ import annotations

import logging
import weakref
from collections.abc import Callable
from typing import Literal

import numpy as np
from napari.utils.events import EmitterGroup, Event

logger = logging.getLogger(__name__)

# Coordinate storage dtype. float32 is exact for integer voxel indices up to
# 2**24 (16,777,216) -- far beyond any real volume axis -- at half the memory
# of float64. It must NOT be float16 (only exact to 2048; integer coords above
# that round to even values, silently corrupting voxel indices). The store may
# hold non-integer values mid-drag, so it must stay float, not int. The
# SpatialIndex uses the same dtype so its queries match the store exactly.
_COORD_DTYPE = np.float32


class _BatchUpdateContext:
    """Context manager for batching multiple data store updates.

    🚀 OPTIMIZATION: Defers listener notifications until all updates complete.
    """

    def __init__(self, store: BBoxDataStore):
        self.store = store
        self.was_batching = False

    def __enter__(self):
        self.was_batching = self.store._batch_mode
        self.store._batch_mode = True
        logger.debug("Entered batch update mode")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.store._batch_mode = self.was_batching
        if not self.was_batching and self.store._pending_notification:
            logger.debug("Exiting batch mode - sending deferred notification")
            self.store._pending_notification = False
            self.store._notify_listeners()
        return False


class _ListenerHandle:
    """Wrapper that stores listener callbacks as weak references when possible.

    Each handle carries its own ``sync_mode``:

    - ``"live"``    : the listener is notified immediately on every change.
    - ``"on_commit"``: while an edit session is active, notifications are
      deferred and coalesced into a single flush at ``end_edit_session``.
      Outside an edit session an ``on_commit`` listener behaves like ``live``.

    ``_has_pending`` disambiguates "nothing pending" from "a pending rebuild
    whose ``changed_idx`` is ``None``" (a bulk op cannot be distinguished from
    "no update" by the index alone).
    """

    __slots__ = (
        "_callback",
        "_has_pending",
        "_is_weak",
        "_pending_changed_idx",
        "_ref",
        "accepts_changed_idx",
        "sync_mode",
    )

    def __init__(
        self,
        callback: Callable[[np.ndarray], None],
        sync_mode: Literal["live", "on_commit"] = "live",
    ):
        import inspect

        self.sync_mode: Literal["live", "on_commit"] = sync_mode
        self._pending_changed_idx: int | None = None
        self._has_pending: bool = False
        try:
            self._ref = weakref.WeakMethod(callback)
            self._callback = None
            self._is_weak = True
        except TypeError:
            # Plain functions, lambdas and functools.partial objects are usually
            # created inline and referenced nowhere else; a weakref.ref to them
            # dies immediately and the listener would silently never fire.
            # Keep a strong reference (callers unregister explicitly).
            self._ref = None
            self._callback = callback
            self._is_weak = False
        try:
            sig = inspect.signature(callback)
            self.accepts_changed_idx = "changed_idx" in sig.parameters
        except Exception:
            self.accepts_changed_idx = False

    def __call__(self) -> Callable[[np.ndarray], None] | None:
        if self._is_weak:
            return self._ref()
        return self._callback

    def matches(self, callback: Callable[[np.ndarray], None]) -> bool:
        if self._is_weak:
            # weakref.WeakMethod reconstructs a *new* bound-method object on
            # every call, so an `is` test never matches a re-fetched bound
            # method. Compare by value: bound methods are equal when their
            # __self__ and __func__ match; for plain functions `==` is
            # identity, so this stays correct for non-method callbacks too.
            target = self._ref()
            return target is not None and target == callback
        return self._callback is callback

    @property
    def is_weak(self) -> bool:
        return self._is_weak

    def alive(self) -> bool:
        if self._is_weak:
            return self._ref() is not None
        return True


class BBoxDataStore:
    """
    Shared storage for bounding box data with event notifications.

    This class acts as a central data store that multiple layer instances
    can reference. When data changes, all registered listeners are notified
    automatically, enabling synchronized views across multiple napari viewers.

    Parameters
    ----------
    initial_data : np.ndarray, optional
        Initial bounding boxes as array of shape (N, 2, D) where N is number
        of boxes, D is dimensionality. Default: empty array

    Attributes
    ----------
    events : EmitterGroup
        Event emitters. Available events:
        - changed: Emitted when bbox data is modified
        - session_ended: Emitted when an edit session ends

    Examples
    --------
    Create shared store and use with multiple layers::

        store = BBoxDataStore(initial_data=boxes)
        layer1 = TurboBoxLayer(bbox_data_store=store)
        layer2 = TurboBoxLayer(bbox_data_store=store)
        # layer1 and layer2 now share the same data!

    Notes
    -----
    Bound-method listeners are held through weak references, so a layer that
    is garbage-collected drops out by itself. Other callables (functions,
    lambdas, functools.partial) are held by strong references and must be
    removed with :meth:`unregister_listener`.

    .. warning::
        This class is NOT thread-safe. All modifications should be made from
        the main Qt/UI thread. If background thread updates are needed, use
        Qt signals or schedule updates via QTimer.singleShot(0, callback).
    """

    def __init__(self, initial_data: np.ndarray | None = None):
        """Initialize the data store with optional initial data.

        All mutations to the store must occur on the main thread.
        """
        if initial_data is None:
            self._bboxes = np.empty((0, 2, 3), dtype=_COORD_DTYPE)
        else:
            self._bboxes = np.asarray(initial_data, dtype=_COORD_DTYPE)
        self._listeners: list[_ListenerHandle] = []
        self.events = EmitterGroup(source=self, changed=Event, session_ended=Event)
        self._batch_mode = False
        self._pending_notification = False
        self._in_edit_session = False

    def _assert_main_thread(self) -> None:
        if __debug__:
            try:
                from qtpy.QtCore import QThread
                from qtpy.QtWidgets import QApplication

                app = QApplication.instance()
                if app is not None and QThread.currentThread() != app.thread():
                    if not getattr(self, "_thread_warning_shown", False):
                        self._thread_warning_shown = True
                        import warnings

                        warnings.warn(
                            "BBoxDataStore mutation called off the main thread! All mutations must occur on the main thread. Use QTimer.singleShot(0, callback) or Qt signals to schedule on the main thread.",
                            UserWarning,
                            stacklevel=3,
                        )
            except ImportError:
                pass

    @property
    def data(self) -> np.ndarray:
        """
        Get the current bounding box data.

        Returns
        -------
        np.ndarray
            Array of shape (N, 2, D) containing all bounding boxes
        """
        view = self._bboxes.view()
        view.flags.writeable = False
        return view

    @data.setter
    def data(self, value: np.ndarray) -> None:
        """
        Set new bounding box data and notify all listeners.

        Parameters
        ----------
        value : np.ndarray
            New bbox data of shape (N, 2, D)
        """
        self._assert_main_thread()
        self._bboxes = np.asarray(value, dtype=_COORD_DTYPE)
        self._notify_listeners()

    def update(self, new_bboxes: np.ndarray) -> None:
        """
        Update bbox data and notify listeners.

        This is an alias for setting the data property.

        Parameters
        ----------
        new_bboxes : np.ndarray
            New bbox data of shape (N, 2, D)
        """
        self.data = new_bboxes

    def update_box_silent(self, index: int, new_box: np.ndarray) -> None:
        """In-place update of a single box without notifying listeners.

        Does NOT propagate to synchronized viewers and never marks any
        listener as pending; the caller is responsible for a later
        notification (for example :meth:`update_box` or :meth:`update`).
        """
        self._assert_main_thread()
        self._bboxes[index] = np.asarray(new_box, dtype=float)

    def update_box(self, index: int, new_box: np.ndarray) -> None:
        """Update a single box in place and notify all listeners.

        Listeners that accept ``changed_idx`` receive ``index``. The layer calls
        this on every drag step; ``on_commit`` listeners defer the notification
        while an edit session is active. The row is written in place; the array
        is not copied.
        """
        self._assert_main_thread()
        self._bboxes[index] = np.asarray(new_box, dtype=float)
        self._notify_listeners(changed_idx=index)

    def update_boxes(self, updates: dict[int, np.ndarray]) -> None:
        """Apply multiple index->box updates in-place, then notify once.

        Parameters
        ----------
        updates : dict of int -> np.ndarray
            Mapping from box index to its new ``(2, D)`` value.

        Notes
        -----
        Multi-index changes collapse to a single ``_notify_listeners(
        changed_idx=None)`` call. This is intentional: a single ``None``
        notification signals "rebuild needed" to slow (``on_commit``)
        listeners rather than emitting one notification per index.
        """
        self._assert_main_thread()
        if not updates:
            return
        for index, new_box in updates.items():
            self._bboxes[index] = np.asarray(new_box, dtype=float)
        self._notify_listeners(changed_idx=None)

    def add_boxes(self, boxes: np.ndarray) -> None:
        """
        Add new boxes to existing data.

        Parameters
        ----------
        boxes : np.ndarray
            Boxes to add, shape (N, 2, D)
        """
        self._assert_main_thread()
        boxes = np.asarray(boxes, dtype=_COORD_DTYPE)
        if boxes.size == 0:
            return
        if self._bboxes.size == 0:
            self._bboxes = boxes
        else:
            self._bboxes = np.concatenate([self._bboxes, boxes], axis=0)
        self._notify_listeners()

    def remove_boxes(self, indices: list[int]) -> None:
        """
        Remove boxes at specified indices.

        Parameters
        ----------
        indices : list of int
            Indices of boxes to remove
        """
        self._assert_main_thread()
        if len(indices) == 0:
            return
        self._bboxes = np.delete(self._bboxes, indices, axis=0)
        self._notify_listeners()

    def clear(self) -> None:
        """Remove all boxes from the store."""
        self._assert_main_thread()
        self._bboxes = np.empty((0, 2, self._bboxes.shape[-1]), dtype=_COORD_DTYPE)
        self._notify_listeners()

    def register_listener(
        self,
        callback: Callable[[np.ndarray], None],
        *,
        sync_mode: Literal["live", "on_commit"] = "live",
    ) -> _ListenerHandle:
        """
        Register a callback to be called when data changes.

        Parameters
        ----------
        callback : callable
            Function to call with new bbox data as argument
        sync_mode : {"live", "on_commit"}, optional
            ``"live"`` (default) notifies the listener immediately on every
            change. ``"on_commit"`` defers and coalesces notifications while
            an edit session is active (see :meth:`begin_edit_session`).

        Returns
        -------
        _ListenerHandle
            The handle for this listener. Callers may later mutate its
            ``sync_mode`` directly or via :meth:`set_listener_sync_mode`.
            If ``callback`` is already registered, the existing handle is
            returned unchanged.
        """
        for handle in self._listeners:
            if handle.matches(callback):
                return handle
        handle = _ListenerHandle(callback, sync_mode=sync_mode)
        if not handle.alive():
            return handle
        if not handle.is_weak:
            logger.warning(
                "Listener %r cannot be weak-referenced; storing strong reference", callback
            )
        self._listeners.append(handle)
        if hasattr(self.events, "changed"):
            try:
                if callback in self.events.changed.callbacks:
                    self.events.changed.disconnect(callback)
                    logger.debug("Removed duplicate callback from events.changed")
            except (ValueError, TypeError, AttributeError):
                pass
        return handle

    def set_listener_sync_mode(
        self,
        callback: Callable[[np.ndarray], None],
        sync_mode: Literal["live", "on_commit"],
    ) -> None:
        """Update the ``sync_mode`` of an already-registered listener.

        Parameters
        ----------
        callback : callable
            The previously registered callback.
        sync_mode : {"live", "on_commit"}
            The new synchronization mode.

        Raises
        ------
        ValueError
            If ``callback`` is not a registered listener.
        """
        for handle in self._listeners:
            if handle.matches(callback):
                handle.sync_mode = sync_mode
                return
        raise ValueError(f"Callback {callback!r} is not a registered listener")

    def begin_edit_session(self) -> None:
        """Mark the start of an edit session.

        While a session is active, ``on_commit`` listeners defer their
        notifications until :meth:`end_edit_session`. Idempotent: calling
        twice without an intervening ``end_edit_session`` is a no-op.
        """
        self._in_edit_session = True

    def end_edit_session(self) -> None:
        """End the edit session and flush deferred ``on_commit`` listeners.

        Every ``on_commit`` listener with a pending update is called exactly
        once with its coalesced ``changed_idx``; its pending state is then
        cleared. Idempotent: calling without an active session is a no-op.
        """
        if not self._in_edit_session:
            return
        self._in_edit_session = False
        self._listeners = [h for h in self._listeners if h.alive()]
        for handle in self._listeners:
            had_pending = handle._has_pending
            changed_idx = handle._pending_changed_idx
            handle._has_pending = False
            handle._pending_changed_idx = None
            if had_pending:
                self._call_listener(handle, changed_idx)
        self.events.session_ended()

    @property
    def in_edit_session(self) -> bool:
        """True while an edit session (see :meth:`begin_edit_session`) is active."""
        return self._in_edit_session

    def unregister_listener(self, callback: Callable[[np.ndarray], None]) -> None:
        """
        Remove a previously registered callback.

        Parameters
        ----------
        callback : callable
            Callback to remove
        """
        self._listeners = [h for h in self._listeners if not h.matches(callback)]

    def batch_update(self):
        """
        Context manager for batching multiple data updates into a single notification.

        Use this when performing multiple add/remove operations to avoid redundant
        synchronization overhead. All listener notifications are deferred until
        the context exits.

        Examples
        --------
        Efficiently add multiple boxes::

            with store.batch_update():
                for box in boxes_list:
                    store.add_boxes(box)
            # Only ONE notification sent here, not len(boxes_list)

        Notes
        -----
        The deferred notification carries no ``changed_idx``, so every
        listener rebuilds its view once.
        """
        return _BatchUpdateContext(self)

    def _call_listener(self, handle: _ListenerHandle, changed_idx: int | None) -> None:
        """Invoke a single listener, respecting ``accepts_changed_idx``.

        Exceptions raised by the listener are swallowed and logged so that a
        misbehaving listener cannot break notification of the others.
        """
        callback = handle()
        if callback is None:
            return
        view = self._bboxes.view()
        view.flags.writeable = False
        try:
            if handle.accepts_changed_idx:
                callback(view, changed_idx=changed_idx)
            else:
                callback(view)
        except Exception:
            logger.exception("Error notifying listener")

    def _notify_listeners(self, changed_idx: int | None = None) -> None:
        """Notify all registered listeners of data change.

        If batch mode is active, defers notification until batch completes.
        ``on_commit`` listeners defer while an edit session is active; their
        pending ``changed_idx`` is coalesced (multiple distinct indices, or a
        bulk op after a single-box update, collapse to ``None`` -> rebuild).
        """
        if self._batch_mode:
            self._pending_notification = True
            logger.debug("Deferring listener notification (batch mode active)")
            return
        self._listeners = [h for h in self._listeners if h.alive()]
        logger.debug("Notifying%slisteners", len(self._listeners))
        view = self._bboxes.view()
        view.flags.writeable = False
        for handle in self._listeners:
            if handle.sync_mode == "on_commit" and self._in_edit_session:
                if not handle._has_pending:
                    handle._pending_changed_idx = changed_idx
                    handle._has_pending = True
                elif handle._pending_changed_idx != changed_idx:
                    handle._pending_changed_idx = None
                # else: same index as before -> pending stays as it was
            else:
                self._call_listener(handle, changed_idx)
        self.events.changed(value=view)

    @property
    def ndim(self) -> int:
        """Get dimensionality of stored boxes."""
        return self._bboxes.shape[-1] if self._bboxes.size > 0 else 3

    @property
    def num_boxes(self) -> int:
        """Get number of boxes currently stored."""
        return len(self._bboxes)

    def __len__(self) -> int:
        """Return number of boxes."""
        return self.num_boxes

    def __repr__(self) -> str:
        """Return string representation."""
        return f"BBoxDataStore(num_boxes={self.num_boxes}, ndim={self.ndim})"
